
#define  WM_APING_DONE                  (WM_USER + 5)   // user msg
#define  WM_CPICCALL_ERR                (WM_USER + 6)   // user msg
#define  WM_REFRESH                     (WM_USER + 7)   // user msg

#define  MAX_TP_NAME                    (64)
#define  MAX_DESTINATION                (17)
#define  MAX_MODE_NAME                  (8)
#define  MAX_USERID                     (10)
#define  MAX_PASSWORD                   (10)
#define  MAX_PACKETSIZE                 (32763)         // see d10749
#define  MAX_CONSECUTIVE                (32767)
#define  MAX_ITERATIONS                 (65535)

#define  MAX_SYM_DEST_NAME              (8)
#define  LAST_MESSAGE_NUM               (32767)
#define  EXCHANGE_BUFFER_SIZE           (128)

#define  MAJOR_VERSION                  (2)
#define  MINOR_VERSION                  (38)
#define  ONEWAY_MAJOR_VERSION           (2)
#define  ONEWAY_MINOR_VERSION           (2)
#define  CPICERR_EXCHANGE_VERSION       (1)
#define  CPICERR_EXCHANGE_OPSYS_STRING  (2)
