
long DoAllocate(CWinapingDoc* pDoc);
long DoExchange(CWinapingDoc* pDoc);
long DoIteration(CWinapingDoc* pDoc, long* pTime, BOOL* pVerifyOK);
long DoDeallocate(CWinapingDoc* pDoc);
void DoTranslate(CWinapingDoc* pDoc, long rc);

