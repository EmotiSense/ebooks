// cpdslistDlg.h : header file
//

#include "conndlg.h"

/////////////////////////////////////////////////////////////////////////////
// CDSListDlg dialog

class CDSListDlg : public CDialog
{
private:
  ECLSession    *m_pECLSession;
  CDSListApp    *m_pMyApp;
  CEdit         *m_pDSContents;
  CListCtrl     *m_pDSList;
  int           m_NumDS;

  void FillDSList();
  BOOL GetToISPF();

// Construction
public:
	CDSListDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDSListDlg)
	enum { IDD = IDD_CPDSLIST_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDSListDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDSListDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnRefreshds();
	afx_msg void OnClickDslist(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
