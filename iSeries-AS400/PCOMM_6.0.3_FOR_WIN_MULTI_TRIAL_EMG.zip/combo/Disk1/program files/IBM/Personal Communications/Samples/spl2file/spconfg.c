//******************************************************************************
//
//  File name   : SPCONFG.C
//
//  Description : Configure Spl2File for the session
//
//  FUNCTIONS:
//
//  COMMENTS:
//
//  Copyright  (C) 1993, 1996 IBM Corporation
//                        All rights reserved.
//
//******************************************************************************

#include <windows.h>                // required for all Windows applications
#include <windowsx.h>               // Windows Macro APIs, window message crackers
#include <string.h>                 // C string functions
#include <stdio.h>                  // C functions

#include "spl2file.h"               // specific to this program
#include "spdata.h"                 // Global Data

//******************************************************************************
//
//  ConfigureSpoolToFile - Configure Spl2File for this session
//
//  PURPOSE: to setup various Spl2File operating parameters
//
//  COMMENTS:
//
//******************************************************************************
void ConfigureSpoolToFile( HWND hWnd )
{
  FARPROC lpProcModalDialog;                   //
                                               //
  lpProcModalDialog = MakeProcInstance(SpoolToFileOptionsDialog, hGlobalInst);
  DialogBox(hGlobalInst, MAKEINTRESOURCE(SPOPTS), hWnd, lpProcModalDialog);
                                               // Display option dialog box
  FreeProcInstance(lpProcModalDialog);         //
}

//******************************************************************************
//
//  FUNCTION: SpoolToFileOptionsDialog(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for CMS filename dialog box
//
//  MESSAGES:
//
//      WM_INITDIALOG - initialize dialog box
//      WM_COMMAND    - Input received
//
//  COMMENTS:
//
//      No initialization is needed for this particular dialog box, but TRUE
//      must be returned to Windows.
//
//      Wait for user to click on "Ok" button, then close the dialog box.
//
//******************************************************************************
BOOL FAR PASCAL SpoolToFileOptionsDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{                                              //
  switch (message)                             //
  {                                            //
    case WM_INITDIALOG:                        // message: initialize dialog box
    {                                          //
      WORD uID;                                //
                                               //
      CheckDlgButton(hDlg, ID_CHECKBOX1, bVisible);
                                               //
      uID = ( bRemoveSoSi == TRUE ? ID_RADIO1 : ID_RADIO2 );
      CheckRadioButton(hDlg, ID_RADIO1, ID_RADIO2, uID);
                                               //
      CenterDialogOnScreen( hDlg );            // Center it
      GetWindowText(hDlg, zMsgBuffer, sizeof(zMsgBuffer));
      lstrcat(zMsgBuffer, zSessionID);         //
      SetWindowText(hDlg, zMsgBuffer);         //
    }                                          //
    return(TRUE);                              //
    break;                                     //
                                               //
    case WM_COMMAND:                           // message: received a command
      switch (GET_WM_COMMAND_ID(wParam,lParam))
      {                                        //
        case IDOK:                             //
        {                                      //
          uchar zTag[33];                      //
                                               //
          bRemoveSoSi = IsDlgButtonChecked(hDlg, ID_RADIO1);
                                               //
          bVisible    = IsDlgButtonChecked(hDlg, ID_CHECKBOX1);
                                               //
          if( bVisible )                       //
          {                                    //
            ShowWindow(hMainWnd, SW_MINIMIZE); // Show the window
          }                                    //
          else                                 //
          {                                    //
            ShowWindow(hMainWnd, SW_HIDE);     // Show the window HIDDEN
          }                                    //

          LoadString(hGlobalInst, LS_OPTIONS_TAG, zTag, sizeof(zTag) );
          lstrcat(zTag, zSessionID );          // Qualify the session
                                               //
          wsprintf(zMsgBuffer, "%d %d", bVisible, bRemoveSoSi);
                                               //
          WriteProfileString(zSpoolToFileClassPrefix,  // WIN.INI section name
                             zTag,             // Value tag
                             zMsgBuffer );     // Sending buffer
                                               //
          EndDialog(hDlg, TRUE);               // End the dialog
        }                                      //
        return(TRUE);                          //
        break;                                 //

        case IDCANCEL:                         //
        {                                      //
          EndDialog(hDlg, FALSE);              // Exits the dialog box
        }                                      //
        return(TRUE);                          //
        break;                                 //

        case ID_RADIO1:                        // yes button
        {                                      //
          CheckRadioButton(hDlg, ID_RADIO1, ID_RADIO2, ID_RADIO1);
        }                                      //
        return(TRUE);                          //
        break;                                 //

        case ID_RADIO2:                        // no button
        {                                      //
          CheckRadioButton(hDlg, ID_RADIO1, ID_RADIO2, ID_RADIO2);
        }                                      //
        return(TRUE);                          //
        break;                                 //

        default:                               //
          break;                               //

      }                                        //
      break;                                   //
  }                                            //
  return(FALSE);                               // Didn't process a message
}                                              //
