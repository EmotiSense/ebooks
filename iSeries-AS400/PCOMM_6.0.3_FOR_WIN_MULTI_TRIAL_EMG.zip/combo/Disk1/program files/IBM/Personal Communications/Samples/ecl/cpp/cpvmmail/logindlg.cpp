// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cpvmmail.h"
#include "LoginDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg dialog


CLoginDlg::CLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLoginDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoginDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLoginDlg, CDialog)
	//{{AFX_MSG_MAP(CLoginDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg message handlers

void CLoginDlg::OnOK() 
{
CEdit *UserNameEdit = (CEdit *)GetDlgItem(IDC_USERNAME);
CEdit *UserPasswordEdit = (CEdit *)GetDlgItem(PASSWORD);
CString UserName;
CString UserPassword;

  // Get the user name and password
  UserNameEdit->GetWindowText(UserName);
  UserPasswordEdit->GetWindowText(UserPassword);

  // Prep the logon string and enter the logon 
  CString LogonString = "L " + UserName + " HERE[enter]";
  try {
    m_pECLSession->GetPS()->SendKeys(LogonString, 23, 16);

    // If bad ID or password, go back out to main dialog to try again
    if ( m_pMyApp->WaitForScreen("PASSWORD NOT AUTHORIZED", "Enter one of the following commands:", 500, 5) ||
         m_pMyApp->WaitForScreen("not in CP directory", "Enter one of the following commands:", 500, 5) ) {
    	CDialog::OnOK();
      return;
    }

    // Wait for the password screen 
    if ( !m_pMyApp->WaitForScreen("Enter your password", "To change your password", 500, 50) ) {
      AfxMessageBox("Couldn't get to password screen", MB_ICONEXCLAMATION);
  	  CDialog::OnCancel();
    }

    // Enter the password
    LogonString = UserPassword + "[enter]";
    m_pECLSession->GetPS()->SendKeys(LogonString, 23, 16);

    // Wait for the Ready; prompt, end if not there
    if ( !m_pMyApp->WaitForScreen("Ready;", "RUNNING", 500, 50) ) {
      AfxMessageBox("Couldn't get to Ready; prompt", MB_ICONEXCLAMATION);
   	  CDialog::OnCancel();
    }
  }
  catch (ECLErr Err) {
    AfxMessageBox(Err.GetMsgText(), MB_ICONEXCLAMATION);
  }
	CDialog::OnOK();
}

void CLoginDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

BOOL CLoginDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
  m_pMyApp = (CCVMMailApp *)AfxGetApp();
  m_pECLSession = m_pMyApp->m_pECLSession;
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
