/*-----------------------------------------------------------------------------*
|  Menu IDs                                                                    |
*-----------------------------------------------------------------------------*/
#define IDM_ABOUT          100
#define IDM_TEXT           101
#define IDM_BIN            102
#define IDM_TITLE          103
#define IDM_TOP            104
#define IDM_TERM           105
#define IDM_CLEAR          106

/*-----------------------------------------------------------------------------*
|  Dialog IDs                                                                  |
*-----------------------------------------------------------------------------*/
#define ABOUTBOX           1000
#define INFOBOX            1001
#define TEXTBOX            1002
#define TITLEBOX           1003

#define IDD_NUMFILES       200
#define IDD_XCORD          201
#define IDD_YCORD          202
#define IDD_ASCII          203
#define IDD_CRLF           204
#define IDD_ADDITIONAL     205
#define IDD_OPTIONS        206
#define IDD_VMDISK         207
#define IDD_SESSID         208
#define IDD_TITLE          209
#define IDD_LIST           210

/*-----------------------------------------------------------------------------*
|  Icon IDs                                                                    |
*-----------------------------------------------------------------------------*/
#define DDXFER             400
#define DDSEND             410
#define DDRECV             420

/*-----------------------------------------------------------------------------*
|  String IDs                                                                  |
*-----------------------------------------------------------------------------*/
#define LS_ASCII           300
#define LS_CRLF            301
#define LS_MENU            302
#define LS_LIST            303
#define LS_LISTBOX         304
#define LS_TYPE            305
#define LS_CLASS           306
#define LS_TITLE           307

/*-----------------------------------------------------------------------------*
|  Defines for the main window's size                                          |
*-----------------------------------------------------------------------------*/
#define MAIN_WIDTH         400
#define MAIN_HEIGHT        200

/*-----------------------------------------------------------------------------*
|  Miscellaneous defines                                                       |
*-----------------------------------------------------------------------------*/
#define FILENAME_LENGTH    80
#define VMFILE_LENGTH      12
#define VMDISK_LENGTH      3
#define STRING_LEN         10
#define TITLE_LEN          64
#define BUFFER_LENGTH      64
#define HLLAPIBUFFER       128
#define FGString           (GMEM_MOVEABLE | GMEM_ZEROINIT | GMEM_DDESHARE)
#define ID_SEND            0
#define ID_RECV            1

/*-----------------------------------------------------------------------------*
|  DDXfer control block                                                        |
*-----------------------------------------------------------------------------*/
typedef struct tagDDXFERINFO
{
   unsigned fAscii   : 1;
   unsigned fCrlf    : 1;
   unsigned fTopmost : 1;
   unsigned fTerm    : 1;
   char     szVMDisk[3];
   char     szSessID[2];
   char     szOptions[128];
} DDXFERINFO, FAR * LPDDXFERINFO;

/*-----------------------------------------------------------------------------*
|  Function prototypes                                                         |
*-----------------------------------------------------------------------------*/
int      PASCAL WinMain(HANDLE, HANDLE, LPSTR, int);
LONG FAR PASCAL MainWndProc(HWND, UINT, WPARAM, LPARAM);
LONG FAR PASCAL ListWndProc(HWND, UINT, WPARAM, LPARAM);
BOOL FAR PASCAL About(HWND, UINT, WPARAM, LPARAM);
BOOL FAR PASCAL TextDlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL FAR PASCAL TitleDlgProc(HWND, UINT, WPARAM, LPARAM);

VOID     PASCAL SendArgProc(HWND);
VOID     PASCAL SendParmProc(HWND, LPSTR, LPSTR, BOOL);
BOOL     PASCAL GenerateHostFile(LPSTR, LPSTR);
VOID     PASCAL GetOption(LPSTR);
