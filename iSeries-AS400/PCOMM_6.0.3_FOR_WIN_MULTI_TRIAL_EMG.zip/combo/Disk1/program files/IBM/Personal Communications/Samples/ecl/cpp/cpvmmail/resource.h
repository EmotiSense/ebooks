//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cpvmmail.rc
//
#define IDC_REFRESH                     3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CPVMMAIL_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_LOGIN                       129
#define IDD_CONNECTIONS                 130
#define IDD_REPLY                       131
#define IDD_SPLASH                      132
#define IDI_VMMAIL                      133
#define IDC_MAILTEXT                    1000
#define ID_REFRESH                      1001
#define ID_KEEP                         1002
#define ID_DISCARD                      1003
#define ID_REPLY                        1004
#define ID_REPLYHIST                    1005
#define IDC_MAILLIST                    1006
#define IDC_USERNAME                    1007
#define PASSWORD                        1008
#define IDC_CONNLIST                    1008
#define IDC_REPLYTEXT                   1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
