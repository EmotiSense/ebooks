// CSetupdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetupdlg dialog

#include "pinginfo.h"
//class CWinapingDoc;

class CSetupdlg : public CDialog
{
// Construction
public:
//      CSetupdlg(CWnd* pParent = NULL);   // standard constructor
        CSetupdlg(PingInfo &pi, CWnd* pParent = NULL);

// Dialog Data
        //{{AFX_DATA(CSetupdlg)
        enum { IDD = IDD_SETUPDLG };
        //}}AFX_DATA


// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CSetupdlg)
        protected:
        virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
        //}}AFX_VIRTUAL

// Implementation
protected:

//      CWinapingDoc* pDoc;
        PingInfo      localpi, &docpi;

        // Generated message map functions
        //{{AFX_MSG(CSetupdlg)
        virtual void OnOK();
        afx_msg void OnReset();
        afx_msg void OnEcho();
        afx_msg void OnSecurity();
        virtual BOOL OnInitDialog();
        //}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};
