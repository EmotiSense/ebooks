// cpvmmailDlg.h : header file
//

#include "cpvmmail.h"
#include "conndlg.h"
#include "LoginDlg.h"
#include "ReplyDlg.h"
#include "Splash.h"
#include "eclall.hpp"

#ifndef _CPVMMAILDLG_H_
#define _CPVMMAILDLG_H_

/////////////////////////////////////////////////////////////////////////////
// CCpvmmailDlg dialog

class CCpvmmailDlg : public CDialog
{
private:
  ECLSession    *m_pECLSession;
  CCVMMailApp   *m_pMyApp;
  CEdit         *m_pMailText;
  int           m_NumMailMessages;
  int           m_MailRow;
  int           m_MailIndex;
  CString       m_FormattedMailString;
  BOOL          m_XtraPages;

  void FillMailList();
  void GetToMailPage();

// Construction
public:
	CCpvmmailDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCpvmmailDlg)
	enum { IDD = IDD_CPVMMAIL_DIALOG };
	CListCtrl	m_MailList;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCpvmmailDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCpvmmailDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRefresh();
	afx_msg void OnDiscard();
	afx_msg void OnKeep();
	afx_msg void OnReply();
	afx_msg void OnClose();
	afx_msg void OnClickMaillist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReplyHist();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //_CPVMMAILDLG_H_
