// winapdoc.h : interface of the CWinapingDoc class
//
/////////////////////////////////////////////////////////////////////////////

#include "pinginfo.h"
#include "aping.h"

class CWinapingDoc : public CDocument
{
protected: // create from serialization only
        CWinapingDoc();
        DECLARE_DYNCREATE(CWinapingDoc)

// Attributes
public:
        Aping*   aping;
        PingInfo pingInfo;       // info from setup dialog

        DWORD    alloctime;
        DWORD    confirmtime;
        CString  partner;

        CString  cmcall;
        CString  cmrcmsg;
        BOOL     stoprunning;
        unsigned char cm_conv_id[8];  // conv id for CPIC calls
        unsigned char *buffer;        // ptr to data buffer for send/rcv
// Operations
public:

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CWinapingDoc)
        public:
        virtual BOOL OnNewDocument();
        //}}AFX_VIRTUAL

// Implementation
public:
        virtual ~CWinapingDoc();
        virtual void Serialize(CArchive& ar);   // overridden for document i/o
#ifdef _DEBUG
        virtual void AssertValid() const;
        virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
        //{{AFX_MSG(CWinapingDoc)
                // NOTE - the ClassWizard will add and remove member functions here.
                //    DO NOT EDIT what you see in these blocks of generated code !
        //}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
