/***************************************************************/
/*                                                             */
/*                      SAMPLE EHLLAPI PROGRAM                 */
/*                                                             */
/*    Author:  IBM                                             */
/*    Date Written:  1996                                      */
/*    For use with IBM Personal Communications/3270            */
/*                                                             */
/*    Certain VM/370 keywords used below may vary in function  */
/*       depending on system configuration.  A host            */
/*       presentation space size of 1920 is assumed.           */
/*                                                             */
/***************************************************************/

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "hapi_c.h"                /* Get EHLLAPI include file  */

/*************************************************************/
/*                                                           */
/* You must set following systemid, userid, and password     */
/* for your local vm system.                                 */
/*                                                           */
/*************************************************************/

#define systemid "systemid"
#define userid   "userid"
#define password "password"

#define PSID "a"
#define PS_POS return_code
#define DRV_NUM return_code
#define CLEAR "@C"
#define ENTER "@E"

/* External variables */

      void call_hllapi();
      void send_keys();

      ULONG i;                       /* general counter */

      int    DRV_NUM;                /* for file transfer */
      int    PS_POS;                 /* for PS search */
      int    search_rc;

      int    function;               /* call parameters */
      char data_string[30];
      int    data_length;
      int    return_code;

      int   expected_return_code;    /* check call result */

      char sf_string[47] =
            {"autoexec.bat a:auto bat a (ascii crlf!"};

      char q_buffer[36];             /* for query system */
      char blank_screen[] =          /* blank screen     */
      {
       "\n"
      };

main()
{
/*************************************************************/
/*  Reset EHLLAPI.                                           */
/*************************************************************/
      function = HA_RESET_SYSTEM;
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Establish connection to the host presentation space.     */
/*************************************************************/
      function = HA_CONNECT_PS;
      strcpy (data_string, PSID);
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Send the system and user ids to the host.                */
/*************************************************************/
      strcpy (data_string, systemid);
      strcat (data_string, " ");
      strcat (data_string, userid);
      strcat (data_string, ENTER);
      data_length = strlen(data_string);
      send_keys();

/*************************************************************/
/*  Has CP asked for my password?  If not, wait for a host   */
/*    update and check again.  Try this twice; if it still   */
/*    hasn't asked, the system is either down or very slow.  */
/*    In this case, just terminate.                          */
/*************************************************************/
      function = HA_SEARCH_PS;
      strcpy (data_string, "Enter your password");
      data_length = strlen(data_string);
      expected_return_code = -1;
      call_hllapi();

      if (return_code != 0)
         {
          function = HA_START_HOST_NOTIFY;
          strcpy (data_string, "a   p           ");
          expected_return_code = 0;
          call_hllapi();

          function = HA_SET_SESSION_PARMS;
          strcpy (data_string, "ipause");
          data_length = strlen(data_string);
          expected_return_code = 0;
          call_hllapi();

          search_rc = 24;
          i = 1;

          while ((i <= 2) && (search_rc != 0))
             {
              function = HA_PAUSE;
              data_length = 10;
              expected_return_code = -1;
              call_hllapi();

              function = HA_QUERY_HOST_UPDATE;
              strcpy (data_string, PSID);
              expected_return_code = -1;
              call_hllapi();

              function = HA_SEARCH_PS;
              strcpy (data_string, "Enter your password");
              data_length = strlen(data_string);
              expected_return_code = -1;
              call_hllapi();
              search_rc = return_code;

              i = i + 1;
             }

          if (search_rc != 0)
             {
              printf ("CP never asked for a password - ");
              printf ("sample terminating\n");
              exit(9);
             }
         }

/*************************************************************/
/*  Stop host notification and reset 'pause'.                */
/*************************************************************/
      function = HA_STOP_HOST_NOTIFY;
      strcpy (data_string, PSID);
      expected_return_code = 0;
      call_hllapi();

      function = HA_SET_SESSION_PARMS;
      strcpy (data_string, "fpause");
      data_length = strlen(data_string);
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Send the password & enter.                               */
/*************************************************************/
      strcpy (data_string, password);
      strcat (data_string, ENTER);
      data_length = strlen(data_string);
      send_keys();

/*************************************************************/
/*  Keep clearing the host presentation space until the      */
/*    ready prompt (Ready;) is found.                        */
/*************************************************************/
      function = HA_SET_SESSION_PARMS;
      strcpy (data_string, "srchfrom");
      data_length = strlen(data_string);
      expected_return_code = 0;
      call_hllapi();

      search_rc = 24;
      while (search_rc != 0)
         {
          function = HA_SEARCH_PS;
          strcpy (data_string, "MORE");
          data_length = strlen(data_string);
          PS_POS = 1900;
          expected_return_code = -1;
          call_hllapi();

          if (return_code == 0)
             {
              strcpy (data_string, CLEAR);
              data_length = 2;
              send_keys();
             }

          function = HA_SEARCH_PS;
          strcpy (data_string, "HOLDING");
          data_length = strlen(data_string);
          PS_POS = 1900;
          expected_return_code = -1;
          call_hllapi();

          if (return_code == 0)
             {
              strcpy (data_string, CLEAR);
              data_length = 2;
              send_keys();
             }

          function = HA_SEARCH_PS;
          strcpy (data_string, "Ready;");
          data_length = strlen(data_string);
          PS_POS = 1;
          expected_return_code = -1;
          call_hllapi();

          search_rc = return_code;
         }

      function = HA_SET_SESSION_PARMS;
      strcpy (data_string, "srchall");
      data_length = strlen(data_string);
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Set EOT mode on.                                         */
/*************************************************************/
      function = HA_SET_SESSION_PARMS;
      strcpy (data_string, "streot eot=!");
      data_length = strlen(data_string);
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Block normal messages on VM.                             */
/*************************************************************/
      strcpy (data_string, "set msg off@E!");
      send_keys();

/*************************************************************/
/*  Prepare for file transfer by disconnecting from the      */
/*    host presentation space.                               */
/*************************************************************/
      function = HA_DISCONNECT_PS;
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Upload "autoexec.bat".                                   */
/*************************************************************/
      function = HA_SEND_FILE;
      DRV_NUM = 4;
      expected_return_code = 3;
      strcpy (data_string, sf_string);
      call_hllapi();

/*************************************************************/
/*  Set EOT mode off.                                        */
/*************************************************************/
      function = HA_SET_SESSION_PARMS;
      strcpy (data_string, "strlen");
      data_length = strlen(data_string);
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Reconnect to the host presentation space.                */
/*************************************************************/
      function = HA_CONNECT_PS;
      strcpy (data_string, PSID);
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Enable normal messages on VM.                            */
/*************************************************************/
      strcpy (data_string, "set msg on@E");
      data_length = strlen(data_string);
      send_keys();

/*************************************************************/
/*  Wait for command to complete...                          */
/*************************************************************/
      function = HA_WAIT;
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Execute filelist on the host.                            */
/*************************************************************/
      function = HA_COPY_STR_TO_PS;
      strcpy (data_string, "filel");
      data_length = strlen(data_string);
      PS_POS = 1761;
      expected_return_code = 0;
      call_hllapi();

      strcpy (data_string, ENTER);
      data_length = strlen(data_string);
      send_keys();

/*************************************************************/
/*  Wait for command to complete...                          */
/*************************************************************/
      function = HA_WAIT;
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Did the file make it to the host?                        */
/*************************************************************/
      function = HA_SET_SESSION_PARMS;
      strcpy (data_string, "srchfrom");
      data_length = strlen(data_string);
      expected_return_code = 0;
      call_hllapi();

      function = HA_SEARCH_PS;
      strcpy (data_string, "AUTO");
      data_length = strlen(data_string);
      PS_POS = 161;
      expected_return_code = 0;
      call_hllapi();

/*************************************************************/
/*  Leave filelist.                                          */
/*************************************************************/
      strcpy (data_string, "@3");
      data_length = strlen(data_string);
      send_keys();
      return(0);
}


void send_keys()
/*************************************************************/
/*  Common sendkey routine.                                  */
/*************************************************************/
{
      function = HA_SENDKEY;
      expected_return_code = 0;
      call_hllapi();
}

void call_hllapi()
/*************************************************************/
/*  Call the hllapi and verify the return code.              */
/*************************************************************/
{
      hllapi (&function, data_string, &data_length, &return_code);

      if (return_code == 9 && function != HA_CONVERT_POS_ROW_COL)
      {
       function = HA_QUERY_SYSTEM;
       hllapi (&function, q_buffer, &data_length, &return_code);
       printf (blank_screen);
       printf ("%s\n",q_buffer);
       exit(9);
      }

   if ((return_code != expected_return_code) &&
       (expected_return_code != -1))
      {
       printf (blank_screen);             /* Clear the screen */
       printf ("Function               %d\n", function);
       printf ("Unexpected return code %d\n", return_code);
       printf ("Expected return code   %d\n", expected_return_code);
       printf ("Data string            %s\n", data_string);
      }
}
