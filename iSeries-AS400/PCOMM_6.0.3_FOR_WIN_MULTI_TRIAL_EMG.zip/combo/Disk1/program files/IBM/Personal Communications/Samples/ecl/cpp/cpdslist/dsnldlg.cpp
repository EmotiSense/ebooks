// DSNLevelDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cpdslist.h"
#include "dsnldlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDSNLevelDlg dialog


CDSNLevelDlg::CDSNLevelDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDSNLevelDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDSNLevelDlg)
	m_DSNLevel = _T("");
	//}}AFX_DATA_INIT
}


void CDSNLevelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDSNLevelDlg)
	DDX_Text(pDX, IDC_DSNLEVEL, m_DSNLevel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDSNLevelDlg, CDialog)
	//{{AFX_MSG_MAP(CDSNLevelDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDSNLevelDlg message handlers
