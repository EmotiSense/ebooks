//******************************************************************************
//
// LISTFILE.H - File containing all defines for application ListFile
//
//
//******************************************************************************

// Global function defines

int PASCAL      WinMain(HANDLE, HANDLE, LPSTR, int);

BOOL            RegisterApplicationClass( HANDLE );
BOOL            InitInstance( HANDLE, int );

long WINAPI     ListFileWndProc(HWND, UINT, WPARAM, LPARAM);
long WINAPI     FileListWndProc(HWND, UINT, WPARAM, LPARAM);

BOOL WINAPI     About(HWND, UINT, WPARAM, LPARAM);

BOOL            InitDDE( void );

void            ListDDEInitiate(  HWND, UINT, WPARAM, LPARAM );
void            ListDDEPoke(      HWND, UINT, WPARAM, LPARAM );
void            ListDDERequest(   HWND, UINT, WPARAM, LPARAM );
void            ListDDETerminate( HWND, UINT, WPARAM, LPARAM );

void            FileDDEAck(       HWND, UINT, WPARAM, LPARAM );
void            FileDDEData(      HWND, UINT, WPARAM, LPARAM );
void            FileDDETerminate( HWND, UINT, WPARAM, LPARAM );

void            Terminate( WORD ); // Terminate conv and/or application

//******************************************************************************
//
// Dialog Identifiers
//
//******************************************************************************

#define ID_ABOUT   5000
#define ID_SEND    5001
#define ID_RECV    5002
#define ID_CONV    5003
#define ID_IGNORE  5999

//******************************************************************************
//
// Resource Identifiers
//
//******************************************************************************

#define LISTMENU   9000
#define LISTICON   9001
#define ABOUTBOX   9002

//******************************************************************************
//
// Load String Identifiers
//
//******************************************************************************

#define LS_COMMAND_LINE_ERROR1  1
#define LS_TITLE_TEXT           2
#define LS_DDE_TOKENS           3
#define LS_16STR_FORMAT         5
#define LS_LISTFILE_COMMAND     6
#define LS_CLEARSCREEN_COMMAND  7

//******************************************************************************
//
// MISC
//
//******************************************************************************

#define uchar           unsigned char

#define DDE_GLOBAL  ( GHND | GMEM_DDESHARE | GMEM_MOVEABLE | GMEM_ZEROINIT )

#define DDE_ACK         0x8000
#define DDE_NACK        0x0000       /* Negative ACK          */
#define DDE_NACK_BUSY   0x4000       /* Negative ACK/BUSY     */

#define WC_PURETEXT     0
#define WC_HLLAPITEXT   1

#define SPACE_CHAR      ' '
#define NULL_CHAR       '\0'

#define PSDATA_ERROR    0
#define PSDATA_END      1
#define PSDATA_MORE     2
#define PSDATA_REREAD   3

#define SIZEOFFILENAME  21
#define MAXFILENAMES    100

#define APPLICATION            1
#define CONVERSATIONS          2
#define CONVERSATION_SESSION   3

//******************************************************************************
//
// typedef's used by listfile and session
//
//******************************************************************************
typedef struct tagGETLIST
{
  uchar     ddepoke[(sizeof(DDEPOKE)-1)];
  int       iSession;
  int       iSystem;
  char      DataSet[41];
  BYTE      Data[1];
} GETLIST;

typedef union tagDDE_GETLIST
{
  DDEPOKE     DDEpoke;
  GETLIST     DDEgetlist;
} DDE_GETLIST;

typedef DDE_GETLIST FAR *LPDDE_GETLIST;

typedef struct tagLISTFILES
{
  uchar     ddedata[(sizeof(DDEDATA)-1)];
  int       iItemsInList;
  USHORT    uFilenameWidth;
  BYTE      Data[1];
} LISTFILES;

typedef union tagDDE_LISTFILES
{
  DDEDATA     DDEdata;
  LISTFILES   DDElistfiles;
} DDE_LISTFILES;

typedef DDE_LISTFILES FAR *LPDDE_LISTFILES;

typedef struct tagXCOMMANDS         // Structure used to send keystrokes
{                                   // to the session via the DDE
  unsigned char zXCommands[129];    // EXECUTE (MACRO service
} XCOMMANDS, FAR *LPXCOMMANDS;

