#ifndef _PINGINFO_H_
#define _PINGINFO_H_

struct PingInfo {
  PingInfo();
  PingInfo(PingInfo const &pi);

  PingInfo& operator=(PingInfo const &pi);

  CString destination;
  CString tpName;
  CString mode;
  CString userID;
  CString password;

  DWORD packetSize;
  DWORD consecutivePackets;
  DWORD iterations;

  BOOL echo;
  BOOL security;
  BOOL verify;

};

#endif
