// mainfrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

class CWinapingDoc;
class CGoView;
class Aping;

class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
        CMainFrame();
        DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:
        BOOL          m_running;       // used to do CmdUI
        CWinapingDoc* pDoc;
        CGoView*      pView;
        Aping*        pRunningThread;

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CMainFrame)
        protected:
        virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
        //}}AFX_VIRTUAL

// Implementation
public:
        virtual ~CMainFrame();
#ifdef _DEBUG
        virtual void AssertValid() const;
        virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
        CStatusBar  m_wndStatusBar;
        CToolBar    m_wndToolBar;
        CTime       m_start_time;

// Generated message map functions
protected:
        //{{AFX_MSG(CMainFrame)
        afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
        afx_msg LONG OnApingDone(UINT, LONG);           // user msg handler
        afx_msg void OnActionGo();
        afx_msg void OnActionSetup();
        afx_msg void OnActionStop();
        afx_msg void OnUpdateActionGo(CCmdUI* pCmdUI);
        afx_msg void OnUpdateActionStop(CCmdUI* pCmdUI);
        afx_msg void OnUpdateActionSetup(CCmdUI* pCmdUI);
        //}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
