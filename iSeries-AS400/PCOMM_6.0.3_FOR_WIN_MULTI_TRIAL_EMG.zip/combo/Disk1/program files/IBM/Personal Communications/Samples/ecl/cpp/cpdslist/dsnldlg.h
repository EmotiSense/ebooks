// DSNLevelDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDSNLevelDlg dialog

class CDSNLevelDlg : public CDialog
{
// Construction
public:
	CDSNLevelDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDSNLevelDlg)
	enum { IDD = IDD_DSNAMELEVEL };
	CString	m_DSNLevel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDSNLevelDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDSNLevelDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
