// aping.h : header file
//

#ifndef _APING_H_
#define _APING_H_

class Aping
{
public:
        Aping();
        ~Aping();
        static UINT PingIt(LPVOID pParam);
};

#endif
