// ReplyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cpvmmail.h"
#include "ReplyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReplyDlg dialog


CReplyDlg::CReplyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CReplyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReplyDlg)
	m_ReplyText = _T("");
	//}}AFX_DATA_INIT
}


void CReplyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReplyDlg)
	DDX_Text(pDX, IDC_REPLYTEXT, m_ReplyText);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReplyDlg, CDialog)
	//{{AFX_MSG_MAP(CReplyDlg)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReplyDlg message handlers

void CReplyDlg::OnOK() 
{
	// Send my note 
  SendNote();
	
	CDialog::OnOK();
}

BOOL CReplyDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
  // Get my application handle and the ECL object handle
  m_pMyApp = (CCVMMailApp *)AfxGetApp();
  m_pECLSession = m_pMyApp->m_pECLSession;

  // Get the handle to the text box
  m_pReplyEditBox = (CEdit *)GetDlgItem(IDC_REPLYTEXT);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CReplyDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
  // Deselect all the text.  It gets selected b/c it is 1st in the
  // tab order.
  m_pReplyEditBox->SetSel(0, 0, FALSE);

}

void CReplyDlg::SendNote()
{
  // Update our member data with what the user entered in the text box
  UpdateData(TRUE);

  // Get to reply screen
  m_pECLSession->GetPS()->SendKeys("[pf6]");
  if ( !m_pMyApp->WaitForScreen("E42", "Reply To The Note", 500, 50) ) {
    AfxMessageBox("Couldn't get to the reply screen", MB_ICONEXCLAMATION);
    EndDialog(0);
  }

  // Put the reply text in the VM reply application
  CopyReplyToScreen();

  // Send the note
  m_pECLSession->GetPS()->SendKeys("[pf5]");
  if ( !m_pMyApp->WaitForScreen("V01", "Note", 500, 50) ) {
    AfxMessageBox("Couldn't get to the mail text screen", MB_ICONEXCLAMATION);
    EndDialog(0);
  }

  // Get back to mail list
  m_pECLSession->GetPS()->SendKeys("[pf12]");
  if ( !m_pMyApp->WaitForScreen("ML01", "In-Basket", 500, 50) ) {
    AfxMessageBox("Couldn't get to the mail screen", MB_ICONEXCLAMATION);
    EndDialog(0);
  }
}

void CReplyDlg::CopyReplyToScreen()
{
CString   WorkString(""), 
          EOLString("\r\n"), 
          SendString("");
int       ReplyLen, 
          NumReplyLines = 1, 
          PageLines, 
          EOLPos;

  // Turn of prefixing so our text will fit in the PS
  m_pECLSession->GetPS()->SendKeys("prefix off[enter]", 24, 7);
  m_pMyApp->WaitForInput(500, 50);
  m_pECLSession->GetPS()->SetCursorPos( 18, 1);

  // Send the keys to the PS
  WorkString = m_ReplyText;
  ReplyLen = m_ReplyText.GetLength();
  EOLPos = WorkString.Find(EOLString);
  while ( !WorkString.IsEmpty() ) {
    // Get the line of text to put on PS
    int EndLine = EOLPos;
    if ( EndLine <= 0 ) {
      SendString = " ";
    }
    else {
      SendString = WorkString.Mid(0, EndLine);
    }

    // Determine if a new page is needed
    if ( NumReplyLines == 4 ) {
      PageDown();
      PageLines = 1;
    }
    if ( PageLines == 8 ){
      PageDown();
      PageLines = 1;
    }

    // Put the string on the PS
    m_pECLSession->GetPS()->SetText(SendString);
    m_pECLSession->GetPS()->SendKeys("[tab]");

    // Bump up the indexes and get new EOL position
    PageLines++;
    NumReplyLines++;
    WorkString = WorkString.Mid(EOLPos + 2, ReplyLen);
    EOLPos = WorkString.Find(EOLString);
  }
}

void CReplyDlg::PageDown()
{
  m_pECLSession->GetPS()->SendKeys("[pf8]");
  m_pMyApp->WaitForInput(500, 50);
  m_pECLSession->GetPS()->SendKeys("[tab][tab]");

}
