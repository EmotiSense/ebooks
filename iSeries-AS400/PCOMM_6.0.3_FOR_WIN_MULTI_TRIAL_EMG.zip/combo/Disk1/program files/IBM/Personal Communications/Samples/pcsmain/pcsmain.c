/******************************************************************************
*                                                                             *
* File Name   : PCSMAIN.C                                                     *
*                                                                             *
* Descriptive name : PCSAPI Sample Program                                    *
*                                                                             *
* Author:  IBM                                                                *
* Date Written:  1996                                                         *
* For use with IBM Personal Communications/3270/5250 for Windows 95           *
*                                                                             *
* Notes:                                                                      *
*        This sample uses PCOM PCSAPI interface. 3270 or 5250 emulator can    *
*        be started/stopped with this program.                                *
*                                                                             *
* Compiler: MicroSoft Visual C++ version 2.2                                  *
*                                                                             *
* Required                                                                    *
*  header : pcsmain.h pcsapi.h pcsapi32.h                                     *
*  lib    : pcscal32.lib                                                      *
*                                                                             *
******************************************************************************/
/******************************************************************************
* Common header files                                                         *
******************************************************************************/
#include <windows.h>    // Windows definitions
#include <windowsx.h>   // Windows Macro APIs, window message crackers
#include <stdio.h>      // Standard IO
#include <string.h>     // String

/******************************************************************************
* Local header files                                                          *
******************************************************************************/
#include "pcsapi.h"
#include "pcsmain.h"

/*******************************************************************************
*                                                                              *
*   FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)                              *
*                                                                              *
*******************************************************************************/
int PASCAL WinMain (hInstance, hPrevInstance, lpszCmdLine, nCmdShow)
HANDLE   hInstance;
HANDLE   hPrevInstance;
LPSTR    lpszCmdLine;
int      nCmdShow;
{
   MSG         msg;
   WNDCLASS    wc;
   RECT        rectMain;
   char        szBuffer1[BUFFER_LENGTH] ;
   char        szBuffer2[BUFFER_LENGTH] ;

   if (!hPrevInstance)
   {
      LoadString(hInstance, LS_MENU, (LPSTR)szBuffer1, sizeof(szBuffer1));
      LoadString(hInstance, LS_CLASS, (LPSTR)szBuffer2, sizeof(szBuffer2));
      wc.style         = 0;
      wc.lpfnWndProc   = MainWndProc;
      wc.cbClsExtra    = 0;
      wc.cbWndExtra    = 0;
      wc.hInstance     = hInstance;
      wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(ICONPCSMAIN));
      wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
      wc.hbrBackground = GetStockObject (WHITE_BRUSH);
      wc.lpszMenuName  = (LPSTR)szBuffer1;
      wc.lpszClassName = (LPSTR)szBuffer2;

      if (!RegisterClass (&wc))
         return FALSE;
   }

   LoadString(hInstance, LS_TITLE, (LPSTR)szBuffer1, sizeof(szBuffer1));
   ghMainWnd = CreateWindow((LPSTR)szBuffer2,
                            (LPSTR)szBuffer1,
                            WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU |
                            WS_MINIMIZEBOX,
                            CW_USEDEFAULT,
                            CW_USEDEFAULT,
                            MAIN_WIDTH,
                            MAIN_HEIGHT,
                            NULL,
                            NULL,
                            hInstance,
                            NULL);

   if (!ghMainWnd)
       return FALSE;

   GetClientRect(ghMainWnd, &rectMain);

   LoadString(hInstance, LS_LISTBOX, (LPSTR)szBuffer1, sizeof(szBuffer1));
   ghListBox = CreateWindow((LPSTR)szBuffer1,
                            NULL,
                            WS_CHILD | WS_VSCROLL | WS_HSCROLL
                            | LBS_NOINTEGRALHEIGHT | WS_VISIBLE | LBS_NOTIFY,
                            0,
                            0,
                            rectMain.right - rectMain.left,
                            rectMain.bottom - rectMain.top,
                            ghMainWnd,
                            (HMENU)IDD_LIST,
                            hInstance,
                            NULL);

   if (!ghListBox)
      return FALSE;

   ShowWindow(ghMainWnd, nCmdShow);
   UpdateWindow(ghMainWnd);

   ghInst = hInstance;

   while (GetMessage (&msg, NULL, 0L, 0L))
   {
      TranslateMessage (&msg);
      DispatchMessage (&msg);
   }
   return msg.wParam;
}

/*******************************************************************************
*                                                                              *
*   FUNCTION: MainWndProc()                                                    *
*                                                                              *
*   PURPOSE:                                                                   *
*                                                                              *
*   This function handles messages belonging to the main window.               *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK MainWndProc(hWnd, iMessage, wParam, lParam)
HWND     hWnd;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   FARPROC  lpDialogProc;
   HANDLE   hMenu;

   switch (iMessage)
   {
      case WM_COMMAND:
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDM_FILE_ABOUT:
               lpDialogProc = MakeProcInstance (About, ghInst);
               DialogBox (ghInst,
                          MAKEINTRESOURCE(ABOUTBOX),
                          hWnd,
                          lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case IDM_FILE_TITLE:
               lpDialogProc = MakeProcInstance(TitleDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(TITLEBOX),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case  IDM_FILE_TOP:
               hMenu = GetMenu(hWnd);
               if (fTopmost)
               {
                  fTopmost = FALSE;
                  CheckMenuItem(hMenu, IDM_FILE_TOP, MF_UNCHECKED) ;
               }
               else
               {
                  fTopmost = TRUE;
                  CheckMenuItem(hMenu, IDM_FILE_TOP, MF_CHECKED) ;
               }
               SetWindowPos(hWnd, (fTopmost ? HWND_TOPMOST : HWND_NOTOPMOST),
                            0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE |
                            SWP_NOMOVE);
               break;

            case IDM_FILE_CLEAR:
               SendDlgItemMessage(hWnd, IDD_LIST, LB_RESETCONTENT, 0, 0L);
               break;

            case IDM_FILE_EXIT:
               PostMessage(hWnd, WM_CLOSE, 0, 0);
               break;

            case IDM_PCSAPI_START:
               lpDialogProc = MakeProcInstance(StartDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(START_DLG),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case IDM_PCSAPI_STOP:
               lpDialogProc = MakeProcInstance(StopDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(STOP_DLG),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case IDM_PCSAPI_STATUS:
               lpDialogProc = MakeProcInstance(StatusDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(STATUS_DLG),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case IDM_PCSAPI_PROFILE:
               lpDialogProc = MakeProcInstance(ProfileDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(PROF_DLG),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case IDM_PCSAPI_CONN:
               lpDialogProc = MakeProcInstance(ConnectDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(CONN_DLG),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case IDM_PCSAPI_DISCONN:
               lpDialogProc = MakeProcInstance(DisconnectDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(DISCONN_DLG),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            case IDM_PCSAPI_TIMEOUT:
               lpDialogProc = MakeProcInstance(SetLinkTimeoutDlgProc, ghInst);
               DialogBox(ghInst,
                         MAKEINTRESOURCE(TIMEOUT_DLG),
                         hWnd,
                         lpDialogProc);
               FreeProcInstance (lpDialogProc);
               break;

            default:
               return DefWindowProc (hWnd, iMessage, wParam, lParam);
         }
         break;

      case WM_DESTROY:
         PostQuitMessage (0);
         break;

      case WM_CREATE:
         // Check menu
         hMenu = GetMenu(hWnd) ;
         if (fTopmost)
         {
            CheckMenuItem(hMenu, IDM_FILE_TOP, MF_CHECKED) ;
            SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0,
                         SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
         }
         else
         {
            CheckMenuItem(hMenu, IDM_FILE_TOP, MF_UNCHECKED) ;
            SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0,
                         SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
         }
         break;

      default:
         return DefWindowProc (hWnd, iMessage, wParam, lParam);

   }
   return 0L;
}

/*******************************************************************************
*                                                                              *
*   FUNCTION: About()                                                          *
*                                                                              *
*   PURPOSE:                                                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK About(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   switch (iMessage)
   {
      case WM_INITDIALOG:
         return TRUE;

      case WM_COMMAND:
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:
            case IDCANCEL:
               EndDialog (hDlg, TRUE);
               return TRUE;

            default:
               break;
         }
   }
   return FALSE;
}

/*******************************************************************************
*                                                                              *
*   FUNCTION: TitleDlgProc                                                     *
*                                                                              *
*   PURPOSE:                                                                   *
*                                                                              *
*   This function handles messages belonging to the "Change Title" dialog box. *
*   It displays information of options.                                        *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK TitleDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   char  szTitle[TITLE_LEN];

   switch (iMessage)
   {
      case WM_INITDIALOG:
         GetWindowText(ghMainWnd, (LPSTR)szTitle, sizeof(szTitle)) ;
         SetDlgItemText(hDlg, IDD_TITLE, (LPSTR)szTitle) ;
         return TRUE;

      case WM_COMMAND:
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:
               GetDlgItemText(hDlg, IDD_TITLE, (LPSTR)szTitle,
                              sizeof(szTitle));
               SetWindowText(ghMainWnd, (LPSTR)szTitle);
               EndDialog (hDlg, TRUE);
               return TRUE;

            case IDCANCEL:
               EndDialog (hDlg, FALSE);
               return TRUE;

            default:
               break;
         }
   }
   return FALSE;
}

/*******************************************************************************
*                                                                              *
*  Name       : StartDlgProc                                                   *
*                                                                              *
*  Description: Processes all messages sent to the Start Session dialog.       *
*               This procedure use "pcsStartSession".                          *
*                                                                              *
*  Concepts : Called for each message sent to the Start Session dialog box.    *
*             A switch statement branches to the routines to be                *
*             performed for each message processed.  Any messages              *
*             not specifically process are passed to the default               *
*             window procedure DefDlgProc().                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK StartDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   ULONG    rc;                          /* Return code                   */
   SHORT    fuCmdShow;                   /* Session creation control flags*/
   CHAR     cShortSessionID[2];          /* Session ID                    */
   CHAR     message[332];                /* Message buffer                */
   CHAR     message1[80], message2[80];  /* Message buffer                */
   SYSTEMTIME DateTime;                  /* Time area                     */

   switch(iMessage)
   {
      case WM_INITDIALOG:
         SendDlgItemMessage(hDlg, DID_SESID, EM_LIMITTEXT, 1, 0L);
         SendDlgItemMessage(hDlg, DID_PRONAME, EM_LIMITTEXT, MAXPATHLEN-1, 0L);
         fuCmdShow = DID_SHOW;
         CheckRadioButton(hDlg,DID_VIS_GP, DID_SHOW_NO_ACT, fuCmdShow);
         SetDlgItemText(hDlg, DID_PRONAME, glpProfile);
         return (TRUE);

      case WM_COMMAND:                   /* Posted by pushbuttons         */
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:                 /* The 'Start Session' pushbutton*/
               GetDlgItemText(hDlg, DID_SESID, cShortSessionID, sizeof(cShortSessionID));
               GetDlgItemText(hDlg, DID_PRONAME, glpProfile, MAXPATHLEN);

               if (IsDlgButtonChecked(hDlg, DID_HIDE))
                 fuCmdShow = (SHORT)SW_HIDE;
               else if (IsDlgButtonChecked(hDlg, DID_SHOW_MIN))
                 fuCmdShow = (SHORT)SW_SHOWMINIMIZED;
               else if (IsDlgButtonChecked(hDlg, DID_SHOW_MAX))
                 fuCmdShow = (SHORT)SW_SHOWMAXIMIZED;
               else
                 fuCmdShow = (SHORT)SW_SHOWNORMAL;

               if(glpProfile[0] == 0x00)
               {
                  LoadString(ghInst, LS_NO_PROFILENAME, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }
               rc = pcsStartSession((PSZ)glpProfile,   /* Profile name     */
                                    *cShortSessionID, /* Session ID       */
                                         /* Session creation control flags*/
                                    fuCmdShow);

               if(rc != PCS_SUCCESSFUL)  /* pcsStartSession is failed.    */
               {
                  switch(rc)
                  {
                     case PCS_INVALID_ID:
                                         /* Invalid Session ID specified  */
                        LoadString(ghInst, LS_INVALID_SESSIONID, (LPSTR)message, sizeof(message));
                        break;

                     case PCS_USED_ID:
                                   /* Specified Session ID already active */
                        LoadString(ghInst, LS_ACTIVE_SESSIONID, (LPSTR)message, sizeof(message));
                        break;

                     case PCS_INVALID_PROFILE:
                                         /* Error found in Profile        */
                        LoadString(ghInst, LS_PROFILE_ERROR, (LPSTR)message, sizeof(message));
                        break;

                     case PCS_SYSTEM_ERROR:
                                         /* System error                  */
                        LoadString(ghInst, LS_SYSTEM_ERROR, (LPSTR)message, sizeof(message));
                        break;
                  }
               }
               else                      /* pcsStartSession is succeed.   */
               {
                  strcpy(message, "Session ");

                  strcat(message, cShortSessionID);

                  strcat(message, " started");
               }
               /*
                * Displays a message box containing an error message or
                * a successful message.
                */
               LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
               MessageBox(NULL,
                          message,
                          message2,
                          MB_OK);
               GetLocalTime(&DateTime);

               /*
                * Log message is edited.
                */
               sprintf(message,
                       "%02d:%02d : Start Session  Buffer = %s, Session ID = %s, Window option = %d, RC = %d",
                       DateTime.wHour,
                       DateTime.wMinute,
                       glpProfile,
                       cShortSessionID,
                       fuCmdShow,
                       rc );

               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_SETHORIZONTALEXTENT, (WPARAM)LISTBOX_MAXWIDTH, 0L);
               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_ADDSTRING, 0, (LPARAM)message);
               return (TRUE);
               break;

            case IDCANCEL:            /* The 'Exit' pushbutton          */
               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            default:
               break;
         }
         break;
   }
   return (FALSE);
} /* End of StartDlgProc */

/*******************************************************************************
*                                                                              *
*  Name       : StopDlgProc                                                    *
*                                                                              *
*  Description: Processes all messages sent to the Stop Session dialog.        *
*               This procedure use "pcsStopSession".                           *
*                                                                              *
*  Concepts : Called for each message sent to the Stop Session dialog box.     *
*             A switch statement branches to the routines to be                *
*             performed for each message processed.  Any messages              *
*             not specifically process are passed to the default               *
*             window procedure DefDlgProc().                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK StopDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   CHAR     cShortSessionID[2];          /* Session ID                    */
   SHORT    fuSaveProfile;               /* Saving profile option         */
   BOOL     brc;                         /* Return code                   */
   CHAR     rc[6];                       /* "TRUE" or "FALSE"             */
   CHAR     message[332];                /* Message buffer                */
   CHAR     message1[80], message2[80];  /* Message buffer                */
   SYSTEMTIME DateTime;                  /* Time area                     */
                                         /* Message box creation control  */
   switch(iMessage)
   {
      case WM_INITDIALOG:
         SendDlgItemMessage(hDlg, DID_SESID, EM_LIMITTEXT, 1, 0L);
         CheckRadioButton(hDlg,DID_SAVE_AS_PROFILE, DID_NOSAVE_ON_EXIT, DID_SAVE_AS_PROFILE);
         return (TRUE);

      case WM_COMMAND:                   /* Posted by pushbuttons         */
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:
               GetDlgItemText(hDlg, DID_SESID, cShortSessionID, sizeof(cShortSessionID));
               /*
                * If cShortSessionID is empty, displays a message box
                * containing an error message.
                */
               if(*cShortSessionID == 0x00
               || *cShortSessionID == ' ')
               {
                  LoadString(ghInst, LS_NO_SESSIONID, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }
               /*
                * Which of radio buttons are checked?
                */
               if (IsDlgButtonChecked(hDlg, DID_SAVE_AS_PROFILE))
                 fuSaveProfile = (SHORT)PCS_SAVE_AS_PROFILE;
               else if (IsDlgButtonChecked(hDlg, DID_SAVE_ON_EXIT))
                 fuSaveProfile = (SHORT)PCS_SAVE_ON_EXIT;
               else if (IsDlgButtonChecked(hDlg, DID_NOSAVE_ON_EXIT))
                 fuSaveProfile = (SHORT)PCS_NOSAVE_ON_EXIT;

               /*
                * Session is stoped.
                */
               brc = pcsStopSession(*cShortSessionID,
                                    fuSaveProfile);
               if(brc == FALSE)          /*  pcsStopSession is failed.    */
               {
                  LoadString(ghInst, LS_SESSION_CANNOTSTOP, (LPSTR)message, sizeof(message));

                  strcpy(rc, "FALSE");
               }
               else                      /* pcsStopSession is succeed.    */
               {
                  strcpy(message, "Session ");

                  strcat(message, cShortSessionID);

                  strcat(message, " stopped");

                  strcpy(rc, "TRUE");
               }
               /*
                * Displays a message box containing an error message or
                * a successful message.
                */
               LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
               MessageBox(NULL,
                          message,
                          message2,
                          MB_OK);
               GetLocalTime(&DateTime);

               /*
                * Log message is edited.
                */
               sprintf(message,
                       "%02d:%02d : Stop Session  Session ID = %s, Saving profile option = %d, RC = %s",
                       DateTime.wHour,
                       DateTime.wMinute,
                       cShortSessionID,
                       fuSaveProfile,
                       rc );

               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_SETHORIZONTALEXTENT, (WPARAM)LISTBOX_MAXWIDTH, 0L);
               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_ADDSTRING, 0, (LPARAM)message);
               return (TRUE);
               break;

            case IDCANCEL:
               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            default:
               break;
         }
         break;
   }
   return (FALSE);
} /* End of StopDlgProc */

/*******************************************************************************
*                                                                              *
*  Name       : StatusDlgProc                                                  *
*                                                                              *
*  Description: Processes all messages sent to the Query Emulater Status       *
*               dialog.                                                        *
*               This procedure use "pcsQueryEmulatorStatus".                   *
*                                                                              *
*  Concepts : Called for each message sent to the Query Emulater Status        *
*             dialog box.                                                      *
*             A switch statement branches to the routines to be                *
*             performed for each message processed.  Any messages              *
*             not specifically process are passed to the default               *
*             window procedure DefDlgProc().                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK StatusDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   CHAR     cShortSessionID[2];          /* Session ID                    */
   ULONG    rc;                          /* Return code                   */
   CHAR     message[332];                /* Message buffer                */
   CHAR     message1[80], message2[80];  /* Message buffer                */
   SYSTEMTIME DateTime;                  /* Time area                     */

   switch(iMessage)
   {
      case WM_INITDIALOG:
         SendDlgItemMessage(hDlg, DID_SESID, EM_LIMITTEXT, 1, 0L);
         return (TRUE);

      case WM_COMMAND:                   /* Posted by pushbuttons         */
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:
               GetDlgItemText(hDlg, DID_SESID, cShortSessionID, sizeof(cShortSessionID));

               if(*cShortSessionID == 0x00
               || *cShortSessionID == ' ')
               {
                  LoadString(ghInst, LS_NO_SESSIONID, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }
               /*
                * pcsQueryEmulatorStatus queries status of
                * 'cShortSessionID' session.
                */

               rc = pcsQueryEmulatorStatus(*cShortSessionID);

               /*
                * Displays a status of 'cShortSessionID' session.
                */
                                         /* Active or Inactive            */
               if((rc & PCS_SESSION_STARTED) != 0)
               {
                                         /* Set text "Active".            */
                  SetDlgItemText(hDlg,
                                 DID_STARTED,
                                 "Active" );

                                         /* Connected or Disconnected     */
                  if((rc & PCS_SESSION_ONLINE) != 0)
                                         /* Set text "Connected".         */
                      SetDlgItemText(hDlg,
                                     DID_ONLINE,
                                     "Connected");
                  else
                                         /* Set text "Disconnected".      */
                     SetDlgItemText(hDlg,
                                    DID_ONLINE,
                                    "Disconnected");

                                         /* Enabled or Disabled           */
                  if((rc & PCS_SESSION_API_ENABLED) != 0)
                                         /* Set text "Enabled".           */
                     SetDlgItemText(hDlg,
                                    DID_API_ENABLED,
                                    "Enabled");
                  else
                                         /* Set text "Disabled".          */
                     SetDlgItemText(hDlg,
                                    DID_API_ENABLED,
                                    "Disabled");
               }
               else
               {
                                         /* Set text "Inactive".          */
                  SetDlgItemText(hDlg,
                                 DID_STARTED,
                                 "Inactive");

                                         /* Clear text field.             */
                  SetDlgItemText(hDlg,
                                 DID_ONLINE,
                                 "");

                                         /* Clear text field.             */
                  SetDlgItemText(hDlg,
                                 DID_API_ENABLED,
                                 "");
               }

               GetLocalTime(&DateTime);

               /*
                * Log message is edited.
                */
               sprintf(message,
                       "%02d:%02d : Query Emulator Status  Session ID = %s, RC = %d",
                       DateTime.wHour,
                       DateTime.wMinute,
                       cShortSessionID,
                       rc);

               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_SETHORIZONTALEXTENT, (WPARAM)LISTBOX_MAXWIDTH, 0L);
               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_ADDSTRING, 0, (LPARAM)message);
               return (TRUE);
               break;

            case IDCANCEL:
               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            default:
               break;
         }
         break;
   }
   return (FALSE);
} /* End of cShortSessionID */

/*******************************************************************************
*                                                                              *
*  Name       : ProfileDlgProc                                                 *
*                                                                              *
*  Description: Processes all messages sent to the Query Workstation           *
*               Profile dialog.                                                *
*               This procedure use "pcsQueryWorkstationProfile".               *
*                                                                              *
*  Concepts : Called for each message sent to the Query Workstation            *
*             Profile dialog box.                                              *
*             A switch statement branches to the routines to be                *
*             performed for each message processed.  Any messages              *
*             not specifically process are passed to the default               *
*             window procedure DefDlgProc().                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK ProfileDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   CHAR     lpProfile[MAXPATHLEN];       /* Profile name                  */
   CHAR     cShortSessionID[2];          /* Session ID                    */
   BOOL     brc;                         /* Return code                   */
   CHAR     rc[6];                       /* "TRUE" or "FALSE"             */
   CHAR     message[332];                /* Message buffer                */
   CHAR     message1[80], message2[80];  /* Message buffer                */
   SYSTEMTIME DateTime;                  /* Time area                     */

   switch(iMessage)
   {
      case WM_INITDIALOG:
         SendDlgItemMessage(hDlg, DID_SESID, EM_LIMITTEXT, 1, 0L);
         return (TRUE);

      case WM_COMMAND:                   /* Posted by pushbuttons         */
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:                 /* The 'Start Session' pushbutton*/
               GetDlgItemText(hDlg, DID_SESID, cShortSessionID, sizeof(cShortSessionID));
               /*
                * If cShortSessionID is empty, displays a message box
                * containing an error message.
                */
               if(*cShortSessionID == 0x00
               || *cShortSessionID == ' ')
               {
                  LoadString(ghInst, LS_NO_SESSIONID, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }

               /*
                * pcsQueryWorkstationProfile queries profile
                * of 'cShortSessionID' session.
                */
               brc = pcsQueryWorkstationProfile(*cShortSessionID,
                                                (PSZ)lpProfile);
               if(brc == FALSE)
               {
                  /*
                   * Displays a message box containing an error message.
                   */
                  LoadString(ghInst, LS_SESSION_NOTSTARTED, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);

                  strcpy(rc, "FALSE");

                                         /* Clear entry field.            */
                  SetDlgItemText(hDlg, DID_PRONAME, "");

               }
               else
               {
                  strcpy(rc, "TRUE");

                  /*
                   * Displays the profile's name of session 'cShortSessionID'.
                   */
                  SetDlgItemText(hDlg,
                                 DID_PRONAME,
                                 lpProfile);
               }

               GetLocalTime(&DateTime);
               /*
                * Log message is edited.
                */
               sprintf(message,
                       "%02d:%02d : Query Workstation Profile  Session ID = %s, RC = %s",
                       DateTime.wHour,
                       DateTime.wMinute,
                       cShortSessionID,
                       rc);

               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_SETHORIZONTALEXTENT, (WPARAM)LISTBOX_MAXWIDTH, 0L);
               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_ADDSTRING, 0, (LPARAM)message);
               return (TRUE);
               break;

            case IDCANCEL:            /* The 'Exit' pushbutton          */
               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            default:
               break;
         }
         break;
   }
   return (FALSE);
} /* End of ProfileDlgProc */

/*******************************************************************************
*                                                                              *
*  Name       : ConnectDlgProc                                                 *
*                                                                              *
*  Description: Processes all messages sent to the Connect Session dialog.     *
*               This procedure use "pcsConnectSession".                        *
*                                                                              *
*  Concepts : Called for each message sent to the Connect Session dialog box.  *
*             A switch statement branches to the routines to be                *
*             performed for each message processed.  Any messages              *
*             not specifically process are passed to the default               *
*             window procedure DefDlgProc().                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK ConnectDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   CHAR     cShortSessionID[2];          /* Session ID                    */
   BOOL     brc;                         /* Return code                   */
   CHAR     rc[6];                       /* "TRUE" or "FALSE"             */
   CHAR     message[332];                /* Message buffer                */
   CHAR     message1[80], message2[80];  /* Message buffer                */
   SYSTEMTIME DateTime;                  /* Time area                     */

   switch(iMessage)
   {
      case WM_INITDIALOG:
         SendDlgItemMessage(hDlg, DID_SESID, EM_LIMITTEXT, 1, 0L);
         return (TRUE);

      case WM_COMMAND:                   /* Posted by pushbuttons         */
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:
               GetDlgItemText(hDlg, DID_SESID, cShortSessionID, sizeof(cShortSessionID));
               /*
                * If cShortSessionID is empty, displays a message box
                * containing an error message.
                */
               if(*cShortSessionID == 0x00
               || *cShortSessionID == ' ')
               {
                  LoadString(ghInst, LS_NO_SESSIONID, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }

               /*
                * Session is stoped.
                */
               brc = pcsConnectSession(*cShortSessionID);
               if(brc == FALSE)          /*  pcsConnectSession is failed. */
               {
                  LoadString(ghInst, LS_SESSION_NOTSTARTED, (LPSTR)message, sizeof(message));

                  strcpy(rc, "FALSE");
               }
               else                      /* pcsConnectSession is succeed.    */
               {
                  strcpy(message, "Session ");

                  strcat(message, cShortSessionID);

                  strcat(message, " connected");

                  strcpy(rc, "TRUE");
               }
               /*
                * Displays a message box containing an error message or
                * a successful message.
                */
               LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
               MessageBox(NULL,
                          message,
                          message2,
                          MB_OK);
               GetLocalTime(&DateTime);

               /*
                * Log message is edited.
                */
               sprintf(message,
                       "%02d:%02d : Connect Session  Session ID = %s, RC = %s",
                       DateTime.wHour,
                       DateTime.wMinute,
                       cShortSessionID,
                       rc );

               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_SETHORIZONTALEXTENT, (WPARAM)LISTBOX_MAXWIDTH, 0L);
               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_ADDSTRING, 0, (LPARAM)message);
               return (TRUE);
               break;

            case IDCANCEL:
               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            default:
               break;
         }
         break;
   }
   return (FALSE);
} /* End of ConnectDlgProc */

/*******************************************************************************
*                                                                              *
*  Name       : DisconnectDlgProc                                              *
*                                                                              *
*  Description: Processes all messages sent to the Disconnect Session dialog.  *
*               This procedure use "pcsConnectSession".                        *
*                                                                              *
*  Concepts : Called for each message sent to the Disconnect Session dialog box*
*             A switch statement branches to the routines to be                *
*             performed for each message processed.  Any messages              *
*             not specifically process are passed to the default               *
*             window procedure DefDlgProc().                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK DisconnectDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   CHAR     cShortSessionID[2];          /* Session ID                    */
   BOOL     brc;                         /* Return code                   */
   CHAR     rc[6];                       /* "TRUE" or "FALSE"             */
   CHAR     message[332];                /* Message buffer                */
   CHAR     message1[80], message2[80];  /* Message buffer                */
   SYSTEMTIME DateTime;                  /* Time area                     */

   switch(iMessage)
   {
      case WM_INITDIALOG:
         SendDlgItemMessage(hDlg, DID_SESID, EM_LIMITTEXT, 1, 0L);
         return (TRUE);

      case WM_COMMAND:                   /* Posted by pushbuttons         */
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:
               GetDlgItemText(hDlg, DID_SESID, cShortSessionID, sizeof(cShortSessionID));
               /*
                * If cShortSessionID is empty, displays a message box
                * containing an error message.
                */
               if(*cShortSessionID == 0x00
               || *cShortSessionID == ' ')
               {
                  LoadString(ghInst, LS_NO_SESSIONID, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }

               /*
                * Session is stoped.
                */
               brc = pcsDisconnectSession(*cShortSessionID);
               if(brc == FALSE)          /*  pcsConnectSession is failed. */
               {
                  LoadString(ghInst, LS_SESSION_NOTSTARTED, (LPSTR)message, sizeof(message));

                  strcpy(rc, "FALSE");
               }
               else                      /* pcsConnectSession is succeed.    */
               {
                  strcpy(message, "Session ");

                  strcat(message, cShortSessionID);

                  strcat(message, " disconnected");

                  strcpy(rc, "TRUE");
               }
               /*
                * Displays a message box containing an error message or
                * a successful message.
                */
               LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
               MessageBox(NULL,
                          message,
                          message2,
                          MB_OK);
               GetLocalTime(&DateTime);

               /*
                * Log message is edited.
                */
               sprintf(message,
                       "%02d:%02d : Disconnect Session  Session ID = %s, RC = %s",
                       DateTime.wHour,
                       DateTime.wMinute,
                       cShortSessionID,
                       rc );

               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_SETHORIZONTALEXTENT, (WPARAM)LISTBOX_MAXWIDTH, 0L);
               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_ADDSTRING, 0, (LPARAM)message);
               return (TRUE);
               break;

            case IDCANCEL:
               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            default:
               break;
         }
         break;
   }
   return (FALSE);
} /* End of DisconnectDlgProc */

/*******************************************************************************
*                                                                              *
*  Name       : SetLinkTimeoutDlgProc                                          *
*                                                                              *
*  Description: Processes all messages sent to the Set Link Timeout dialog.    *
*               This procedure use "pcsSetLinkTimeout".                        *
*                                                                              *
*  Concepts : Called for each message sent to the Set Link Timeout             *
*             dialog box.                                                      *
*             A switch statement branches to the routines to be                *
*             performed for each message processed.  Any messages              *
*             not specifically process are passed to the default               *
*             window procedure DefDlgProc().                                   *
*                                                                              *
*******************************************************************************/
LRESULT CALLBACK SetLinkTimeoutDlgProc(hDlg, iMessage, wParam, lParam)
HWND     hDlg;
UINT     iMessage;
WPARAM   wParam;
LPARAM   lParam;
{
   CHAR     cTimeoutValue[3];            /* Timeout value                 */
   CHAR     cShortSessionID[2];          /* Session ID                    */
   WORD     fuTimeoutValue;              /* Timeout value                 */
   ULONG    rc;                          /* Return code                   */
   CHAR     message[332];                /* Message buffer                */
   CHAR     message1[80], message2[80];  /* Message buffer                */
   SYSTEMTIME DateTime;                  /* Time area                     */

   switch(iMessage)
   {
      case WM_INITDIALOG:
         SendDlgItemMessage(hDlg, DID_SESID, EM_LIMITTEXT, 1, 0L);
         SendDlgItemMessage(hDlg, DID_TIMEOUTVALUE, EM_LIMITTEXT, 2, 0L);
         return (TRUE);

      case WM_COMMAND:                   /* Posted by pushbuttons         */
         switch (GET_WM_COMMAND_ID(wParam,lParam))
         {
            case IDOK:                /* The 'Set Link Timeout' pushbutton*/
               GetDlgItemText(hDlg, DID_SESID, cShortSessionID, sizeof(cShortSessionID));
               /*
                * If cShortSessionID is empty, displays a message box
                * containing an error message.
                */
               if(*cShortSessionID == 0x00
               || *cShortSessionID == ' ')
               {
                  LoadString(ghInst, LS_NO_SESSIONID, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }

               GetDlgItemText(hDlg, DID_TIMEOUTVALUE, cTimeoutValue, sizeof(cTimeoutValue));

               /*
                * Strips off leading and trailing blanks in cTimeoutValue
                */ 
               if(cTimeoutValue[0] == ' ')
               {
                  cTimeoutValue[0] = cTimeoutValue[1];
                  cTimeoutValue[1] = 0x00;
               }
               if(cTimeoutValue[0] != 0x00
               && cTimeoutValue[1] == ' ')
               {
                  cTimeoutValue[1] = 0x00;
               } 

               /*
                * If cTimeoutValue is empty, displays a message box
                * containing an error message.
                */
               if(*cTimeoutValue == 0x00)
               {
                  LoadString(ghInst, LS_NO_TIMEOUTVALUE, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }

               /*
                * If cTimeoutValue is invalid, displays a message box
                * containing an error message.
                */
               if(strspn(cTimeoutValue, "0123456789") != strlen(cTimeoutValue))
               {
                  LoadString(ghInst, LS_INVALID_TIMEOUTVALUE, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);
                  return (TRUE);
                  break;
               }

               /*
                * pcsSetLinkTimeout sets the link timeout
                * of 'cShortSessionID' session.
                */
               fuTimeoutValue = atoi(cTimeoutValue);
               rc = pcsSetLinkTimeout(*cShortSessionID,
                                      fuTimeoutValue);
               if(rc != 0)
               {
                  /*
                   * Displays a message box containing an error message.
                   */
                  LoadString(ghInst, LS_TIMEOUT_ERROR, (LPSTR)message1, sizeof(message1));
                  LoadString(ghInst, LS_SAMPLE_PROGRAM, (LPSTR)message2, sizeof(message2));
                  MessageBox(NULL,
                             message1,
                             message2,
                             MB_OK);

                                         /* Clear entry field.            */
                  SetDlgItemText(hDlg, DID_TIMEOUTVALUE, "");

               }

               GetLocalTime(&DateTime);
               /*
                * Log message is edited.
                */
               sprintf(message,
                       "%02d:%02d : Set Link Timeout  Session ID = %s, RC = %d",
                       DateTime.wHour,
                       DateTime.wMinute,
                       cShortSessionID,
                       rc);

               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_SETHORIZONTALEXTENT, (WPARAM)LISTBOX_MAXWIDTH, 0L);
               SendDlgItemMessage(ghMainWnd, IDD_LIST, LB_ADDSTRING, 0, (LPARAM)message);
               return (TRUE);
               break;

            case IDCANCEL:            /* The 'Exit' pushbutton          */
               EndDialog(hDlg, TRUE);
               return (TRUE);
               break;

            default:
               break;
         }
         break;
   }
   return (FALSE);
} /* End of SetLinkTimeoutDlgProc */

