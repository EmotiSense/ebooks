Emulator Class Library sample - CPDSLIST
----------------------------------------

Description:
------------

This is a sample ECL application which implements a GUI front in to ISPF Dataset
browsing.  It will view the first page (80 columns only) of the dataset.  


Building the program:
---------------------


  Microsoft Visual C++ Version 4.2
  --------------------------------

  A Visual Studio project file is provided for building the sample from
  the Visual Studio application.  To load the project file into the
  Visual Studio:

     File -> Open Workspace

  Load the CPDSLIST.MDB file in this directory.  If the sample is moved
  from the default installation location, the project settings will need
  to be modified to point to the proper PComm directories.  To do this,
  modify the following in the Build -> Settings:

    "Additional include directories" on the C/C++ tab ("Preprocessor")
    "Object/library modules" on the Link tab

  To build the sample, select Build -> Rebuild All.  The resulting
  executable file (CPDSLIST.EXE) will be placed in the "Debug"
  subdirectory.
