Emulator Class Library sample - ECLSAMPS
----------------------------------------

Description:
------------

This is a collection of all the sample code that appears in the C++ chapter
of the Emulator Class Library document (SC31-8527-00).  Each sample is
a function of the form "SampleXXX".  A main driver routine is provided which
will prompt for a sample number and run the corresponding function.

This is a command-line program.

Building the program:
---------------------

A working executable (.EXE) file is provided so the program can be run
without the use of a development environment.  To build the program,
install a supported development environment and follow the instructions 
below:

  IBM VisualAge C++ for OS2 or Windows
  ------------------------------------

  A "make" file is provided for building the sample from a command
  line.  If the sample is moved from the default installation location,
  the make file will need to be modified to point to the proper
  PComm directories.  See the comments in the "MAKEFILE" file.

  To build the sample program, issue the following command:

     nmake /a all

  The resulting executable (ECLSAMPS.EXE) will be placed in the
  current directory.

  Microsoft Visual C++ Version 4.2 (Win32 only)
  ---------------------------------------------

  A Visual Studio project file is provided for building the sample from
  the Visual Studio application.  To load the project file into the
  Visual Studio:

     File -> Open Workspace

  Load the ECLSAMPS.DSP file in this directory.  If the sample is moved
  from the default installation location, the project settings will need
  to be modified to point to the proper PComm directories.  To do this,
  modify the following in the Build -> Settings:

    "Additional include directories" on the C/C++ tab ("Preprocessor")
    "Object/library modules" on the Link tab

  To build the sample, select Build -> Rebuild All.  The resulting
  executable file (ECLSAMPS.EXE) will be placed in the "Debug"
  subdirectory.
