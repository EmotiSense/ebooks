// ConnectionsDLG.h : header file
//

#include "eclall.hpp"


/////////////////////////////////////////////////////////////////////////////
// CConnectionsDLG dialog

class CConnectionsDLG : public CDialog
{
friend class ConnEvent;

private:
  ECLConnMgr  m_ConnMgr;
  CListBox    *m_pMyConnListBox;

public:
	CConnectionsDLG(CWnd* pParent = NULL);   // standard constructor
  void RefreshConnList();

// Dialog Data
	//{{AFX_DATA(CConnectionsDLG)
	enum { IDD = IDD_CONNECTIONS };
	CString	m_ConnName;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnectionsDLG)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConnectionsDLG)
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnRefresh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
