/*****************************************************************************/
/*                                                                           */
/*  Copyright Notice: IBM Personal Communication/3270 Version 4.2            */
/*                    (C) COPYRIGHT IBM CORP. 1997 - PROGRAM PROPERTY        */
/*                    OF IBM ALL RIGHTS RESERVED                             */
/*                                                                           */
/* Changes:                                                                  */
/*   07/24/98 - Added more error checking to samples 3, 29, 45, 58.          */
/*D1 03/02/04 - def91466_f9:Added samples for ECL Printer and Page Setup     */
/*                                                                           */
/*****************************************************************************/
// This file contains the sample code from the C++ chapter of
// the Emulator Class Library programming manual.  The samples
// can be run by compiling and executing this program.  The
// program will prompt for the sample number and will run the
// corresponding "SampleX()" function.  All input and output
// is command-line (console).
//
// This sample application can be built with IBM VisualAge C++ using the
// MAKEFILE provided (OS/2 and Win32), or with Microsoft Visual C++ V4.2
// Developer Studio using the supplied project workspace file (ECLSAMPS.MDP).

#include <stdio.h>          // C language header
#include <string.h>         // String library functions
#define INCL_DOSPROCESS
#include "eclall.hpp"       // Emulator Class Library

// Some platform mappings.  Note that OS2 and WIN are defined by ECLOPSYS.HPP.
#if defined(OS2)
  #define Sleep             DosSleep
  #define HANDLE            PVOID
#endif

#if defined(WIN)
  #include <windows.h>
#endif

void Sample108();           //@D1a
void Sample109();           //@D1a
void Sample110();           //@D1a
void Sample110();           //@D1a
void Sample111();           //@D1a
void Sample112();           //@D1a
void Sample113();           //@D1a
void Sample114();           //@D1a
void Sample115();           //@D1a
void Sample116();           //@D1a 
void Sample117();           //@D1a
void Sample118();           //@D1a
void Sample119();           //@D1a
void Sample120();           //@D1a
void Sample121();           //@D1a 
void Sample122();           //@D1a
void Sample123();           //@D1a
void Sample124();           //@D1a
void Sample125();           //@D1a

ULONG LoopCnt;

//-------------------------------------------------------------------
// ECLBase::GetVersion
//-------------------------------------------------------------------
void Sample2() {

if (ECLBase::GetVersion() >= 200) {
  printf("Running version 2.0 or later.\n");
}
else {
  printf("Running version 1.XX\n");
}

} // end sample

//-------------------------------------------------------------------
// ECLBase::ConvertHandle2ShortName
//-------------------------------------------------------------------
void Sample3() {

ECLConnList  ConnList;
long Handle;
char Name;

// Print connection name of first connection in the
// connection list.
ECLConnection *Connection = ConnList.GetFirstConnection();
if (Connection != NULL) {
  Handle = Connection->GetHandle();
  Name = ConnList.ConvertHandle2ShortName(Handle);
  printf("Name of first connection is: %c \n", Name);
}
else printf("There are no connections.\n");

} // end sample

//-------------------------------------------------------------------
// ECLBase::ConvertShortName2Handle
//-------------------------------------------------------------------
void Sample4() {

ECLConnList  ConnList;
long Handle;
char Name;

Name = 'A';
Handle = ConnList.ConvertShortName2Handle(Name);
printf("Handle of connection A is: 0x%lx \n", Handle);

} // end sample

//-------------------------------------------------------------------
// ECLBase::ConvertTypeToString
//-------------------------------------------------------------------
void Sample5() {

ECLConnection  *pConn;
char           TypeString[21];

pConn = new ECLConnection('A');

pConn->ConvertTypeToString(pConn->GetConnType(), TypeString);
// Could also use:
// ECLBase::ConvertTypeToString(pConn->GetConnType(), TypeString);

printf("Session A is a %s \n", TypeString);

delete pConn;

} // end sample



//-------------------------------------------------------------------
// ECLBase::ConvertPos
//-------------------------------------------------------------------
void Sample6() {

ECLPS     *pPS;
ULONG     NumRows, NumCols, Row, Col;

try {
  pPS = new ECLPS('A');

  pPS->GetSize(&NumRows, &NumCols);  // Get height and width of PS

  // Get row/column coordinate of position 81
  ECLBase::ConvertPos(81, &Row, &Col, NumCols);
  printf("Position 81 is row %lu, column %lu \n", Row, Col);

  delete pPS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample


//-------------------------------------------------------------------
// ECLConnection::ECLConnection    (Constructor)
//
// Create two connection objects for connection 'A', one created
// by name, the other by handle.
//-------------------------------------------------------------------
void Sample7() {

ECLConnection 		*pConn1, *pConn2;
long              Hand;

try {
  pConn1  = new ECLConnection('A');
  Hand    = pConn1->GetHandle();
  pConn2  = new ECLConnection(Hand);  // Another ECLConnection for 'A'

  printf("Conn1 is for connection %c, Conn2 is for connection %c.\n",
         pConn1->GetName(), pConn2->GetName());

  delete pConn1;  // Call destructors
  delete pConn2;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::~ECLConnection    (Destructor)
//
// Create two connection objects, then delete both of them.
//-------------------------------------------------------------------
void Sample8() {

ECLConnection 		*pConn1, *pConn2;
long              Hand;

try {
  pConn1  = new ECLConnection('A');
  Hand    = pConn1->GetHandle();
  pConn2  = new ECLConnection(Hand);  // Another ECLConnection for 'A'

  printf("Conn1 is for connection %c, Conn2 is for connection %c.\n",
         pConn1->GetName(), pConn2->GetName());

  delete pConn1;  // Call destructors
  delete pConn2;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::GetHandle
//
// Get the handle of connection 'A' and use it to create another
// connection object.
//-------------------------------------------------------------------
void Sample9() {

ECLConnection 		*pConn1, *pConn2;
long              Hand;

try {
  pConn1  = new ECLConnection('A');
  Hand    = pConn1->GetHandle();
  pConn2  = new ECLConnection(Hand);  // Another ECLConnection for 'A'

  printf("Conn1 is for connection %c, Conn2 is for connection %c.\n",
         pConn1->GetName(), pConn2->GetName());

  delete pConn1;  // Call destructors
  delete pConn2;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::GetConnType
//
// Find the first 3270 display connection in the current list of
// all connections.
//-------------------------------------------------------------------
void Sample10() {

ULONG      i;             // Connection counter
ECLConnList ConnList;     // Connection list object
ECLConnection *Info=NULL; // Pointer to connection object

for (i=0; i<ConnList.GetCount(); i++) {

  Info = ConnList.GetNextConnection(Info);
  if (Info->GetConnType() == HOSTTYPE_3270DISPLAY) {
    // Found the first 3270 display connection
    printf("First 3270 display connection is '%c'.\n",
            Info->GetName());
    return;
  }

} // for
printf("Found no 3270 display connections.\n");

} // end sample

//-------------------------------------------------------------------
// ECLConnection::GetName
//
// Find the first 3270 display connection in the current list of
// all connections and display its name (PComm session ID).
//-------------------------------------------------------------------
void Sample11() {

ULONG      i;             // Connection counter
ECLConnList ConnList;     // Connection list object
ECLConnection *Info=NULL; // Pointer to connection object

for (i=0; i<ConnList.GetCount(); i++) {

  Info = ConnList.GetNextConnection(Info);
  if (Info->GetConnType() == HOSTTYPE_3270DISPLAY) {
    // Found the first 3270 display connection, display the name
    printf("First 3270 display connection is '%c'.\n",
            Info->GetName());
    return;
  }

} // for
printf("Found no 3270 display connections.\n");

} // end sample


//-------------------------------------------------------------------
// ECLConnection::IsStarted
//
// Display list of all started connections.  Note they may or may
// not be communications-connected to a host, and may or may not
// be visible on the screen.
//-------------------------------------------------------------------
void Sample12() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object

// Print list of started connections

for (Info = ConnList.GetFirstConnection();
     Info != NULL;
     Info = ConnList.GetNextConnection(Info)) {

  if (Info->IsStarted())
    printf("Connection %c is started.\n", Info->GetName());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::IsCommStarted
//
// Display list of all started connections which are currently
// in communications with a host.
//-------------------------------------------------------------------
void Sample13() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object

for (Info = ConnList.GetFirstConnection();
     Info != NULL;
     Info = ConnList.GetNextConnection(Info)) {

  if (Info->IsCommStarted())
    printf("Connection %c is connected to a host.\n", Info->GetName());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::IsAPIEnabled
//
// Display list of all started connections which have APIs enabled.
//-------------------------------------------------------------------
void Sample14() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object

for (Info = ConnList.GetFirstConnection();
     Info != NULL;
     Info = ConnList.GetNextConnection(Info)) {

  if (Info->IsAPIEnabled())
    printf("Connection %c has APIs enabled.\n", Info->GetName());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::IsReady
//
// Display list of all connections which are started, comm-connected
// to a host, and have APIs enabled.
//-------------------------------------------------------------------
void Sample15() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object

for (Info = ConnList.GetFirstConnection();
     Info != NULL;
     Info = ConnList.GetNextConnection(Info)) {

  if (Info->IsReady())
    printf("Connection %c is ready (started, comm-connected, API enabled).\n", Info->GetName());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::GetCodePage
//
// Display host code page for each ready connection.
//-------------------------------------------------------------------
void Sample16() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object

for (Info = ConnList.GetFirstConnection();
     Info != NULL;
     Info = ConnList.GetNextConnection(Info)) {

  if (Info->IsReady())
    printf("Connection %c is configured for host code page %u.\n",
            Info->GetName(), Info->GetCodePage());
}

} // end sample


//-------------------------------------------------------------------
// ECLConnection::StartCommunication
//
// Start communications link for any connection which is currently
// not comm-connected to a host.
//-------------------------------------------------------------------
void Sample17() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object

for (Info = ConnList.GetFirstConnection();
     Info != NULL;
     Info = ConnList.GetNextConnection(Info)) {

  if (!(Info->IsCommStarted())) {
    printf("Starting comm-link for connection %c...\n", Info->GetName());
    Info->StartCommunication();
  }
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::StopCommunication
//
// Stop comm-link for any connection which is currently connected
// to a host.
//-------------------------------------------------------------------
void Sample18() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object

for (Info = ConnList.GetFirstConnection();
     Info != NULL;
     Info = ConnList.GetNextConnection(Info)) {

  if (Info->IsCommStarted()) {
    printf("Stopping comm-link for connection %c...\n", Info->GetName());
    Info->StopCommunication();
  }
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::RegisterCommEvent
//
// See ECLCommNotify class for sample.
//-------------------------------------------------------------------

//-------------------------------------------------------------------
// ECLConnection::UnregisterCommEvent
//
// See ECLCommNotify class for sample.
//-------------------------------------------------------------------


//-------------------------------------------------------------------
// ECLConnList::ECLConnList        (Constructor)
//
// Dynamically construct a connection list object, display number
// of connections in the list, then delete the list.
//-------------------------------------------------------------------
void Sample19() {

ECLConnList *pConnList;  // Pointer to connection list object

try {
  pConnList = new ECLConnList();
  printf("There are %lu connections in the connection list.\n",
         pConnList->GetCount());

  delete pConnList;  // Call destructor
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnList::~ECLConnList        (Destructor)
//
// Dynamically construct a connection list object, display number
// of connections in the list, then delete the list.
//-------------------------------------------------------------------
void Sample20() {

ECLConnList *pConnList;  // Pointer to connection list object

try {
  pConnList = new ECLConnList();
  printf("There are %lu connections in the connection list.\n",
         pConnList->GetCount());

  delete pConnList;  // Call destructor
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample


//-------------------------------------------------------------------
// ECLConnection::GetFirstConnection
//
// Iterate over list of connections and display information about
// each one.
//-------------------------------------------------------------------
void Sample21() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object
char TypeString[21];     // Type of connection

for (Info = ConnList.GetFirstConnection();       // Get first one
     Info != NULL;                               // While there is one
     Info = ConnList.GetNextConnection(Info)) {  // Get next one

  ECLBase::ConvertTypeToString(Info->GetConnType(), TypeString);
  printf("Connection %c is a %s type connection.\n",
         Info->GetName(), TypeString);
}

} // end sample


//-------------------------------------------------------------------
// ECLConnection::GetNextConnection
//
// Iterate over list of connections and display information about
// each one.
//-------------------------------------------------------------------
void Sample22() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object
char TypeString[21];     // Type of connection

for (Info = ConnList.GetFirstConnection();       // Get first one
     Info != NULL;                               // While there is one
     Info = ConnList.GetNextConnection(Info)) {  // Get next one

  ECLBase::ConvertTypeToString(Info->GetConnType(), TypeString);
  printf("Connection %c is a %s type connection.\n",
         Info->GetName(), TypeString);
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::FindConnection
//
// Find connection 'B' in the list of connections.  If found, display
// its type.
//-------------------------------------------------------------------
void Sample23() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object
char TypeString[21];     // Type of connection

Info = ConnList.FindConnection('B');  // Find connection by name
if (Info != NULL) {

  ECLBase::ConvertTypeToString(Info->GetConnType(), TypeString);
  printf("Connection 'B' is a %s type connection.\n",
          TypeString);
}
else printf("Connection 'B' not found.\n");

} // end sample

//-------------------------------------------------------------------
// ECLConnList::GetCount
//
// Dynamically construct a connection list object, display number
// of connections in the list, then delete the list.
//-------------------------------------------------------------------
void Sample24() {

ECLConnList *pConnList;  // Pointer to connection list object

try {
  pConnList = new ECLConnList();
  printf("There are %lu connections in the connection list.\n",
         pConnList->GetCount());

  delete pConnList;  // Call destructor
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnection::Refresh
//
// Loop-and-wait until connection 'B' is started.
//-------------------------------------------------------------------
void Sample25() {

ECLConnection *Info;     // Pointer to connection object
ECLConnList ConnList;	   // Connection list object
int i;

printf("Waiting up to 60 seconds for connection B to start...\n");
for (i=0; i<60; i++) {   // Limit wait to 60 seconds
  ConnList.Refresh();    // Refresh the connection list
  Info = ConnList.FindConnection('B');
  if ((Info != NULL) && (Info->IsStarted())) {
    printf("Connection B is now started.\n");
    return;
  }
  Sleep(1000L);          // Wait 1 second and try again
}

printf("Connection 'B' not started after 60 seconds.\n");

} // end sample

//-------------------------------------------------------------------
// ECLConnMgr::ECLConnMgr          (Constructor)
//
// Create a connection mangager object, start a new connection,
// then delete the manager.
//-------------------------------------------------------------------
void Sample26() {

ECLConnMgr			*pCM; // Pointer to connection manager object

try {
  pCM = new ECLConnMgr();  // Create connection manager
  pCM->StartConnection("profile=coax connname=e");
  printf("Connection 'E' started with COAX profile.\n");
  delete pCM;              // Delete connection manager
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnMgr::~ECLConnMgr          (Destructor)
//
// Create a connection mangager object, start a new connection,
// then delete the manager.
//-------------------------------------------------------------------
void Sample27() {

ECLConnMgr			*pCM; // Pointer to connection manager object

try {
  pCM = new ECLConnMgr();  // Create connection manager
  pCM->StartConnection("profile=coax connname=e");
  printf("Connection 'E' started with COAX profile.\n");
  delete pCM;              // Delete connection manager
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLConnMgr::GetConnList
//
// Use connection manager's connection list object to display
// number of connections (see also ECLConnList::GetCount).
//-------------------------------------------------------------------
void Sample28() {

ECLConnMgr			CM; // Connection manager object

printf("There are %lu connections in the connection list.\n",
       CM.GetConnList()->GetCount());

} // end sample

//-------------------------------------------------------------------
// ECLConnMgr::StopConnection
//
// Stop the first connection in the connection list.
//-------------------------------------------------------------------
void Sample29() {

ECLConnMgr			CM; // Connection manager object

if (CM.GetConnList()->GetCount() > 0) {

  printf("Stopping connection %c.\n",
         CM.GetConnList()->GetFirstConnection()->GetName());

  CM.StopConnection(
    CM.GetConnList()->GetFirstConnection()->GetHandle(),
    "saveprofile=no");
}
else printf("No connections to stop.\n");


} // end sample

//-------------------------------------------------------------------
// ECLConnMgr::RegisterStartEvent
//
// See ECLStartNotify class for example.
//-------------------------------------------------------------------

//-------------------------------------------------------------------
// ECLConnMgr::UnregisterStartEvent
//
// See ECLStartNotify class for example.
//-------------------------------------------------------------------


//-------------------------------------------------------------------
// ECLCommNotify class
//
// This sample demonstrates the use of:
//
// ECLCommNotify::NotifyEvent
// ECLCommNotify::NotifyError
// ECLCommNotify::NotifyStop
// ECLConnection::RegisterCommEvent
// ECLConnection::UnregisterCommEvent
//-------------------------------------------------------------------

//...................................................................
// Define a class derived from ECLCommNotify
//...................................................................
class MyCommNotify: public ECLCommNotify
{
public:
  // Define my own constructor to store instance data
  MyCommNotify(HANDLE DataHandle);

  // We have to implement this function
  void	NotifyEvent(ECLConnection *ConnObj, BOOL Connected);

  // We choose to implement this function
  void NotifyStop (ECLConnection *ConnObj, int Reason);

  // We will take the default behaviour for this so we
  // don't implement it in our class:
  // void NotifyError (ECLConnection *ConnObj, ECLErr ErrObject);

private:
  // We will store our application data handle here
  HANDLE MyDataH;
};

//...................................................................
MyCommNotify::MyCommNotify(HANDLE DataHandle)   // Constructor
//...................................................................
{
  MyDataH = DataHandle;  // Save data handle for later use
}

//...................................................................
void MyCommNotify::NotifyEvent(ECLConnection *ConnObj,
                           BOOL Connected)
//
// This function is called whenever the communications link
// with the host connects or disconnects.
//
// For this example, we will just write a message.  Note that we
// have access the the MyDataH handle which could have application
// instance data if we needed it here.
//
// The ConnObj pointer is to the ECLConnection object upon which
// this event was registered.
//...................................................................
{
  if (Connected)
    printf("Connection %c is now connected.\n", ConnObj->GetName());
  else
    printf("Connection %c is now disconnected.\n", ConnObj->GetName());

  return;
}

//...................................................................
void MyCommNotify::NotifyStop(ECLConnection *ConnObj,
                         int Reason)
//...................................................................
{
  // When notification ends, display message
  printf("Comm link monitoring for %c stopped.\n", ConnObj->GetName());
}

//...................................................................
// Create the class and start notification on connection 'A'.
//...................................................................
void Sample30() {

ECLConnection *Conn;    // Ptr to connection object
MyCommNotify *Event;    // Ptr to my event handling object
HANDLE InstData = NULL;	// Handle to application data block (for example)

try {
  Conn = new ECLConnection('A');         // Create connection obj
  Event = new MyCommNotify(InstData);    // Create event handler

  Conn->RegisterCommEvent(Event);        // Register for comm events

  // At this point, any comm link event will cause the
  // MyCommEvent::NotifyEvent() function to execute.  For
  // this sample, we put this thread to sleep during this 
  // time.

  printf("Monitoring comm link on 'A' for 60 seconds...\n");
  Sleep(60000);

  // Now stop event generation.  This will cause the NotifyStop
  // member to be called.
  Conn->UnregisterCommEvent(Event);

  delete Event;  // Don't delete until after unregister!
  delete Conn;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample


//-------------------------------------------------------------------
// ECLErr::GetMsgNumber
//
// Cause an 'invalid parameters' error and tryp the ECL exception.
// The extract the error number and language-sensative text.
//-------------------------------------------------------------------
void Sample31() {

ECLPS   *PS = NULL;

try {
  PS = new ECLPS('A');
  PS->SetCursorPos(999,999);  // Invalid parameters
}
catch (ECLErr ErrObj) {
  printf("The following ECL error was trapped:\n");
  printf("%s \nError number: %lu\nReason code: %lu\n",
    ErrObj.GetMsgText(),
    ErrObj.GetMsgNumber(),
    ErrObj.GetReasonCode());
}

if (PS != NULL)
  delete PS;

} // end sample

//-------------------------------------------------------------------
// ECLErr::GetReasonCode
//
// Cause an 'invalid parameters' error and tryp the ECL exception.
// The extract the error number and language-sensative text.
//-------------------------------------------------------------------
void Sample32() {

ECLPS   *PS = NULL;

try {
  PS = new ECLPS('A');
  PS->SetCursorPos(999,999);  // Invalid parameters
}
catch (ECLErr ErrObj) {
  printf("The following ECL error was trapped:\n");
  printf("%s \nError number: %lu\nReason code: %lu\n",
    ErrObj.GetMsgText(),
    ErrObj.GetMsgNumber(),
    ErrObj.GetReasonCode());
}

if (PS != NULL)
  delete PS;

} // end sample

//-------------------------------------------------------------------
// ECLErr::GetMsgText
//
// Cause an 'invalid parameters' error and tryp the ECL exception.
// The extract the error number and language-sensative text.
//-------------------------------------------------------------------
void Sample33() {

ECLPS   *PS = NULL;

try {
  PS = new ECLPS('A');
  PS->SetCursorPos(999,999);  // Invalid parameters
}
catch (ECLErr ErrObj) {
  printf("The following ECL error was trapped:\n");
  printf("%s \nError number: %lu\nReason code: %lu\n",
    ErrObj.GetMsgText(),
    ErrObj.GetMsgNumber(),
    ErrObj.GetReasonCode());
}

if (PS != NULL)
  delete PS;

} // end sample

//-------------------------------------------------------------------
// ECLField::GetStart
// ECLField::GetStartRow
// ECLField::GetStartCol
// ECLField::GetEnd
// ECLField::GetEndRow
// ECLField::GetEndCol
// ECLField::GetLength
//
// Iterate over list of fields and print each field
// starting pos, row, col, and ending pos, row, col.
//-------------------------------------------------------------------
void Sample34() {

ECLPS        *pPS;           // Pointer to PS object
ECLFieldList *pFieldList;    // Pointer to field list object
ECLField     *pField;        // Pointer to field object

try {
  pPS = new ECLPS('A');                // Create PS object for 'A'

  pFieldList = pPS->GetFieldList();    // Get pointer to field list
  pFieldList->Refresh();               // Build the field list

  printf("Start(Pos ,Row ,Col )  End(Pos ,Row ,Col ) Length(Len )\n");
  for (pField = pFieldList->GetFirstField();      // First field
    pField != NULL;                               // While more
    pField = pFieldList->GetNextField(pField)) {  // Next field
 
    printf("Start(%04lu,%04lu,%04lu)  End(%04lu,%03lu,%04lu)  Length(%04lu)\n",
      pField->GetStart(), pField->GetStartRow(), pField->GetStartCol(),
      pField->GetEnd(), pField->GetEndRow(), pField->GetEndCol(), pField->GetLength());
  }
  delete pPS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLField::GetScreen
//
// Iterate over list of fields and print each fields text contents.
//-------------------------------------------------------------------
void Sample35() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object
ECLField     *Field;        // Pointer to field object
char         *Buff;         // Screen data buffer
ULONG        BuffLen;

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  BuffLen = PS->GetSize() + 1;        // Make big enough for entire screen
  Buff = new char[BuffLen];           // Allocate screen buffer

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  for (Field = FieldList->GetFirstField();     // First field
    Field != NULL;                             // While more
    Field = FieldList->GetNextField(Field)) {  // Next field

      Field->GetScreen(Buff, BuffLen); // Get this fields text
      printf("%02lu,%02lu: %s\n",      // Print "row,col: text"
             Field->GetStartRow(), 
             Field->GetStartCol(),
             Buff);
  }
  delete []Buff;
  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLField::SetText
//
// Set the field that contains row 2, column 10 to a value.
//-------------------------------------------------------------------
void Sample36() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object
ECLField     *Field;        // Pointer to field object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'
  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  // If the field at row 2 col 10 is an input field, set
  // it to a new value.
  Field = FieldList->FindField(2, 10);    // Find field at this location
  if (Field != NULL) {                    
    if (!Field->IsProtected())            // Make sure its an input field
      Field->SetText("Way cool!");        // Assign new field text
      //
      // Note: The above could also have been done using the ECLField
      //       object's assignment operator:
      //
      //             *Field = "Way cool!";
      //
      //       Assigning a string to a field object is equivilent to
      //       calling the SetText() method.  You can also assign
      //       numeric values without first converting to strings:
      //
      //             *Field = 1087;
      //
      //       This is equivilent to converting the number to a string
      //       and then calling the SetText() method.
    else
      printf("Position 2,10 is protected.\n");
  }
  else printf("Cannot find field at position 2,10.\n");

  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLField::IsModified
// ECLField::IsProtected
// ECLField::IsNumeric
// ECLField::IsHighIntensity
// ECLField::IsPenDetectable
// ECLField::IsDisplay
//
// Iterate over list of fields and print each fields attributes.
//-------------------------------------------------------------------
void Sample37() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object
ECLField     *Field;        // Pointer to field object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  for (Field = FieldList->GetFirstField();     // First field
    Field != NULL;                             // While more
    Field = FieldList->GetNextField(Field)) {  // Next field

      printf("Field at %02lu,%02lu is: ",
             Field->GetStartRow(), Field->GetStartCol());

      if (Field->IsProtected())
        printf("Protect ");
      else
        printf("Input   ");

      if (Field->IsModified())
        printf("Modified   ");
      else
        printf("Unmodified ");

      if (Field->IsNumeric())
        printf("Numeric  ");
      else
        printf("Alphanum ");

      if (Field->IsHighIntensity())
        printf("HiIntensity ");
      else
        printf("Normal      ");

      if (Field->IsPenDetectable())
        printf("Penable ");
      else
        printf("NoPen   ");

      if (Field->IsDisplay())
        printf("Display \n");
      else
        printf("Hidden  \n");
  }
  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLField::GetAttribute
//
// Iterate over list of fields and print each fields attribute
// value.
//-------------------------------------------------------------------
void Sample38() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object
ECLField     *Field;        // Pointer to field object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  for (Field = FieldList->GetFirstField();     // First field
    Field != NULL;                             // While more
    Field = FieldList->GetNextField(Field)) {  // Next field

      printf("Attribute value for field at %02lu,%02lu is: 0x%02x\n",
             Field->GetStartRow(), Field->GetStartCol(),
             Field->GetAttribute());
  }
  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLFieldList::Refresh
//
// Display number of fields on the screen. 
//-------------------------------------------------------------------
void Sample39() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  printf("There are %lu fields on the screen of connection %c.\n",
    FieldList->GetFieldCount(), PS->GetName());

  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLFieldList::GetFieldCount
//
// Display number of fields on the screen. 
//-------------------------------------------------------------------
void Sample40() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  printf("There are %lu fields on the screen of connection %c.\n",
    FieldList->GetFieldCount(), PS->GetName());

  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLFieldList::GetFirstField
//
// Display starting position of every input (unprotected) field.
//-------------------------------------------------------------------
void Sample41() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object
ECLField     *Field;        // Pointer to field object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  // Interate over (only) unprotected fields
  printf("List of input fields:\n");
  for (Field = FieldList->GetFirstField(GetUnprotected);    
    Field != NULL;                             
    Field = FieldList->GetNextField(Field, GetUnprotected)) {

    printf("Input field starts at %02lu,%02lu\n",
            Field->GetStartRow(), Field->GetStartCol());
  }
  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLFieldList::GetNextField
//
// Display starting position of every input (unprotected) field.
//-------------------------------------------------------------------
void Sample42() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object
ECLField     *Field;        // Pointer to field object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  // Interate over (only) unprotected fields
  printf("List of input fields:\n");
  for (Field = FieldList->GetFirstField(GetUnprotected);    
    Field != NULL;                             
    Field = FieldList->GetNextField(Field, GetUnprotected)) {

    printf("Input field starts at %02lu,%02lu\n",
            Field->GetStartRow(), Field->GetStartCol());
  }
  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLFieldList::FindField
//
// Display the field which contains row 2 column 10.  Also find
// the first field containing a particular string.
//-------------------------------------------------------------------
void Sample43() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object
ECLField     *Field;        // Pointer to field object
char         Buff[4000];

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  // Find by row,column coordinate

  Field = FieldList->FindField(2, 10);
  if (Field != NULL) {
    Field->GetScreen(Buff, sizeof(Buff));
    printf("Field at 2,10: %s\n", Buff);
  }
  else printf("No field found at 2,10.\n");

  // Find by text.  Note that text may span fields, this
  // will find the field in which the text starts.

  Field = FieldList->FindField("IBM");
  if (Field != NULL) {
    printf("String 'IBM' found in field that starts at %lu,%lu.\n",
            Field->GetStartRow(), Field->GetStartCol());
  }
  else printf("String 'IBM' not found.\n");

  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLKeyNotify class
//
// This sample demonstrates the use of:
//
// ECLKeyNotify::NotifyEvent
// ECLKeyNotify::NotifyError
// ECLKeyNotify::NotifyStop
// ECLPS::RegisterKeyEvent
// ECLPS::UnregisterKeyEvent
//-------------------------------------------------------------------

//...................................................................
// Define a class derived from ECLKeyNotify
//...................................................................
class MyKeyNotify: public ECLKeyNotify
{
public:
  // Define my own constructor to store instance data
  MyKeyNotify(HANDLE DataHandle);

  // We have to implement this function
  virtual int NotifyEvent(ECLPS *PSObj, char const KeyType[2],
                          const char * const KeyString);

  // We choose to implement this function
  void NotifyStop (ECLPS *PSObj, int Reason);

  // We will take the default behaviour for this so we
  // don't implement it in our class:
  // void NotifyError (ECLPS *PSObj, ECLErr ErrObject);

private:
  // We will store our application data handle here
  HANDLE MyDataH;
};

//...................................................................
MyKeyNotify::MyKeyNotify(HANDLE DataHandle)   // Constructor
//...................................................................
{
  MyDataH = DataHandle;  // Save data handle for later use
}

//...................................................................
int MyKeyNotify::NotifyEvent(ECLPS *PSObj,
                             char const KeyType[2],
                             const char * const KeyString)
//...................................................................

{
  // This function is called whenever a keystroke occures.  We will
  // just do something simple: when the user presses PF1 we will
  // send a PF2 to the host instead.  All other keys will be unchanged.

  printf("Connection %c got keystroke '%s' (type %s).\n",
         PSObj->GetName(), KeyString, KeyType);

  if (KeyType[0] == 'M') {             // Is this a mnemonic keyword?
    if (!strcmp(KeyString, "[pf1]")) { // Is it a PF1 key?
      PSObj->SendKeys("[pf2]");        // Send PF2 instead
      printf("Changed PF1 to PF2 on connection %c.\n",
             PSObj->GetName());
      return 1;                        // Discard this PF1 key
    }
  }

  return 0;                            // Process key normally
}

//...................................................................
void MyKeyNotify::NotifyStop (ECLPS *PSObj, int Reason)
//...................................................................
{
  // When notification ends, display message
  printf("Keystroke intercept for connection %c stopped.\n", PSObj->GetName());
}

//...................................................................
// Create the class and start keystroke processing on A and B.
//...................................................................
void Sample44() {

ECLPS *PSA, *PSB;       // PS objects
MyKeyNotify *Event;     // Ptr to my event handling object
HANDLE InstData = NULL;	// Handle to application data block (for example)

try {

  #if defined(OS2)
  printf("OS/2 NOTE: This sample will throw an error on OS/2 because this is a non-PM\n");
  printf("application and ECLPS::RegisterKeyEvent() is supported only for PM applications.\n\n");
  #endif

  PSA = new ECLPS('A');               // Create PS objects
  PSB = new ECLPS('B');
  Event = new MyKeyNotify(InstData);  // Create event handler

  PSA->RegisterKeyEvent(Event);       // Register for keystroke events
  PSB->RegisterKeyEvent(Event);       // Register for keystroke events

  // At this point, any keystrokes on A or B will cause the
  // MyKeyEvent::NotifyEvent() function to execute.  For
  // this sample, we put this thread to sleep during this 
  // time.

  printf("Processing keystrokes for 60 seconds on A and B...\n");
  Sleep(60000);

  // Now stop event generation.  This will cause the NotifyStop
  // member to be called.
  PSA->UnregisterKeyEvent(Event);
  PSB->UnregisterKeyEvent(Event);

  delete Event;  // Don't delete until after unregister!
  delete PSA;
  delete PSB;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLOIA::ECLOIA              (Constructor) 
//
// Build an OIA object from a name, and another from a handle.
//-------------------------------------------------------------------
void Sample45() {

ECLOIA *OIA1, *OIA2;    // Pointer to OIA objects
ECLConnList ConnList;   // Connection list object

try {
  // Create OIA object for connection 'A'
  OIA1 = new ECLOIA('A');

  // Create OIA object for first connection in conn list
  ECLConnection *Connection = ConnList.GetFirstConnection();
  if (Connection != NULL) {
    OIA2 = new ECLOIA(Connection->GetHandle());

    printf("OIA #1 is for connection %c, OIA #2 is for connection %c.\n",
           OIA1->GetName(), OIA2->GetName());
    delete OIA1;
    delete OIA2;
  }
  else printf("No connections to create OIA object.\n");
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsAlphanumeric 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample46() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsAlphanumeric())
  printf("Alphanumeric.\n");
else
  printf("Not Alphanumeric.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsAPL 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample47() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsAPL())
  printf("APL.\n");
else
  printf("Not APL.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsKatakana 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample48() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsKatakana())
  printf("Katakana.\n");
else
  printf("Not Katakana.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsHiragana 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample49() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsHiragana())
  printf("Hiragana.\n");
else
  printf("Not Hiragana.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsDBCS 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample50() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsDBCS())
  printf("DBCS.\n");
else
  printf("Not DBCS.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsUpperShift 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample51() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsUpperShift())
  printf("UpperShift.\n");
else
  printf("Not UpperShift.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsNumeric 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample52() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsNumeric())
  printf("Numeric.\n");
else
  printf("Not Numeric.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsCapsLock 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample53() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsCapsLock())
  printf("CapsLock.\n");
else
  printf("Not CapsLock.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsInsertMode 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample54() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsInsertMode())
  printf("InsertMode.\n");
else
  printf("Not InsertMode.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsCommErrorReminder 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample55() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsCommErrorReminder())
  printf("CommErrorReminder.\n");
else
  printf("Not CommErrorReminder.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::IsMessageWaiting 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample56() {

ECLOIA OIA('A');   // OIA object for connection A

if (OIA.IsMessageWaiting())
  printf("MessageWaiting.\n");
else
  printf("Not MessageWaiting.\n");

} // end sample

//-------------------------------------------------------------------
// ECLOIA::InputInhibited 
//
// Determine status of connection 'A' OIA indicator
//-------------------------------------------------------------------
void Sample57() {

ECLOIA OIA('A');   // OIA object for connection A

switch (OIA.InputInhibited()) {
case NotInhibited:
  printf("Input not inhibited.\n");
  break;
case SystemWait:
  printf("Input inhibited for SystemWait.\n");
  break;
case CommCheck:
  printf("Input inhibited for CommCheck.\n");
  break;
case ProgCheck:
  printf("Input inhibited for ProgCheck.\n");
  break;
case MachCheck:
  printf("Input inhibited for MachCheck.\n");
  break;
case OtherInhibit:
  printf("Input inhibited for OtherInhibit.\n");
  break;
default:
  printf("Input inhibited for unknown reason.\n");
  break;
}
} // end sample

//-------------------------------------------------------------------
// ECLPS::ECLPS              (Constructor) 
//
// Build a PS object from a name, and another from a handle.
//-------------------------------------------------------------------
void Sample58() {

ECLPS *PS1, *PS2;       // Pointer to PS objects
ECLConnList ConnList;   // Connection list object

try {
  // Create PS object for connection 'A'
  PS1 = new ECLPS('A');

  // Create PS object for first connection in conn list
  ECLConnection *Connection = ConnList.GetFirstConnection();
  if (Connection != NULL) {
    PS2 = new ECLPS(Connection->GetHandle());

    printf("PS #1 is for connection %c, PS #2 is for connection %c.\n",
           PS1->GetName(), PS2->GetName());
    delete PS1;
    delete PS2;
  }
  else printf("No connections available to create PS object.\n");
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLPS::GetSize
// ECLPS::GetSizeRows
// ECLPS::GetSizeCols
//
// Display dimensions of connection 'A'
//-------------------------------------------------------------------
void Sample59() {

ECLPS PS('A');       // PS object for connection A
ULONG Rows, Cols, Len;

PS.GetSize(&Rows, &Cols);   // Get num of rows and cols
// Could also write as:
Rows = PS.GetSizeRows();    // Redundant
Cols = PS.GetSizeCols();    // Redundant

Len = PS.GetSize();         // Get total size

printf("Connection A has %lu rows and %lu columns (%lu total length)\n",
       Rows, Cols, Len);

} // end sample

//-------------------------------------------------------------------
// ECLPS::GetCursorPos
// ECLPS::GetCursorPosRow
// ECLPS::GetCursorPosCol
//
// Display position of host cursor in connection 'A'
//-------------------------------------------------------------------
void Sample60() {

ECLPS PS('A');       // PS object for connection A
ULONG Row, Col, Pos;

PS.GetCursorPos(&Row, &Col);   // Get row/col position
// Could also write as:
Row = PS.GetCursorPosRow();    // Redundant
Col = PS.GetCursorPosCol();    // Redundant

Pos = PS.GetCursorPos();       // Get linear position

printf("Host cursor of connection A is at row %lu column %lu (linear position %lu)\n",
       Row, Col, Pos);

} // end sample

//-------------------------------------------------------------------
// ECLPS::SetCursorPos
//
// Set host cursor to row 2 column 1.
//-------------------------------------------------------------------
void Sample61() {

ECLPS PS('A');          // PS object for connection A

PS.SetCursorPos(2, 1);  // Put cursor at row 2, column 1
printf("Cursor of connection A set to row 2 column 1.\n");

} // end sample

//-------------------------------------------------------------------
// ECLPS::SendKeys
//
// Sends a series of keystrokes, including 3270 function keys, to
// the host on connection A.
//-------------------------------------------------------------------
void Sample62() {

ECLPS PS('A');         // PS object for connection A

// The following key string will erase from the current cursor
// position to the end of the field, and then type the given
// characters into the field.
char		SendStr[] = "[eraseeof]PCOMM is really cool";

// Note that an ECL error is thrown if we try to send keys to
// a protected field.

try {
  PS.SendKeys(SendStr);        // Do it at the current cursor position
  PS.SendKeys(SendStr, 3, 10); // Again at row 3 column 10
}
catch (ECLErr Err) {
  printf("Failed to send keys: %s\n", Err.GetMsgText());
}

} // end sample


//-------------------------------------------------------------------
// ECLPS::SearchText
//
// Search for a string in various parts of the screen.
//-------------------------------------------------------------------
void Sample63() {

ECLPS PS('A');            // PS object
char  FindStr[] = "IBM";  // String to search for
ULONG LastOne;            // Position of search result

// Case insensative search of entire screen

printf("Searching for '%s'...\n", FindStr);
printf("  Anywhere, any case: ");
if (PS.SearchText(FindStr, TRUE) != 0)
  printf("Yes\n");
else
  printf("No\n");

// Backward, case sensative search on line 1

printf("  Line 1, exact match: ");
if (PS.SearchText(FindStr, 1, 80, SrchBackward) != 0)
  printf("Yes\n");
else
  printf("No\n");

// Backward, full screen search

LastOne = PS.SearchText(FindStr, SrchBackward, TRUE);
if (LastOne != 0)
  printf("  Last occurance on the screen is at row %lu, column %lu.\n",
         PS.ConvertPosToRow(LastOne), PS.ConvertPosToCol(LastOne));

} // end sample


//-------------------------------------------------------------------
// ECLPS::GetScreen
//
// Get text and other planes of data from the presentation space.
//-------------------------------------------------------------------
void Sample64() {

ECLPS PS('A');            // PS object
char  *Text;              // Text plane data
char  *Field;             // Field plane data
ULONG Len;                // Size of PS

Len = PS.GetSize();

// Note text buffer needs extra byte for null terminator

Text  = new char[Len + 1];
Field = new char[Len];

PS.GetScreen(Text, Len+1);                // Get entire screen (text)
PS.GetScreen(Field, Len, FieldPlane);     // Get entire field plane
PS.GetScreen(Text, Len+1, 1, 1, 80);      // Get line 1 of text

printf("Line 1 of the screen is:\n%s\n", Text);

delete []Text;
delete []Field;

} // end sample

//-------------------------------------------------------------------
// ECLPS::SetText
//
// Update various input fields of the screen.
//-------------------------------------------------------------------
void Sample65() {

ECLPS PS('A');         // PS object for connection A

// Note that an ECL error is thrown if we try to write to
// a protected field.

try {
  // Update first 2 input fields of the screen.  Note
  // fields are not erased before update.
  PS.SendKeys("[home]");
  PS.SetText("Field 1");
  PS.SendKeys("[tab]");
  PS.SetText("Field 2");
  // Note: Above 4 lines could also be written as:
  // PS.SendKeys("[home]Field 1[tab]Field 2");
  // But SetText() is faster, esp for long strings
  //
  // The ECLPS object assignment operators can also be used to
  // update input fields.  The above SetText() calls could be:
  //
  //    PS = "Field 1";
  //    PS = "Field 2";
  //
  // Assignment of a string to a PS object is equivilent to
  // calling the SetText() method.  You can also assign numeric
  // value directly without first converting to strings:
  //
  //    PS = 1936;
  //
  // This would write the characters "1936" at the current cursor
  // location.
}
catch (ECLErr Err) {
  printf("Failed to send keys: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLPS::GetScreenRect
//
// Get rectangular parts of the host screen.
//-------------------------------------------------------------------
void Sample66() {

ECLPS PS('A');         // PS object for connection A
char Buff[4000];       // Big buffer

// Get first 2 lines of the screen text
PS.GetScreenRect(Buff, sizeof(Buff), 1, 1, 2, 80);

// Get last 2 lines of the screen
PS.GetScreenRect(Buff, sizeof(Buff),
                 PS.GetSizeRows()-1,
                 1,
                 PS.GetSizeRows(),
                 PS.GetSizeCols());

// Get just a part of the screen (OfficeVision/VM main menu calendar)
PS.GetScreenRect(Buff, sizeof(Buff),
                 5,  51, 
                 13, 76);

// Same as previous (specify any 2 oposite corners of the rectangle)
PS.GetScreenRect(Buff, sizeof(Buff),
                 13, 51,
                 5,  76);

// Note results are placed in buffer end-to-end with no line delimiters
printf("Contents of rectangular screen area:\n%s\n", Buff);

} // end sample

//-------------------------------------------------------------------
// ECLPS::ConvertPosToRowCol
// ECLPS::ConvertPosToRow
// ECLPS::ConvertPosToCol
//
// Find a string in the presentation space and display the row/column
// coordinate of its location.
//-------------------------------------------------------------------
void Sample67() {

ECLPS PS('A');            // PS Object
ULONG FoundPos;           // Linear position
ULONG FoundRow,FoundCol;


FoundPos = PS.SearchText("IBM", TRUE);
if (FoundPos != 0) {
  PS.ConvertPosToRowCol(FoundPos, &FoundRow, &FoundCol);
  // Another way to do the same thing:
  FoundRow = PS.ConvertPosToRow(FoundPos);
  FoundCol = PS.ConvertPosToCol(FoundPos);

  printf("String found at row %lu column %lu (position %lu)\n",
         FoundRow, FoundCol, FoundPos);
}
else printf("String not found.\n");

} // end sample


//-------------------------------------------------------------------
// ECLPS::RegisterKeyEvent
//
// See sample in ECLKeyNotify class.
//-------------------------------------------------------------------

//-------------------------------------------------------------------
// ECLPS::UnregisterKeyEvent
//
// See sample in ECLKeyNotify class.
//-------------------------------------------------------------------


//-------------------------------------------------------------------
// ECLPS::GetFieldList
//
// Display number of fields on the screen. 
//-------------------------------------------------------------------
void Sample68() {

ECLPS        *PS;           // Pointer to PS object
ECLFieldList *FieldList;    // Pointer to field list object

try {
  PS = new ECLPS('A');                // Create PS object for 'A'

  FieldList = PS->GetFieldList();     // Get pointer to field list
  FieldList->Refresh();               // Build the field list

  printf("There are %lu fields on the screen of connection %c.\n",
    FieldList->GetFieldCount(), PS->GetName());

  delete PS;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLSession::GetPS
//
// Get PS object from session object and use it.
//-------------------------------------------------------------------
void Sample69() {

ECLSession *Sess;       // Pointer to Session object for connection A
ECLPS      *PS;         // PS object pointer

try {
  Sess = new ECLSession('A');
  
  PS = Sess->GetPS();
  printf("Size of presentation space is %lu.\n", PS->GetSize());

  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLSession::GetOIA
//
// Get OIA object from session object and use it.
//-------------------------------------------------------------------
void Sample70() {

ECLSession *Sess;       // Pointer to Session object for connection A
ECLOIA     *OIA;        // OIA object pointer

try {
  Sess = new ECLSession('A');
  
  OIA = Sess->GetOIA();
  if (OIA->InputInhibited() == NotInhibited)
    printf("Input is not inhibited.\n");
  else
    printf("Input is inhibited.\n");

  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLSession::GetXfer
//
// Get OIA object from session object and use it.
//-------------------------------------------------------------------
void Sample71() {

ECLSession *Sess;       // Pointer to Session object for connection A
ECLXfer    *Xfer;       // Xfer object pointer
int        Rc;

try {
  Sess = new ECLSession('A');
  
  Xfer = Sess->GetXfer();
  Rc = Xfer->SendFile("c:\\autoexec.bat", "AUTOEXEC BAT A", "(ASCII CRLF");
  printf("File transfer return code %u.\n", Rc);

  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLSession::GetWinMetrics
//
// Get WinMetrics object from session object and use it.
//-------------------------------------------------------------------
void Sample72() {

ECLSession *Sess;       // Pointer to Session object for connection A
ECLWinMetrics *Metrics; // WinMetrics object pointer

try {
  Sess = new ECLSession('A');
  
  Metrics = Sess->GetWinMetrics();
  printf("Window height is %lu pixels.\n", Metrics->GetHeight());

  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLSession::RegisterUpdateEvent
//
// See ECLUpdateNotify class for sample.
//-------------------------------------------------------------------

//-------------------------------------------------------------------
// ECLSession::UnregisterUpdateEvent
//
// See ECLUpdateNotify class for sample.
//-------------------------------------------------------------------


//-------------------------------------------------------------------
// ECLSession::ECLSession      (Constructor)
//
// Build PS object from name.
//-------------------------------------------------------------------
void Sample73() {

ECLSession *Sess;       // Pointer to Session object for connection A
ECLPS      *PS;         // PS object pointer

try {
  Sess = new ECLSession('A');
  
  PS = Sess->GetPS();
  printf("Size of presentation space is %lu.\n", PS->GetSize());

  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLSession::~ECLSession      (Destructor)
//
// Build PS object from name and then delete it.
//-------------------------------------------------------------------
void Sample74() {

ECLSession *Sess;       // Pointer to Session object for connection A
ECLPS      *PS;         // PS object pointer

try {
  Sess = new ECLSession('A');
  
  PS = Sess->GetPS();
  printf("Size of presentation space is %lu.\n", PS->GetSize());

  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLStartNotify class
//
// This sample demonstrates the use of:
//
// ECLStartNotify::NotifyEvent
// ECLStartNotify::NotifyError
// ECLStartNotify::NotifyStop
// ECLConnMgr::RegisterStartEvent
// ECLConnMgr::UnregisterStartEvent
//-------------------------------------------------------------------

//...................................................................
// Define a class derived from ECLStartNotify
//...................................................................
class MyStartNotify: public ECLStartNotify
{
public:
  // Define my own constructor to store instance data
  MyStartNotify(HANDLE DataHandle);

  // We have to implement this function
  void	NotifyEvent(ECLConnMgr *CMObj, long ConnHandle,
                    BOOL Started);

  // We will take the default behaviour for these so we
  // don't implement them in our class:
  // void NotifyError (ECLConnMgr *CMObj, long ConnHandle, ECLErr ErrObject);
  // void NotifyStop (ECLConnMgr *CMObj, int Reason);

private:
  // We will store our application data handle here
  HANDLE MyDataH;
};

//...................................................................
MyStartNotify::MyStartNotify(HANDLE DataHandle)   // Constructor
//...................................................................
{
  MyDataH = DataHandle;  // Save data handle for later use
}

//...................................................................
void	MyStartNotify::NotifyEvent(ECLConnMgr *CMObj, long ConnHandle,
                    BOOL Started)
//...................................................................
{
  // This function is called whenever a connection start or stops.

  if (Started)
    printf("Connection %c started.\n", CMObj->ConvertHandle2ShortName(ConnHandle));
  else
    printf("Connection %c stopped.\n", CMObj->ConvertHandle2ShortName(ConnHandle));

  return;
}

//...................................................................
// Create the class and begin start/stop monitoring.
//...................................................................
void Sample75() {

ECLConnMgr    CMgr;     // Connection manager object
MyStartNotify *Event;   // Ptr to my event handling object
HANDLE InstData = NULL;	// Handle to application data block (for example)

try {
  Event = new MyStartNotify(InstData);  // Create event handler

  CMgr.RegisterStartEvent(Event);       // Register to get events

  // At this point, any connection start/stops will cause the
  // MyStartEvent::NotifyEvent() function to execute.  For
  // this sample, we put this thread to sleep during this 
  // time.

  printf("Monitoring connection start/stops for 60 seconds...\n");
  Sleep(60000);

  // Now stop event generation.
  CMgr.UnregisterStartEvent(Event);
  printf("Start/stop monitoring ended.\n");

  delete Event;  // Don't delete until after unregister!
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLUpdateNotify class
//
// This sample demonstrates the use of:
//
// ECLUpdateNotify::NotifyEvent
// ECLUpdateNotify::NotifyError
// ECLUpdateNotify::NotifyStop
// ECLSession::RegisterStartEvent
// ECLSession::UnregisterStartEvent
//-------------------------------------------------------------------

//...................................................................
// Define a class derived from ECLUpdateNotify
//...................................................................
class MyUpdateNotify: public ECLUpdateNotify
{
public:
  // Define my own constructor to store instance data
  MyUpdateNotify(HANDLE DataHandle);

  // We have to implement this function
  void	NotifyEvent(ECLSession *SessObj,
                    UPDATETYPE Type);

  // We will take the default behaviour for these so we
  // don't implement them in our class:
  // void NotifyError (ECLSession *SessObj, ECLErr ErrObject);
  // void NotifyStop (ECLSession *SessObj, int Reason);

private:
  // We will store our application data handle here
  HANDLE MyDataH;
};

//...................................................................
MyUpdateNotify::MyUpdateNotify(HANDLE DataHandle)   // Constructor
//...................................................................
{
  MyDataH = DataHandle;  // Save data handle for later use
}

//...................................................................
void MyUpdateNotify::NotifyEvent(ECLSession *SessObj,
                           UPDATETYPE Type)
//...................................................................
{
  // This function is called whenever the PS/OIA is updated.
  // We just display a message whenever the OIA is updated.

  if ((Type == OIAUpdate) ||       // OIA was updated
      (Type == PSOIAUpdate))       // Both PS and OIA updated
    printf("OIA updated on connection %c.\n", SessObj->GetName());

  if ((Type == PSUpdate) ||        // PS was updated
      (Type == PSOIAUpdate))       // Both PS and OIA updated
    printf("PS  updated on connection %c.\n", SessObj->GetName());

  return;
}

//...................................................................
// Create the class and start monitoring OIA changes
//...................................................................
void Sample76() {

ECLSession     *Session; // Ptr to Session object
MyUpdateNotify *Event;   // Ptr to my event handling object
HANDLE InstData = NULL;	 // Handle to application data block (for example)

try {
  Session = new ECLSession('A');        // Create a session object
  Event = new MyUpdateNotify(InstData); // Create event handler

  // Register for both PS and OIA updates
  Session->RegisterUpdateEvent(PSOIAUpdate, Event);

  // At this point, any updates to PS or OIA by the
  // opreator or the host will cause the
  // MyUpdateEvent::NotifyEvent() function to execute.  For
  // this sample, we put this thread to sleep during this 
  // time.

  printf("Monitoring updates on connection A for 60 seconds...\n");
  Sleep(60000);

  Session->UnregisterUpdateEvent(Event);
  printf("Update monitoring ended.\n");

  delete Event;  // Don't delete until after unregister!
  delete Session;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::ECLWinMetrics   (Constructor)
//
// Build WinMetrics object from name.
//-------------------------------------------------------------------
void Sample77() {

ECLWinMetrics *Metrics;    // Ptr to object

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  printf("Window of connection A is %lu pixels wide.\n",
    Metrics->GetWidth());

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::ECLWinMetrics   (Destructor)
//
// Build WinMetrics object from name.
//-------------------------------------------------------------------
void Sample78() {

ECLWinMetrics *Metrics;    // Ptr to object

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  printf("Window of connection A is %lu pixels wide.\n",
    Metrics->GetWidth());

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::GetWindowTitle
//
// Display current window title of connection A.
//-------------------------------------------------------------------
void Sample79() {

ECLWinMetrics *Metrics;    // Ptr to object

try {

  #if defined(OS2)
  printf("OS/2 NOTE: This sample will throw an error on OS/2 because this is a non-PM\n");
  printf("application and ECLWinMetrics::GetWindowTitle() is supported only for\nPM applications.\n\n");
  #endif

  Metrics = new ECLWinMetrics('A');  // Create for connection A

  printf("Title of connection A is: %s\n",
    Metrics->GetWindowTitle());

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetWindowTitle
//
// Change current window title of connection A.
//-------------------------------------------------------------------
void Sample80() {

ECLWinMetrics *Metrics;    // Ptr to object

try {

  #if defined(OS2)
  printf("OS/2 NOTE: This sample will throw an error on OS/2 because this is a non-PM\n");
  printf("application and ECLWinMetrics::GetWindowTitle() is supported only for\nPM applications.\n\n");
  #endif

  Metrics = new ECLWinMetrics('A');  // Create for connection A

  // Note this throws an error on OS/2 when run from a
  // non-PM program like this sample.  This function is only
  // supported for PM OS/2 applications.

  // Get current title
  printf("Title of connection A is: %s\n", Metrics->GetWindowTitle());

  // Set new title
  Metrics->SetWindowTitle("New Title");
  printf("New title is: %s\n", Metrics->GetWindowTitle());

  // Reset back to original title
  Metrics->SetWindowTitle("");
  printf("Returned title to: %s\n", Metrics->GetWindowTitle());

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::GetXpos
//
// Move window 10 pixels.
//-------------------------------------------------------------------
void Sample81() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot move minimized or maximized window.\n");
  }
  else {
    X = Metrics->GetXpos();
    Y = Metrics->GetYpos();
    Metrics->SetXpos(X+10);   
    Metrics->SetYpos(Y+10);
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::GetYpos
//
// Move window 10 pixels.
//-------------------------------------------------------------------
void Sample82() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot move minimized or maximized window.\n");
  }
  else {
    X = Metrics->GetXpos();
    Y = Metrics->GetYpos();
    Metrics->SetXpos(X+10);   
    Metrics->SetYpos(Y+10);
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetXpos
//
// Move window 10 pixels.
//-------------------------------------------------------------------
void Sample83() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot move minimized or maximized window.\n");
  }
  else {
    X = Metrics->GetXpos();
    Y = Metrics->GetYpos();
    Metrics->SetXpos(X+10);   
    Metrics->SetYpos(Y+10);
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetYpos
//
// Move window 10 pixels.
//-------------------------------------------------------------------
void Sample84() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot move minimized or maximized window.\n");
  }
  else {
    X = Metrics->GetXpos();
    Y = Metrics->GetYpos();
    Metrics->SetXpos(X+10);   
    Metrics->SetYpos(Y+10);
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::GetWidth
//
// Make window 1/2 its current size.  Depending on display settings
// (Appearance->Display Setup menu) it may snap to a font that is
// not exactly the 1/2 size we specify.
//-------------------------------------------------------------------
void Sample85() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot size minimized or maximized window.\n");
  }
  else {
    X = Metrics->GetWidth();
    Y = Metrics->GetHeight();
    Metrics->SetWidth(X/2);   
    Metrics->SetHeight(Y/2);
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::GetHeight
//
// Make window 1/2 its current size.  Depending on display settings
// (Appearance->Display Setup menu) it may snap to a font that is
// not exactly the 1/2 size we specify.
//-------------------------------------------------------------------
void Sample86() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot size minimized or maximized window.\n");
  }
  else {
    X = Metrics->GetWidth();
    Y = Metrics->GetHeight();
    Metrics->SetWidth(X/2);   
    Metrics->SetHeight(Y/2);
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetWidth
//
// Make window 1/2 its current size.  Depending on display settings
// (Appearance->Display Setup menu) it may snap to a font that is
// not exactly the 1/2 size we specify.
//-------------------------------------------------------------------
void Sample87() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot size minimized or maximized window.\n");
  }
  else {
    X = Metrics->GetWidth();
    Y = Metrics->GetHeight();
    Metrics->SetWidth(X/2);   
    Metrics->SetHeight(Y/2);
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::GetWindowRect
//
// Make window 1/2 its current size.  Depending on display settings
// (Appearance->Display Setup menu) it may snap to a font that is
// not exactly the 1/2 size we specify.  Also move the window.
//-------------------------------------------------------------------
void Sample88() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y, Width, Height;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot size/move minimized or maximized window.\n");
  }
  else {
    Metrics->GetWindowRect(&X, &Y, &Width, &Height);
    Metrics->SetWindowRect(X+10, Y+10,         // Move window
                           Width/2, Height/2); // Size window
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetWindowRect
//
// Make window 1/2 its current size.  Depending on display settings
// (Appearance->Display Setup menu) it may snap to a font that is
// not exactly the 1/2 size we specify.  Also move the window.
//-------------------------------------------------------------------
void Sample89() {

ECLWinMetrics *Metrics;    // Ptr to object
long X, Y, Width, Height;

try {
  Metrics = new ECLWinMetrics('A');  // Create for connection A

  if (Metrics->IsMinimized() || Metrics->IsMaximized()) {
    printf("Cannot size/move minimized or maximized window.\n");
  }
  else {
    Metrics->GetWindowRect(&X, &Y, &Width, &Height);
    Metrics->SetWindowRect(X+10, Y+10,         // Move window
                           Width/2, Height/2); // Size window
  }

  delete Metrics;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::IsVisible
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample90() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsVisible(); // Get state
Metrics.SetVisible(!CurrState);  // Set state

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetVisible
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample91() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsVisible(); // Get state
Metrics.SetVisible(!CurrState);  // Set state

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::IsActive
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample92() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsActive();  // Get state
Metrics.SetActive(!CurrState);   // Set state

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::IsMinimized
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample93() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsMinimized();  // Get state
if (!CurrState)
  Metrics.SetMinimized();           // Set state
else
  Metrics.SetRestored();

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetMinimized
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample94() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsMinimized();  // Get state
if (!CurrState)
  Metrics.SetMinimized();           // Set state
else
  Metrics.SetRestored();

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::IsRestored
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample95() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsRestored();  // Get state
if (!CurrState)
  Metrics.SetRestored();           // Set state
else
  Metrics.SetMinimized();

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetRestored
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample96() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsRestored();  // Get state
if (!CurrState)
  Metrics.SetRestored();           // Set state
else
  Metrics.SetMinimized();

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::IsMaximized
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample97() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsMaximized();  // Get state
if (!CurrState)
  Metrics.SetMaximized();           // Set state
else
  Metrics.SetMinimized();

} // end sample

//-------------------------------------------------------------------
// ECLWinMetrics::SetMaximized
//
// Get current state of window, and then toggle it.
//-------------------------------------------------------------------
void Sample98() {

ECLWinMetrics Metrics('A');      // Window metrics class
BOOL  CurrState;

CurrState = Metrics.IsMaximized();  // Get state
if (!CurrState)
  Metrics.SetMaximized();           // Set state
else
  Metrics.SetMinimized();

} // end sample

//-------------------------------------------------------------------
// ECLXfer::ECLXfer          (Constructor)
//
// Build ECLXfer object from a connection name.
//-------------------------------------------------------------------
void Sample99() {

ECLXfer  *Xfer;             // Pointer to Xfer object

try {
  Xfer = new ECLXfer('A');  // Create object for connection A
  printf("Created ECLXfer for connection %c.\n", Xfer->GetName());

  delete Xfer;              // Delete Xfer object
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLXfer::~ECLXfer          (Destructor)
//
// Build ECLXfer object from a connection name.
//-------------------------------------------------------------------
void Sample100() {

ECLXfer  *Xfer;             // Pointer to Xfer object

try {
  Xfer = new ECLXfer('A');  // Create object for connection A
  printf("Created ECLXfer for connection %c.\n", Xfer->GetName());

  delete Xfer;              // Delete Xfer object
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLXfer::SendFile
//
// Send a file to a VM/CMS host with ASCII translation.
//-------------------------------------------------------------------
void Sample101() {

ECLXfer  *Xfer;             // Pointer to Xfer object
int Rc;

try {
  Xfer = new ECLXfer('A');  // Create object for connection A

  printf("Sending file...\n");
  Rc = Xfer->SendFile("c:\\autoexec.bat", "autoexec bat a", "(ASCII CRLF QUIET");
  switch (Rc) {
  case 2:
    printf("File transfer failed, error in parameters.\n", Rc);
    break;
  case 3:
    printf("File transfer sucessfull.\n");
    break;
  case 4: 
    printf("File transfer sucessfull, some records were segmented.\n");
    break;
  case 5:
    printf("File transfer failed, workstation file not found.\n");
    break;
  case 27:
    printf("File transfer cancelled or timed out.\n");
    break;
  default:
    printf("File transfer failed, code %u.\n", Rc);
    break;
  } // case

  delete Xfer;              // Delete Xfer object
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLXfer::ReceiveFile
//
// Receive file from a VM/CMS host with ASCII translation.
//-------------------------------------------------------------------
void Sample102() {

ECLXfer  *Xfer;             // Pointer to Xfer object
int Rc;

try {
  Xfer = new ECLXfer('A');  // Create object for connection A

  printf("Receiving file...\n");
  Rc = Xfer->ReceiveFile("c:\\temp.txt", "temp text a", "(ASCII CRLF QUIET");
  switch (Rc) {
  case 2:
    printf("File transfer failed, error in parameters.\n", Rc);
    break;
  case 3:
    printf("File transfer sucessfull.\n");
    break;
  case 4: 
    printf("File transfer sucessfull, some records were segmented.\n");
    break;
  case 27:
    printf("File transfer cancelled or timed out.\n");
    break;
  default:
    printf("File transfer failed, code %u.\n", Rc);
    break;
  } // case

  delete Xfer;              // Delete Xfer object
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}

} // end sample

//-------------------------------------------------------------------
// ECLField::operator=(const ECLField&)
//
// Capture some input fields of a screen in static ECLField
// objects.  This demonstrates the use of the assignment operator
// of the ECLField object to make (read-only) copies of fields.
//-------------------------------------------------------------------
void Sample103() {

ECLPS *Ps;                  // Ptr to PS object
ECLField Flds[4];           // Captured fields
ECLField *CurrFld;          // Ptr to current field in field list
int i, Count = -1;
char TextBuff[4000];        // Big text buffer

  Ps = new ECLPS('A');      // Create PS object for 'A' connection

  // Iterate over only the unprotected fields of the screen
  Ps->GetFieldList()->Refresh();

  for (CurrFld = Ps->GetFieldList()->GetFirstField(GetUnprotected), i=0;    
      (CurrFld != NULL) && (i<4);                                      
      CurrFld = Ps->GetFieldList()->GetNextField(CurrFld,GetUnprotected), i++) {
  
    Flds[i] = *CurrFld;     // Assign this field into our array
    Count = i;              // Keep track of max index we used
  }

  // We can delete the PS object (and thus the field list and all
  // the fields in it).
  delete Ps;

  // Our array of fields still has the captured data.  We can use
  // all the ECLField member functions on them except SetText().

  printf("First 4 input fields of connection 'A'...\n");
  for (i=0; i<=Count; i++) {
    Flds[i].GetScreen(TextBuff, sizeof(TextBuff));  // Get field text
    printf("Input field %i (row %lu, col %lu): %s\n",
           i,
           Flds[i].GetStartRow(),
           Flds[i].GetStartCol(),
           TextBuff);
  }

  // This will cause an exception because we cannot do SetText()
  // on a copy of an ECLField object.
  //
  try {
    Flds[0].SetText("ABC");
  } catch (ECLErr Err) {
    printf("Exception on SetText() -- as expected.\n");
  }

}

//-------------------------------------------------------------------
// ECLField::operator=(const char const *)
// ECLField::operator=(const LONG const *)
//
// This sample uses the string assignment operator and numeric
// assignment operator to set the first two input fields of the
// screen to "IBM" and "22" respectively.
//-------------------------------------------------------------------
void Sample104() {

ECLPS *Ps;                  // Ptr to PS object
ECLField *CurrFld;          // Ptr to current field in field list

  printf("Updating 1st unprotected field with 'IBM', second with 22...\n");
  Ps = new ECLPS('A');      // Create PS object for 'A' connection

  // Build field list for current screen
  Ps->GetFieldList()->Refresh();

  // Get first unprotected (input) field
  CurrFld = Ps->GetFieldList()->GetFirstField(GetUnprotected);
  if (CurrFld != NULL) 
    // Use assignment of a string to set new text to field
    *CurrFld = "IBM";

  // Get 2nd unprotected (input) field
  CurrFld = Ps->GetFieldList()->GetNextField(CurrFld, GetUnprotected);
  if (CurrFld != NULL) 
    // Use assignment to set field directly from numeric value
    *CurrFld = 22;

  printf("Done.");

  delete Ps;
}

//-------------------------------------------------------------------
// ECLField copy constructor
//
// Captures a field using the copy constructor of the
// ECLField object.
//-------------------------------------------------------------------
void Sample105() {

ECLPS *Ps;                  // Ptr to PS object
ECLField *Field1;           // Ptr to copy of a field
char TextBuff[4000];        // Big text buffer

  Ps = new ECLPS('A');      // Create PS object for 'A' connection

  // Build field list
  Ps->GetFieldList()->Refresh();

  if (Ps->GetFieldList()->GetFirstField() != NULL)
    Field1 = new ECLField(*Ps->GetFieldList()->GetFirstField()); 

  // We can delete the PS object (and thus the field list and all
  // the fields in it).
  delete Ps;

  // Our constructed field still has the captured data.  We can use
  // all the ECLField member functions on it except SetText().

  printf("First field of connection 'A'...\n");
  Field1->GetScreen(TextBuff, sizeof(TextBuff));  // Get field text
  printf("(row %lu, col %lu): %s\n",
           Field1->GetStartRow(),
           Field1->GetStartCol(),
           TextBuff);

  // This will cause an exception because we cannot do SetText()
  // on a copy of an ECLField object.
  //
  try {
    Field1->SetText("ABC");
  } catch (ECLErr Err) {
    printf("Exception on SetText() -- as expected.\n");
  }

}

//-------------------------------------------------------------------
// ECLFieldList::operator=(const ECLFieldList&)
//
// This sample uses the ECLFieldList assignment operator to capture
// an entire screen including all the field data.
//-------------------------------------------------------------------
void Sample106() {

ECLPS *Ps;                  // Ptr to PS object
ECLFieldList CaptureList;   // Captured list of all fields
ECLField     *CurrFld;      // Current field in the list
char TextBuff[4000];        // Big text buffer
int  i;

  Ps = new ECLPS('A');      // Create PS object for 'A' connection

  // Make a (read-only) copy of the field list to user later.
  Ps->GetFieldList()->Refresh();       // Rebuild from current screen
  CaptureList = *Ps->GetFieldList();   // Make frozen read-only copy by assignment

  // Send keystrokes to the screen to move it on to something else
  Ps->SendKeys("[enter]");

  // Now we can still look at the screen we captured using the
  // copy of the field list object we made.  We can use all the
  // field list methods except Refresh().  Note that all the ECLField
  // objects in the list are also copies.

  printf("First 4 fields of the prior screen were...\n");
  for (CurrFld = CaptureList.GetFirstField(), i=0;    
      (CurrFld != NULL) && (i<4);                                      
      CurrFld = CaptureList.GetNextField(CurrFld), i++) {

    CurrFld->GetScreen(TextBuff, sizeof(TextBuff));  // Get field text
    printf("Field %i (row %lu, col %lu): %s\n",
           i,
           CurrFld->GetStartRow(),
           CurrFld->GetStartCol(),
           TextBuff);
  
  }

  // We could even delete the PS object (and its field list)
  // and we can still our our captured copy.
  delete Ps;

  // This will cause an exception because we cannot do Refresh()
  // on a copy of an ECLFieldList object.
  //
  try {
    CaptureList.Refresh();
  } catch (ECLErr Err) {
    printf("Exception on Refresh() -- as expected.\n");
  }

  // This will cause an exception because we did not build
  // the original field list object with the color plane.
  //
  try {
    CaptureList.GetFirstField()->GetScreen(TextBuff, sizeof(TextBuff), ColorPlane);
  } catch (ECLErr Err) {
    printf("Exception on Field->GetScreen() -- as expected.\n");
  }

  // All the ECLField objects in our CaptureList will be deleted
  // with the list when it goes out of scope, so we don't have
  // to do any cleanup.
}


//-------------------------------------------------------------------
// ECLFieldList::operator=(const char const *)           
// ECLFieldList::operator=(const LONG const *)
//
// This sample uses the string assignment operator and numeric
// assignment operator to set some characters in the PS.
//-------------------------------------------------------------------
void Sample107() {

ECLPS Ps('A');                // PS object for connection 'A'

  try {
    Ps.SetCursorPos(4, 10);  // Put cursor to 4,10
    Ps = "Hello";            // Write string at cursor
    Ps.SetCursorPos(5, 10);  // Move cursor
    Ps = -3829;              // Write numer at cursor

    printf("Strings written at 4,10 and 5,10.");
  } catch (ECLErr Err) {
    printf("ECL Error writing to 4,10 or 5,10: %s\n", Err.GetMsgText());
  }
}

//@D1a Start
//-------------------------------------------------------------------
// ECLPageSettings::ECLPageSettings (Constructor)
//
// Build a PageSettings object from a name, and another from a handle.
//-------------------------------------------------------------------

void Sample108() {
ECLPageSettings *PgSet1, *PgSet2; // Pointer to ECLPageSettings objects
ECLConnList ConnList; // Connection list object

try {
	// Create ECLPageSettings object for connection 'A'
	PgSet1 = new ECLPageSettings('A');
	// Create ECLPageSettings object for first connection in conn list
  ECLConnection *Connection = ConnList.GetFirstConnection();
  if (Connection != NULL) {
    PgSet2 = new ECLPageSettings(Connection->GetHandle());	
	  printf("PgSet#1 is for connection %c, PgSet #2 is for connection %c.\n", 
				PgSet1->GetName(), PgSet2->GetName());
	  delete PgSet1;
	  delete PgSet2;
	}
  else printf("No connections to create PageSettings object.\n");
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

void Sample109() {
ECLPageSettings PgSet('A');

PgSet.SetCPI(10);
ULONG cpi = PgSet.GetCPI();
printf("CPI = %ld\n", cpi);
if (PgSet.IsFontCPI())
  printf("FontCPI\n");
else
  printf("Not FontCPI\n");
} // end sample

void Sample110() {
ECLPageSettings PgSet('A');

PgSet.SetLPI();
ULONG lpi = PgSet.GetLPI();
printf("LPI = %ld\n", lpi);
if (PgSet.IsFontLPI())
  printf("FontLPI\n");
else
  printf("Not FontLPI\n");
} // end sample

void Sample111() {
ECLPageSettings PgSet('A');
const char *Face;

PgSet.SetFontFaceName("Courier New");
Face = PgSet.GetFontFaceName();
printf("FaceName = %s\n", Face);

} // end sample


void Sample112() {
ECLPageSettings PgSet('A');

if (PgSet.IsDBCSHost()) {
  PgSet.SetFontSize(10);
  ULONG size = PgSet.GetFontSize();
  printf("FontSize = %ld\n", size);
}
} // end sample

void Sample113() {
ECLPageSettings PgSet('A');

PgSet.SetMaxLinesPerPage(40);
ULONG MPL = PgSet.GetMaxLinesPerPage();
printf("MaxLinesPerPage = %ld\n", MPL);
} // end sample

void Sample114() {
ECLPageSettings PgSet('A');

PgSet.SetMaxCharsPerLine(50);
ULONG MPP = PgSet.GetMaxCharsPerLine();
printf("MaxCharsPerLine=%ld\n", MPP);
} // end sample

void Sample115() {
ECLPageSettings PgSet('A');

PgSet.RestoreDefaults(PAGE_TEXT);
printf("Restored Defaults successfully\n");
} // end sample

void Sample116() {
ECLPrinterSettings *PrSet1, *PrSet2; // Pointer to ECLPrinterSettings objects
ECLConnList ConnList; // Connection list object

try {
	// Create ECLPrinterSettings object for connection 'A'
	PrSet1 = new ECLPrinterSettings('A');
	// Create ECLPrinterSettings object for first connection in conn list
  ECLConnection *Connection = ConnList.GetFirstConnection();
  if (Connection != NULL) {
    PrSet2 = new ECLPrinterSettings(Connection->GetHandle());	
	  printf("PrSet#1 is for connection %c, PrSet #2 is for connection %c.\n", 
				PrSet1->GetName(), PrSet2->GetName());
	  delete PrSet1;
	  delete PrSet2;
	}
  else printf("No connections to create PageSettings object.\n");
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

void Sample117() {
ECLPrinterSettings PrSet('A');

try {
  PrSet.SetPDTMode(TRUE, "epson.pdt");
  const char *PDTFile = PrSet.GetPDTFile();
  printf("PDT File = %s\n", PDTFile);
  if (PrSet.IsPDTMode())
    printf("PDTMode\n");
  else
    printf("Not PDTMode\n");
  PrSet.SetPDTMode(FALSE);
  PrSet.SetPDTMode(TRUE);
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

void Sample118() {
ECLPrinterSettings PrSet('A');

ECLPrinterSettings::PrintMode PrtMode;
PrtMode = PrSet.GetPrintMode();
switch (PrtMode) {
  case ECLPrinterSettings::PrtToDskAppend:
    printf("PrtToDskAppend mode\n");
    break;
  case ECLPrinterSettings::PrtToDskSeparate:
    printf("PrtToDskSeparate mode\n");
    break;
  case ECLPrinterSettings::SpecificPrinter:
    printf("SpecificPrinter mode\n");
    break;
  case ECLPrinterSettings::WinDefaultPrinter:
    printf("WinDefaultPrinter mode\n");
    break;
}
} // end sample

void Sample119() {
ECLPrinterSettings PrSet('A');

try {
  PrSet.SetPrtToDskAppend("dskapp.txt");
  const char *DskAppFile = PrSet.GetPrtToDskAppendFile();
  printf("Print to Disk-Append File = %s\n", DskAppFile);
}  
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

void Sample120() {
ECLPrinterSettings PrSet('A');

try {
  PrSet.SetPrtToDskSeparate("dsksep");
  const char *DskSepFile = PrSet.GetPrtToDskSeparateFile();
  printf("Print to Disk-Separate File = %s\n", DskSepFile);
}  
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

void Sample121() {
ECLPrinterSettings PrSet('A');

try {
  PrSet.SetSpecificPrinter("IBM InfoPrint 40 PS");
  const char *Printer = PrSet.GetPrinterName();
  printf("Printer = %s\n", Printer);  
}  
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

void Sample122() {
ECLPrinterSettings PrSet('A');

try {
  PrSet.SetWinDefaultPrinter();
  const char *Printer = PrSet.GetPrinterName();
  printf("Windows Default Printer = %s\n", Printer);
}  
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample


void Sample123() {
ECLPrinterSettings PrSet('A');

try {
  PrSet.SetPromptDialog();
  if (PrSet.IsPromptDialogEnabled())
    printf("Prompt Dialog before Printing - Enabled\n");
  else
    printf("Prompt Dialog before Printing - Disabled\n");  
}  
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample

//-------------------------------------------------------------------
// ECLSession::GetPageSettings
//
// Get PageSettings object from session object and use it.
//-------------------------------------------------------------------
void Sample124() {
ECLSession *Sess;       // Pointer to Session object for connection A
ECLPageSettings *PgSet; // PageSettings object pointer
try {
  Sess = new ECLSession('A');
  PgSet = Sess->GetPageSettings();
  printf("FaceName = %s\n", PgSet->GetFontFaceName());
  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample


//-------------------------------------------------------------------
// ECLSession::GetPrinterSettings
//
// Get PrinterSettings object from session object and use it.
//-------------------------------------------------------------------
void Sample125() {
ECLSession *Sess;          // Pointer to Session object for connection A
ECLPrinterSettings *PrSet; // PrinterSettings object pointer
try {
  Sess = new ECLSession('A');
  PrSet = Sess->GetPrinterSettings();
  if (PrSet->IsPDTMode())
    printf("PDTMode\n");
  else
    printf("Not PDTMode\n");
  delete Sess;
}
catch (ECLErr Err) {
  printf("ECL Error: %s\n", Err.GetMsgText());
}
} // end sample
//@D1a End
  
//*******************************************************************
// This main() will prompt for a sample number, and then runs
// the corresponding "SampleX()" function.  It loops until an
// invalid sample number (e.g. 0) is entered.  This is a 
// command-line (console) application.
//*******************************************************************
int main( int argc, char *argv[ ], char *envp[ ] )
{
  int SampNum;

  try {  // Catch any ECL errors the samples do not trap

    while (TRUE) {
      printf("\nEnter sample number to be run (0 to exit) ===> ");
      fflush(stdout);
      fflush(stdin);
      scanf("%i", &SampNum);
      switch (SampNum) {
      case   2: Sample2();    break;
      case   3: Sample3();    break;
      case   4: Sample4();    break;
      case   5: Sample5();    break;
      case   6: Sample6();    break;
      case   7: Sample7();    break;
      case   8: Sample8();    break;
      case   9: Sample9();    break;
      case  10: Sample10();   break;
      case  11: Sample11();   break;
      case  12: Sample12();   break;
      case  13: Sample13();   break;
      case  14: Sample14();   break;
      case  15: Sample15();   break;
      case  16: Sample16();   break;
      case  17: Sample17();   break;
      case  18: Sample18();   break;
      case  19: Sample19();   break;
      case  20: Sample20();   break;
      case  21: Sample21();   break;
      case  22: Sample22();   break;
      case  23: Sample23();   break;
      case  24: Sample24();   break;
      case  25: Sample25();   break;
      case  26: Sample26();   break;
      case  27: Sample27();   break;
      case  28: Sample28();   break;
      case  29: Sample29();   break;
      case  30: Sample30();   break;
      case  31: Sample31();   break;
      case  32: Sample32();   break;
      case  33: Sample33();   break;
      case  34: Sample34();   break;
      case  35: Sample35();   break;
      case  36: Sample36();   break;
      case  37: Sample37();   break;
      case  38: Sample38();   break;
      case  39: Sample39();   break;
      case  40: Sample40();   break;
      case  41: Sample41();   break;
      case  42: Sample42();   break;
      case  43: Sample43();   break;
      case  44: Sample44();   break;
      case  45: Sample45();   break;
      case  46: Sample46();   break;
      case  47: Sample47();   break;
      case  48: Sample48();   break;
      case  49: Sample49();   break;
      case  50: Sample50();   break;
      case  51: Sample51();   break;
      case  52: Sample52();   break;
      case  53: Sample53();   break;
      case  54: Sample54();   break;
      case  55: Sample55();   break;
      case  56: Sample56();   break;
      case  57: Sample57();   break;
      case  58: Sample58();   break;
      case  59: Sample59();   break;
      case  60: Sample60();   break;
      case  61: Sample61();   break;
      case  62: Sample62();   break;
      case  63: Sample63();   break;
      case  64: Sample64();   break;
      case  65: Sample65();   break;
      case  66: Sample66();   break;
      case  67: Sample67();   break;
      case  68: Sample68();   break;
      case  69: Sample69();   break;
      case  70: Sample70();   break;
      case  71: Sample71();   break;
      case  72: Sample72();   break;
      case  73: Sample73();   break;
      case  74: Sample74();   break;
      case  75: Sample75();   break;
      case  76: Sample76();   break;
      case  77: Sample77();   break;
      case  78: Sample78();   break;
      case  79: Sample79();   break;
      case  80: Sample80();   break;
      case  81: Sample81();   break;
      case  82: Sample82();   break;
      case  83: Sample83();   break;
      case  84: Sample84();   break;
      case  85: Sample85();   break;
      case  86: Sample86();   break;
      case  87: Sample87();   break;
      case  88: Sample88();   break;
      case  89: Sample89();   break;
      case  90: Sample90();   break;
      case  91: Sample91();   break;
      case  92: Sample92();   break;
      case  93: Sample93();   break;
      case  94: Sample94();   break;
      case  95: Sample95();   break;
      case  96: Sample96();   break;
      case  97: Sample97();   break;
      case  98: Sample98();   break;
      case  99: Sample99();   break;
      case 100: Sample100();  break;
      case 101: Sample101();  break;
      case 102: Sample102();  break;
      case 103: Sample103();  break;
      case 104: Sample104();  break;
      case 105: Sample105();  break;
      case 106: Sample106();  break;
      case 107: Sample107();  break;      
      case 108: Sample108();  break;      //@D1a
      case 109: Sample109();  break;      //@D1a 
      case 110: Sample110();  break;      //@D1a
      case 111: Sample111();  break;      //@D1a 
      case 112: Sample112();  break;      //@D1a 
      case 113: Sample113();  break;      //@D1a
      case 114: Sample114();  break;      //@D1a
      case 115: Sample115();  break;      //@D1a 
      case 116: Sample116();  break;      //@D1a
      case 117: Sample117();  break;      //@D1a
      case 118: Sample118();  break;      //@D1a 
      case 119: Sample119();  break;      //@D1a
      case 120: Sample120();  break;      //@D1a
      case 121: Sample121();  break;      //@D1a
      case 122: Sample122();  break;      //@D1a 
      case 123: Sample123();  break;      //@D1a
      case 124: Sample124();  break;      //@D1a
      case 125: Sample125();  break;      //@D1a

      case 999: // Run selected samples in a loop forever (ctrl-break to stop)
        LoopCnt = 1;
        while (TRUE) {
          printf("-------------------------------------------------------------------------------\n");
          printf("----------------------------- Iteration %5lu ---------------------------------\n", LoopCnt++);
          printf("-------------------------------------------------------------------------------\n");
          fflush(stdout);
          Sleep(1000);
          printf("===>Sample2\n"); Sample2();
          printf("===>Sample3\n"); Sample3();
          printf("===>Sample4\n"); Sample4();
          printf("===>Sample5\n"); Sample5();
          printf("===>Sample6\n"); Sample6();
          printf("===>Sample7\n"); Sample7();
          printf("===>Sample8\n"); Sample8();
          printf("===>Sample9\n"); Sample9();
          printf("===>Sample10\n"); Sample10();
          printf("===>Sample11\n"); Sample11();
          printf("===>Sample12\n"); Sample12();
          printf("===>Sample13\n"); Sample13();
          printf("===>Sample14\n"); Sample14();
          printf("===>Sample15\n"); Sample15();
          printf("===>Sample16\n"); Sample16();
          printf("===>Sample19\n"); Sample19();
          printf("===>Sample20\n"); Sample20();
          printf("===>Sample21\n"); Sample21();
          printf("===>Sample22\n"); Sample22();
          printf("===>Sample23\n"); Sample23();
          printf("===>Sample24\n"); Sample24();
          printf("===>Sample25\n"); Sample25();
          printf("===>Sample28\n"); Sample28();
          printf("===>Sample31\n"); Sample31();
          printf("===>Sample32\n"); Sample32();
          printf("===>Sample33\n"); Sample33();
          printf("===>Sample34\n"); Sample34();
          printf("===>Sample35\n"); Sample35();
          printf("===>Sample36\n"); Sample36();
          printf("===>Sample37\n"); Sample37();
          printf("===>Sample38\n"); Sample38();
          printf("===>Sample39\n"); Sample39();
          printf("===>Sample40\n"); Sample40();
          printf("===>Sample41\n"); Sample41();
          printf("===>Sample42\n"); Sample42();
          printf("===>Sample43\n"); Sample43();
          printf("===>Sample45\n"); Sample45();
          printf("===>Sample46\n"); Sample46();
          printf("===>Sample47\n"); Sample47();
          printf("===>Sample48\n"); Sample48();
          printf("===>Sample49\n"); Sample49();
          printf("===>Sample50\n"); Sample50();
          printf("===>Sample51\n"); Sample51();
          printf("===>Sample52\n"); Sample52();
          printf("===>Sample53\n"); Sample53();
          printf("===>Sample54\n"); Sample54();
          printf("===>Sample55\n"); Sample55();
          printf("===>Sample56\n"); Sample56();
          printf("===>Sample57\n"); Sample57();
          printf("===>Sample58\n"); Sample58();
          printf("===>Sample59\n"); Sample59();
          printf("===>Sample60\n"); Sample60();
          printf("===>Sample61\n"); Sample61();
          printf("===>Sample62\n"); Sample62();
          printf("===>Sample63\n"); Sample63();
          printf("===>Sample64\n"); Sample64();
          printf("===>Sample65\n"); Sample65();
          printf("===>Sample66\n"); Sample66();
          printf("===>Sample67\n"); Sample67();
          printf("===>Sample68\n"); Sample68();
          printf("===>Sample69\n"); Sample69();
          printf("===>Sample70\n"); Sample70();
          printf("===>Sample72\n"); Sample72();
          printf("===>Sample73\n"); Sample73();
          printf("===>Sample74\n"); Sample74();
          printf("===>Sample77\n"); Sample77();
          printf("===>Sample78\n"); Sample78();
          printf("===>Sample79\n"); Sample79();
          printf("===>Sample80\n"); Sample80();
          printf("===>Sample81\n"); Sample81();
          printf("===>Sample82\n"); Sample82();
          printf("===>Sample83\n"); Sample83();
          printf("===>Sample84\n"); Sample84();
          printf("===>Sample85\n"); Sample85();
          printf("===>Sample86\n"); Sample86();
          printf("===>Sample87\n"); Sample87();
          printf("===>Sample88\n"); Sample88();
          printf("===>Sample89\n"); Sample89();
          printf("===>Sample90\n"); Sample90();
          printf("===>Sample91\n"); Sample91();
          printf("===>Sample92\n"); Sample92();
          printf("===>Sample93\n"); Sample93();
          printf("===>Sample94\n"); Sample94();
          printf("===>Sample95\n"); Sample95();
          printf("===>Sample96\n"); Sample96();
          printf("===>Sample97\n"); Sample97();
          printf("===>Sample98\n"); Sample98();
          printf("===>Sample99\n"); Sample99();
          printf("===>Sample103\n"); Sample103();
          printf("===>Sample104\n"); Sample104();
          printf("===>Sample105\n"); Sample105();
          //printf("===>Sample106\n"); Sample106();
          //printf("===>Sample107\n"); Sample107();
        }
      default:
        printf("Exiting...\n");
        return 0;
      } // switch
    } // while
  } // try

  catch (ECLErr Err) {
  printf("\n\nSample program did not catch the following ECL error:\n%s\n",
         Err.GetMsgText());
  }

  return 0;
}

