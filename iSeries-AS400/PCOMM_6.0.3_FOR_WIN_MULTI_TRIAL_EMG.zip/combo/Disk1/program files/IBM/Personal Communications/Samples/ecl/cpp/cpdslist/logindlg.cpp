// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cpdslist.h"
#include "LoginDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg dialog


CLoginDlg::CLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLoginDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoginDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLoginDlg, CDialog)
	//{{AFX_MSG_MAP(CLoginDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg message handlers

void CLoginDlg::OnOK() 
{
CEdit *UserNameEdit = (CEdit *)GetDlgItem(IDC_USERNAME);
CEdit *UserPasswordEdit = (CEdit *)GetDlgItem(IDC_PASSWORD);
CString UserName;
CString UserPassword;

  // Get the user name and password
  UserNameEdit->GetWindowText(UserName);
  UserPasswordEdit->GetWindowText(UserPassword);

  // Enter the logon 
  try {
    // If at TN3270 logon
    if ( m_pECLSession->GetPS()->SearchText( "IKJ56700A" ) != 0 ) {
      m_pECLSession->GetPS()->SetText(UserName);
      m_pECLSession->GetPS()->SendKeys("[enter]");
      if ( !m_pMyApp->WaitForScreen("Userid", "Password", 500, 50) ) {
        AfxMessageBox("Couldn't get to TSO logon screen", MB_ICONEXCLAMATION);
        EndDialog(0);
        return;
      }
      else {
        m_pECLSession->GetPS()->SetText(UserPassword);
        m_pECLSession->GetPS()->SendKeys("[enter]");
      }
    }
    // If at normal logon screen
    else if ( m_pECLSession->GetPS()->SearchText( "Userid", 6, 5 ) != 0 && 
              m_pECLSession->GetPS()->SearchText( "Password", 8, 5 ) != 0 ) {
      m_pECLSession->GetPS()->SetText(UserName);
      m_pECLSession->GetPS()->SendKeys("[tab]");
      m_pECLSession->GetPS()->SetText(UserPassword);
      m_pECLSession->GetPS()->SendKeys("[enter]");
    }


    // If bad ID or password, go back out to main dialog to try again
    if ( m_pMyApp->WaitForScreen("PASSWORD NOT AUTHORIZED", "Enter one of the following commands:", 500, 5) ||
         m_pMyApp->WaitForScreen("not in CP directory", "Enter one of the following commands:", 500, 5) ) {
    	CDialog::OnOK();
      return;
    }

    // Wait for the password screen 
    if ( !m_pMyApp->WaitForScreen("Enter your password", "To change your password", 500, 50) ) {
      AfxMessageBox("Couldn't get to password screen", MB_ICONEXCLAMATION);
  	  CDialog::OnCancel();
    }

    // Enter the password
    LogonString = UserPassword + "[enter]";
    m_pECLSession->GetPS()->SendKeys(LogonString, 23, 16);

  }
  catch (ECLErr Err) {
    AfxMessageBox(Err.GetMsgText(), MB_ICONEXCLAMATION);
  }
	CDialog::OnOK();
}

void CLoginDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

BOOL CLoginDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
  m_pMyApp = (CDSListApp *)AfxGetApp();
  m_pECLSession = m_pMyApp->m_pECLSession;
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
