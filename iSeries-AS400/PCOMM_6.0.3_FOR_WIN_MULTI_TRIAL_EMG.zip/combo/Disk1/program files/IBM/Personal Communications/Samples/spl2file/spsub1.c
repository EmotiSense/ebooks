//******************************************************************************
//
//  File name   : SPSUB1.C
//
//  Description :Misc functions, etc for the MyPrint DDE application
//
//  FUNCTIONS:
//
//  COMMENTS:
//
//  Copyright  (C) 1993, 1996 IBM Corporation
//                        All rights reserved.
//
//******************************************************************************

#include <windows.h>                // required for all Windows applications
#include <string.h>                 // C string functions
#include <stdio.h>                  // C functions

#include "spl2file.h"               // specific to this program
#include "spdata.h"                 // Global Data

//******************************************************************************
//
// TerminateConversation - Terminate the DDE Conversation
//
//  Abstract:
//
//  This function checks for existence of the target window and if it exists
//  Post's the message to the window. if the Window does not exist return
//  FALSE;
//
//******************************************************************************
BOOL TerminateConversation( void )
{                                                //
  DDEPostMessage(hDDEClientWnd, WM_DDE_TERMINATE, (WPARAM)hMainWnd, 0L );
                                                 //
  hDDEClientWnd = NULL;                          // Ensure conversation severed.

  return( TRUE );                                //
}                                                //

//******************************************************************************
//
// DDEPostMessage - Post a PC/5250 Client DDE message
//
//  Abstract:
//
//  This function checks for existence of the target window and if it exists
//  Post's the message to the window. if the Window does not exist return
//  FALSE;
//
//******************************************************************************
BOOL DDEPostMessage( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
  if( IsWindow(hWnd) )                            // Does Window exist?
  {                                               // Yes, post the message
    return( PostMessage( hWnd, message, wParam, lParam ) );
  }                                               //

  return(FALSE);                                  //
}                                                 //

//******************************************************************************
//
//  FUNCTION: CenterDialogOnScreen
//
//  PURPOSE: Centers the dialog on the display screen
//
//******************************************************************************
void CenterDialogOnScreen( HWND hWnd )
{
  RECT r;

  GetWindowRect(hWnd, &r);

  r.left = (GetSystemMetrics(SM_CXSCREEN) - (r.right - r.left)) / 2;
  r.top  = (GetSystemMetrics(SM_CYSCREEN) - (r.bottom - r.top)) / 2;

  SetWindowPos(hWnd, NULL, r.left, r.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER );
  SetForegroundWindow(hWnd);
}

//******************************************************************************
//
//  FUNCTION: OffsetInPs( int nRow, int nCol )
//
//  PURPOSE: Get the offset in Ps.
//
//******************************************************************************
int OffsetInPs( int nRow, int nCol )
{                                                //
  return ( (nRow - 1) * MAX_COL + nCol - 1 );    //
}                                                //

//******************************************************************************
//
//  FUNCTION: GetStartEndCol( LPSTR lpData, LPINT lpnStartCol, LPINT lpnEndCol )
//
//  PURPOSE: Get the Start and End column position from the screen data
//
//******************************************************************************
void GetStartEndCol( LPSTR lpData, LPINT lpnStartCol, LPINT lpnEndCol )
{
  int    i=0;                                         //

  *lpnStartCol = 0;                                   //
  *lpnEndCol = 0;                                     //
  while ( (lpData[i] >= '0') && (lpData[i] <= '9') )  // numeric character?
  {                                                   //
    *lpnStartCol *= 10;                               // convert ascii to number
    *lpnStartCol += (int)(lpData[i] - '0');           //
    i++;                                              //
  }                                                   //
  i += 3;                                             //
  while ( (lpData[i] >= '0') && (lpData[i] <= '9') )  // numeric character?
  {                                                   //
    *lpnEndCol *= 10;                                 // convert ascii to number
    *lpnEndCol += (int)(lpData[i] - '0');             //
    i++;                                              //
  }                                                   //
}                                                     //

//******************************************************************************
//
//  FUNCTION: IsDbcsHiByte( BYTE byValue )
//
//  PURPOSE: Checks if the specified value is a DBCS Hi-Byte in PC code page.
//
//******************************************************************************
BOOL IsDbcsHiByte( BYTE byValue )
{                                                     //
  if (((byValue >= 0x81) && (byValue <= 0x9f)) ||     //
      ((byValue >= 0xe0) && (byValue <= 0xfc)))       //
  {                                                   //
    return (TRUE);                                    //
  }                                                   //
  else                                                //
  {                                                   //
    return (FALSE);                                   //
  }                                                   //
}                                                     //

//******************************************************************************
//
//  FUNCTION: IsSoSi( BYTE byValue )
//
//  PURPOSE: Checks if the specified value is SO (0x0e) or SI (0x0f).
//
//******************************************************************************
BOOL IsSoSi( BYTE byValue )
{                                                     //
  if ((byValue == 0x0e) || (byValue == 0x0f))         //
  {                                                   //
    return (TRUE);                                    //
  }                                                   //
  else                                                //
  {                                                   //
    return (FALSE);                                   //
  }                                                   //
}                                                     //
