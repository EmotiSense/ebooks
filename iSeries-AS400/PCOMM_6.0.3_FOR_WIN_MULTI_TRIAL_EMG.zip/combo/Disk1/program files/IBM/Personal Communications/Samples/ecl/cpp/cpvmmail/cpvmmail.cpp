// cpvmmail.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "cpvmmail.h"
#include "cpvmmDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCVMMailApp

BEGIN_MESSAGE_MAP(CCVMMailApp, CWinApp)
	//{{AFX_MSG_MAP(CCVMMailApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCVMMailApp construction

CCVMMailApp::CCVMMailApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCVMMailApp object

CCVMMailApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCVMMailApp initialization

BOOL CCVMMailApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CCpvmmailDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// Worker function that waits for a screen to appear.  Resides in the App 
// object so all dialogs can have access to it.

BOOL CCVMMailApp::WaitForScreen(CString Str1, CString Str2, long TimeInterval, int MaxTries)
{
BOOL  RetVal = FALSE;
int   i = 0;

  for (i = 0; i <= MaxTries; i++) {
    if ( m_pECLSession->GetPS()->SearchText("MORE...") ) {
      m_pECLSession->GetPS()->SendKeys("[clear]");
      Sleep(TimeInterval);
    }
    else if ( m_pECLSession->GetPS()->SearchText("HOLDING") ) {
      m_pECLSession->GetPS()->SendKeys("[clear]");
      Sleep(TimeInterval);
    }
    else if ( m_pECLSession->GetPS()->SearchText("RECONNECTED AT") ) {
      m_pECLSession->GetPS()->SendKeys("[clear]");
      m_pECLSession->GetPS()->SendKeys("b[enter]");
      Sleep(TimeInterval);
    }
    else if ( m_pECLSession->GetPS()->SearchText(Str1) && m_pECLSession->GetPS()->SearchText(Str2) ) {
      RetVal = TRUE;
      break;
    }
    else {
      Sleep(TimeInterval);
    }
  }

  return RetVal;
}

/////////////////////////////////////////////////////////////////////////////
// Worker function that waits for the OIA to indicate input is not inhibited
//

void CCVMMailApp::WaitForInput(int SleepInterval, int MaxTries)
{
int   i = 0;
BOOL  Ready = FALSE;

  while ( !Ready ) {
    i = i + 1;
    if (i == MaxTries) {
      AfxMessageBox("Input timeout expired", MB_ICONEXCLAMATION);
      return;
    }
    else {
      if ( m_pECLSession->GetOIA()->InputInhibited() == 0 ) {
        Ready = TRUE;
      }
      else {
        Sleep(SleepInterval);
      }
    }
  }

  return;
}
    
 
