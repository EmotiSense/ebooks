/*****************************************************************************/
/*                                                                           */
/*  Module Name     : PCSAPI32.H                                             */
/*                                                                           */
/*  Description     : 32 Bit PCSAPI Return Codes and Routines                */
/*                                                                           */
/*  Copyright Notice: IBM eNetwork Personal Communication                    */
/*                    (C) COPYRIGHT IBM CORP. 1984,1997 - PROGRAM PROPERTY   */
/*                    OF IBM ALL RIGHTS RESERVED                             */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  Function:                                                                */
/*                                                                           */
/*    Define the PCSAPI return code constants and the external               */
/*    routines.                                                              */
/*                                                                           */
/*****************************************************************************/
/* V4.2 changes:                                                             */
/*   - Added pcsQuerySessionList() function and data structures              */
/*   - Added ordinal entry point values for dynamic loading of PCSAPI32.DLL  */
/*   - Added #define's for pcsStartSession() window-status parameter.        */
/* V4.3 changes:                                                             */
/*   - Added pcsSetLinkTimeout() function                                    */
/* $A1                             Add symbols for PCSAPI RexxHLLAPI support */
/* Defects                                                                   */
/* ==========================================================================*/
/*  flag   Defect#    rls  date    name description of change                */
/*  $P1    DF45036   4.20 05/17/99 CIL  pcsConnectSession fails              */
/*  $P2    AXA DCR   5.02 20010105 eeg  pcsQueryConnectionInfo               */
//  $P3    F91466    5.72 20031018 san  PageSettings and PrinterSettings     */
//  $P4    D91521    5.70 20031020 MPH  API support for Page & Print Setup   */
//  $bd1   D100777   59   20080424 IF   Bidi support for autECLPrinterSettings API *
//  $PR1   D102195   60   20090826 PRA  Workstation ID is missing in Quick Connect Bar
//  $PR2   D102346   60   20091004 PRA  Host name missing in Link Paremeters */
/*****************************************************************************/

#ifdef __cplusplus                     /* C++ compiler                       */
  extern "C" {
#endif

#ifndef _PCSAPI32_H_
#define _PCSAPI32_H_

/*--------------------------------------------------------------------------*/
/*  General Purpose Definition                                              */
/*--------------------------------------------------------------------------*/
#define MAXPATHLEN                    256

/*--------------------------------------------------------------------------*/
/*  Definition for Query Session Status                                     */
/*--------------------------------------------------------------------------*/

#define PCS_SESSION_STARTED          0x00000001
#define PCS_SESSION_ONLINE           0x00000002
#define PCS_SESSION_API_ENABLED      0x00000004
#define PCS_SESSION_INTERIM_STATE    0x00000008                    //@P1a

/*--------------------------------------------------------------------------*/
/*  Definition for Start Session                                            */
/*--------------------------------------------------------------------------*/

#define PCS_HIDE                     0
#define PCS_SHOW                     1
#define PCS_MINIMIZE                 2
#define PCS_MAXIMIZE                 3

#define PCS_SUCCESSFUL               0
#define PCS_INVALID_ID               1
#define PCS_USED_ID                  2
#define PCS_INVALID_PROFILE          3
#define PCS_SYSTEM_ERROR             9

/*--------------------------------------------------------------------------*/
/*  Definition for Stop Session                                             */
/*--------------------------------------------------------------------------*/

#define PCS_SAVE_AS_PROFILE          0
#define PCS_SAVE_ON_EXIT             1
#define PCS_NOSAVE_ON_EXIT           2

// @A1+ [ added PCSAPI symbols ]
/*--------------------------------------------------------------------------*/
/*  Symbol definitions for RexxHLLAPI support                               */
/*--------------------------------------------------------------------------*/

#define PCSAPI_START_SESSION            140     /* Rexx - pcsStartSession    */
#define PCSAPI_STOP_SESSION             141     /* Rexx - pcsStopSession     */
#define PCSAPI_START_COMMUNICATION      142     /* Rexx - pcsStartCommunicati*/
#define PCSAPI_STOP_COMMUNICATION       143     /* Rexx - pcsStopCommunicatio*/
#define PCSAPI_QUERY_SESSLIST           144     /* Rexx - pcsQuerySessionList*/
#define PCSAPI_QUERY_EMULATOR_STAT      145     /* Rexx - pcsQueryEmulatorSta*/
#define PCSAPI_QUERY_WS_PROFILE         146     /* Rexx - pcsQueryWSProfile  */
// @A1+ [ end ]

/*--------------------------------------------------------------------------*/
/*  Definition for Query Session List (added V4.2)                          */
/*--------------------------------------------------------------------------*/

typedef union _SESSNAME {   // Name field of SessInfo structure
  char ShortName;           // Short session ID (A-Z)
  ULONG Handle;             // Session handle
  } SESSNAME;

typedef struct _SESSINFO {  // Description of a single session
  SESSNAME Name;            // Session name (ID or handle)
  ULONG    Status;          // Session status (PCS_SESSION_* bit flags)
  } SESSINFO;

typedef struct _CONNECTIONINFO { // Description of a connection
  char hostName[63];             // telnet host name
  char reserved1[1];             // reserved
  int  portNumber;               // host port number
  char luName[17];               // LU name
  char reserved2[3];             // reserved
  BOOL sslIndicator;             // Secure Connection indicator
  BOOL bInCustomize;              //@PR2A
  char qluName[17];               //@PR1A
  char qworkstationid[12];        //@PR1A
  char reserved3[227];           // reserved //@PR1C
  } CONNECTIONINFO;
typedef CONNECTIONINFO far *LPCONNECTIONINFO;                        //@P4A

/*--------------------------------------------------------------------------*/
/*  Definition for  (added V5.7) Page Settings APIs                @P3A     */
/*--------------------------------------------------------------------------*/
  // Return Codes
// Already defined  PCS_SUCCESSFUL, PCS_INVALID_ID are valid and used.
#define PCS_INVALID_SESS_TYPE   2
#define PCS_DIALOG_IN_USE       3
#define PCS_PRINTING            4
#define PCS_PDT_MODE            5
#define PCS_FAILURE             6

 // Constants
#define PCS_MAX_FACE_NAME_LENGTH 32 

#define PCS_PAGE_TEXT                  0x00000001

  // Flags to be used for nFlags field.
#define PCS_PAGE_CPI                   0x00000001
#define PCS_PAGE_LPI                   0x00000002
#define PCS_PAGE_FACE_NAME             0x00000004
#define PCS_PAGE_FONT_SIZE             0x00000008
#define PCS_PAGE_MPL                   0x00000010
#define PCS_PAGE_MPP                   0x00000020

 // Structures
typedef struct
{
  ULONG nFlags;
  ULONG nCPI;
  ULONG nLPI; 
  char szFaceName[PCS_MAX_FACE_NAME_LENGTH];
  USHORT nFontSize;
  USHORT nMPL;
  USHORT nMPP; 
  USHORT reserved1;
  ULONG reserved2[2]; // reserved for future. MUST be set to NULL
}PAGEINFO;

/*--------------------------------------------------------------------------*/ 
/*  Definition for  (added V5.7) Printer Settings APIs             @P3A     */
/*--------------------------------------------------------------------------*/

  // Return Codes
    // Following return codes are already defined and used for Printer Settings APIs:
    // PCS_SUCCESSFUL, PCS_INVALID_ID, PCS_DIALOG_IN_USE, PCS_PRINTING, PCS_FAILURE           
    // PCS_SYSTEM_ERROR

// Extended Error Codes
#define PCS_PRINT_PDTMODE_ERROR           0x00000001
#define PCS_PRINT_PDTFILE_ERROR           0x00000002 
#define PCS_PRINT_PRTTODSK_FILE_ERROR     0x00000004
#define PCS_PRINT_PRINTMODE_ERROR         0x00000008

#define  PCS_PRINT_PDTFILE_SIZEERR        0x00000010
#define  PCS_PRINT_DSKAPPFILE_SIZEERR     0x00000020
#define  PCS_PRINT_DSKSEPFILE_SIZEERR     0x00000040
#define  PCS_PRINT_PRINTERNAME_SIZEERR    0x00000080


enum PRINTMODE
{ 
  PrtToDskAppend = 1,
  PrtToDskSeparate,
  SpecificPrinter, 
  WinDefaultPrinter
};

  // Flags to be used for nFlags field.
#define PCS_PRINT_PDT                  0x00000001
#define PCS_PRINT_PRINTMODE            0x00000002
#define PCS_PRINT_PROMPT_DIALOG        0x00000004
#define PCS_PRINT_BIDIDIR              0x00000008  //@bd1a

  // Structures
typedef struct
{
  ULONG nFlags;
  ULONG nBufSize;
  ULONG nSizeNeeded;
  BOOL bPromptDialog;
  BOOL bPDTMode;
  char *lpPDTFile;
  enum PRINTMODE nPrtMode;
  char *lpPrtToDskAppFile;
  char *lpPrtToDskSepFile;
  char *lpPrinterName;
  ULONG nRTLBidiDir; //@bd1a
  ULONG reserved[2]; // reserved for future. MUST be set to NULL
}PRINTINFO;

/*--------------------------------------------------------------------------*/
/*  Function Prototypes                                                     */
/*--------------------------------------------------------------------------*/
#if defined(__OS2__)
  #define PCSAPI_ENTRY APIENTRY
#else
  #define PCSAPI_ENTRY WINAPI
#endif

ULONG PCSAPI_ENTRY pcsQueryEmulatorStatus(char);
BOOL  PCSAPI_ENTRY pcsQueryWorkstationProfile(char, PSZ);
ULONG PCSAPI_ENTRY pcsStartSession(PSZ, char, USHORT);
BOOL  PCSAPI_ENTRY pcsStopSession(char, USHORT);
BOOL  PCSAPI_ENTRY pcsConnectSession(char);
BOOL  PCSAPI_ENTRY pcsDisconnectSession(char);
ULONG PCSAPI_ENTRY pcsQuerySessionList(ULONG Count, SESSINFO *SessList); // Added V4.2
#if defined(_V43)
ULONG PCSAPI_ENTRY pcsSetLinkTimeout(char, USHORT); // Added V4.3
#endif
#if defined(_V50)
BOOL  PCSAPI_ENTRY pcsQueryConnectionInfo(char, CONNECTIONINFO *);  // @P2A
#endif

#if defined(_V57) 
ULONG PCSAPI_ENTRY pcsRestorePageDefaults(/*[in]*/ char cShortSessionID,          //@P3A
                                          /*[in]*/ ULONG nFlags);                 //@P3A
ULONG PCSAPI_ENTRY pcsSetPageSettings(/*[in]*/ char cShortSessionID,              //@P3A
                                      /*[in]*/ const PAGEINFO * const pPageInfo,  //@P3A
                                      /*[out]*/ ULONG * const pErrorInfo);        //@P3A
ULONG PCSAPI_ENTRY pcsGetPageSettings(/*[in]*/ char cShortSessionID,              //@P3A
                                      /*[in-out]*/ PAGEINFO * const pPageInfo,    //@P3A
                                      /*[out]*/ ULONG * const pErrorInfo);        //@P3A
ULONG WINAPI pcsSetPrinterSettings(/*[in]*/  char cShortSessionID,                //@P3A
                                   /*[in]*/  const PRINTINFO * const pPrintInfo,  //@P3A
                                   /*[out]*/ ULONG *const pErrorInfo);            //@P3A
ULONG WINAPI pcsGetPrinterSettings(/*[in]*/  char cShortSessionID,                //@P3A
                                   /*[out]*/ PRINTINFO * const pPrintInfo,        //@P3A
                                   /*[out]*/ ULONG *const pErrorInfo);            //@P3A
#endif
/*--------------------------------------------------------------------------*/
/*  Ordinal numbers for function entry points                               */
/*--------------------------------------------------------------------------*/

#define ord_pcsQueryEmulatorStatus     3
#define ord_pcsQueryWorkstationProfile 4
#define ord_pcsStartSession            5
#define ord_pcsStopSession             6
#define ord_pcsConnectSession          7
#define ord_pcsDisconnectSession       8
#define ord_pcsQuerySessionList        9
#if defined(_V43)
#define ord_pcsSetLinkTimeout          10
#endif
#if defined(_V50)
#define ord_pcsQueryConnectionInfo     11
#endif

#if defined(_V57)
#define ord_pcsRestorePageDefaults     12                                         //@P3A
#define ord_pcsSetPageSettings         13                                         //@P3A
#define ord_pcsGetPageSettings         14                                         //@P3A
#define ord_pcsSetPrinterSettings      15                                         //@P3A
#define ord_pcsGetPrinterSettings      16                                         //@P3A
#endif

#endif // _PCSAPI32_H_                                                            //@P3A

#ifdef __cplusplus
  }
#endif

