
#ifndef INCL_CPICCMC
#define INCL_CPICCMC

//#define CM_SECURITY_NONE    XC_SECURITY_NONE                 /* for andy   */
//#define CM_SECURITY_SAME    XC_SECURITY_SAME                 /* for andy   */
//#define CM_SECURITY_PROGRAM XC_SECURITY_PROGRAM              /* for andy   */

#define CM_SYNC_POINT            (CM_SYNC_LEVEL) 2           /*  ypc       */
#define CM_SYNC_POINT_NO_CONFIRM (CM_SYNC_LEVEL) 3           /*  ypc       */

#include <windows.h>
#include "wincpic.h"

#endif

