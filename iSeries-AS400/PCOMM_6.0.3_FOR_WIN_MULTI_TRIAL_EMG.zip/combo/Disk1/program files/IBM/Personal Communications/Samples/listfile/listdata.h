//******************************************************************************
//
// LISTDATA.H - Data Global to ListFile application
//
//******************************************************************************

#ifdef MAIN
#define DECLARE
#define INIT_TO(init_value)  = init_value
#else
#define DECLARE extern
#define INIT_TO(init_value)
#endif

DECLARE HWND           hRcvDlgClient           INIT_TO(NULL);
DECLARE HWND           hSessionServer          INIT_TO(NULL);
DECLARE HANDLE         hGlobalInst;
DECLARE HANDLE         hData;

DECLARE HWND           hGlobalWnd;
DECLARE HWND           hWndHidden;

DECLARE BOOL           bFirstScreen            INIT_TO(TRUE);

DECLARE UINT           uCurFileDDEMsg;
DECLARE WORD           uNumberOfFiles          INIT_TO(0);

DECLARE uchar          *ListFileClassName        INIT_TO("ListFile");
DECLARE uchar          *FileListClassName        INIT_TO("FileList");

DECLARE uchar          *zSpace                   INIT_TO(" ");
DECLARE uchar          *zMore                    INIT_TO("MORE");
DECLARE uchar          *zRunning                 INIT_TO("RUNNING");
DECLARE uchar          *zReady                   INIT_TO("READY");

DECLARE uchar          zMsgBuffer[257];
DECLARE uchar          zFmtBuffer[257];
DECLARE uchar          zCmdLineSessionID[9];
DECLARE uchar          zHostFileMask[129];

DECLARE uchar          zListFileNames[MAXFILENAMES+1][SIZEOFFILENAME];
