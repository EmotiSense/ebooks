Emulator Class Library sample - ECLMON
--------------------------------------

Description:
------------

This is a sample ECL application which implements a PComm "system monitor".
It monitors the status of all 26 sessions and allows the user to start,
stop, connect, and disconnect sessions.  It also displays the presenation
space, field list, and other information about any session.

Building the program:
---------------------

A working executable (.EXE) file is provided so the program can be run
without the use of a development environment.  To build the program,
install a supported development environment and follow the instructions 
below:

  IBM VisualAge C++
  -----------------

  A "make" file is provided for building the sample from a command
  line.  If the sample is moved from the default installation location,
  the make file will need to be modified to point to the proper
  PComm directories.  See the comments in the "MAKEFILE" file.

  To build the sample program, issue the following command:

     build /a all

  The resulting executable (ECLMON.EXE) will be placed in the
  current directory.

  Microsoft Visual C++ Version 4.2
  --------------------------------

  A Visual Studio project file is provided for building the sample from
  the Visual Studio application.  To load the project file into the
  Visual Studio:

     File -> Open Workspace

  Load the ECLMON.MDB file in this directory.  If the sample is moved
  from the default installation location, the project settings will need
  to be modified to point to the proper PComm directories.  To do this,
  modify the following in the Build -> Settings:

    "Additional include directories" on the C/C++ tab ("Preprocessor")
    "Object/library modules" on the Link tab

  To build the sample, select Build -> Rebuild All.  The resulting
  executable file (ECLMON.EXE) will be placed in the "Debug"
  subdirectory.
