#include "stdafx.h"
#include "pinginfo.h"

PingInfo::PingInfo() :
 destination(_T("")), tpName(_T("APINGD")), mode(_T("#INTER")),
 consecutivePackets(1), iterations(2), packetSize(100),
 userID(_T("")), password(_T("")),
 echo(TRUE), security(FALSE), verify(FALSE)
{
}

PingInfo::PingInfo(PingInfo const &pi) :
 destination(pi.destination), tpName(pi.tpName), mode(pi.mode),
 consecutivePackets(pi.consecutivePackets), iterations(pi.iterations),
 packetSize(pi.packetSize),
 userID(pi.userID), password(pi.password),
 echo(pi.echo), security(pi.security), verify(pi.verify)
{
}

PingInfo& PingInfo::operator=(PingInfo const &pi)
{
  if (this != &pi) {
    destination = pi.destination;
    tpName = pi.tpName;
    mode = pi.mode;
    consecutivePackets = pi.consecutivePackets;
    iterations = pi.iterations;
    packetSize = pi.packetSize;
    userID = pi.userID;
    password = pi.password;
    echo = pi.echo;
    security = pi.security;
    verify = pi.verify;
  }

  return *this;
}
