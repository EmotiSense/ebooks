//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cpdslist.rc
//
#define IDR_MAINFRAME                   128
#define IDD_LOGIN                       129
#define IDD_SPLASH                      130
#define IDD_CONNECTIONS                 131
#define IDD_CPDSLIST_DIALOG             132
#define IDC_DSLIST                      133
#define IDC_DSCONTENTS                  134
#define IDC_REFRESHDS                   135
#define IDC_USERNAME                    136
#define IDC_PASSWORD                    137
#define IDC_REFRESH                     138
#define IDC_CONNLIST                    139
#define IDD_DSNAMELEVEL                 140
#define IDC_DSNLEVEL                    1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
