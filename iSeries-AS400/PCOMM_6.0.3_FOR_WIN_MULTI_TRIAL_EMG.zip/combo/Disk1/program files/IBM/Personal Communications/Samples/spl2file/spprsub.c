//******************************************************************************
//
//  File name   : SPPRSUB.C
//
//  Description : Common sub functions for the Spl2File
//
//  FUNCTIONS:
//
//  COMMENTS:
//
//  Copyright  (C) 1993, 1996 IBM Corporation
//                        All rights reserved.
//
//******************************************************************************

#include <windows.h>                // required for all Windows applications
#include <windowsx.h>               // Windows Macro APIs, window message crackers
#include <string.h>                 // C string functions
#include <stdio.h>                  // C functions

#include "spl2file.h"               // specific to this program
#include "spdata.h"                 // Global Data
                                    //
//******************************************************************************
//
// Local Data
//
//******************************************************************************
                                           //
static FARPROC lpAbortDialogProc;          //
                                           //
//******************************************************************************
//
//  DisplayAbortDialog - Display an abort dialog box
//
//  PURPOSE:
//
//  Put a modeless dialog box
//
//  COMMENTS:
//
//******************************************************************************
//BOOL DisplayAbortDialog( HWND hOwnerWnd )
HWND DisplayAbortDialog( HWND hOwnerWnd )
{                                          //
  HWND hDlg;                               //
  lpAbortDialogProc = MakeProcInstance( AbortDialogProc, hGlobalInst );
                                           //
  hDlg = CreateDialog(hGlobalInst, MAKEINTRESOURCE(ABORTBOX),
                      hOwnerWnd, lpAbortDialogProc );
                                           //
  EnableWindow( hOwnerWnd, FALSE );        // Disable the parent

//return( (BOOL) hDlg );                   //
  return( hDlg );                          //
}                                          //

//******************************************************************************
//
//  DestroyAbortDialog - Destroy the abort dialog box
//
//  PURPOSE:
//
//  Gets rid of the abort dialog and re enables the parent.
//
//  COMMENTS:
//
//******************************************************************************
BOOL DestroyAbortDialog( HWND hAbortDlg, HWND hOwnerWnd )
{                                         //
  DestroyWindow( hAbortDlg );             // Get rid of Window
  FreeProcInstance( lpAbortDialogProc );  // Get rid of proc instance
  EnableWindow( hOwnerWnd, TRUE );        // Enable the parent

  return( (BOOL) TRUE );                  //
}                                         //

//******************************************************************************
//
//  AbortDialogProc - Abort box dialog procedure
//
//  PURPOSE:
//
//  Process the abort dialog
//
//  COMMENTS:
//
//******************************************************************************
BOOL FAR PASCAL AbortDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{                                        //
  switch (message)                       //
  {                                      //
    case WM_INITDIALOG:                  // message: initialize dialog box
      bUserAbort = FALSE;                //
      CenterDialogOnScreen( hDlg );      // Center it
      SetWindowText(hDlg, zAbortTitle);  // Set the title
      SetFocus( hDlg );                  // Give the dialog focus.
      return(TRUE);                      //
      break;                             //

    case WM_COMMAND:                     //
      switch (GET_WM_COMMAND_ID(wParam,lParam))
      {                                  //
        case IDCANCEL:                   // cancel button
          bUserAbort = TRUE;             //
          PostMessage(hMainWnd,          //
                      WM_USER_ABORT,     //
                      (WPARAM)hMainWnd,  //
                      0L );              //
          return(TRUE);                  //
          break;                         //

        default:                         //
          break;                         //
      }                                  //
      break;                             //
  }                                      //
  return( FALSE );                       //
}                                        //

//******************************************************************************
//
//  InitSession - Initiate session DDE conversation
//
//  PURPOSE:
//
//
//  COMMENTS:
//
//******************************************************************************
BOOL InitSession( void )
{                                          //
  uchar    zTmpSess[10];                   //

  lstrcpy ( zTmpSess, zSESSION );          //
  lstrcat ( zTmpSess, zSessionID );        //
  aIBM5250 = GlobalAddAtom ( zIBM5250 );   // Application name
  aSession = GlobalAddAtom ( zTmpSess );   // Topic name

  SendMessage ( (HWND)-1,                  // Send Initiate messgae
                WM_DDE_INITIATE,           //
                (WPARAM)hMainWnd,          //
                MAKELONG ( aIBM5250, aSession ) );
                                           //
  GlobalDeleteAtom ( aSession );           //
  GlobalDeleteAtom ( aIBM5250 );           //

  return ( ( BOOL ) hSessWnd );            //
}                                          //

//******************************************************************************
//
//  TerminateSession - Terminate session DDE conversation
//
//  PURPOSE:
//
//
//  COMMENTS:
//
//******************************************************************************
void TerminateSession ( void )
{                                          //
  if ( hSessWnd )                          //
  {                                        //
    PostMessage ( hSessWnd,                // Post Terminate message
                  WM_DDE_TERMINATE,        //
                  (WPARAM)hMainWnd,        //
                  MAKELONG ( NULL, NULL ) );  //
  }                                        //
}                                          //

//******************************************************************************
//
//  FSM_Event - Select Finite State Machine
//
//  PURPOSE:
//
//
//  COMMENTS:
//
//******************************************************************************
BOOL FSM_Event( BYTE Event, ATOM aItem, HANDLE hData )
{
  BOOL  bRC = FALSE;                                 //
                                                     //
  switch (wOperation)                                //
  {                                                  //
    case SPOOL_TO_FILE:                              // Spool to File
      FSM_SpoolToFile( Event, aItem, hData );        //
      bRC = TRUE;                                    //
      break;                                         //
                                                     //
    default:                                         //
      break;                                         //
  }                                                  //
  return (bRC);                                      //
}                                                    //
