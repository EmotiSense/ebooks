//******************************************************************************
//
//  File name   : SPL2FILE.H
//
//  Description : Defines constans and function prototypes
//
//  FUNCTIONS:
//
//  COMMENTS:
//
//  Copyright  (C) 1993, 1996 IBM Corporation
//                        All rights reserved.
//
//******************************************************************************

#define uchar           unsigned char

//************* Global function defines

//------------------------------------------------------------------------------
// SPWINMAN.C
//------------------------------------------------------------------------------
int      PASCAL WinMain                  ( HANDLE, HANDLE, LPSTR, int );
BOOL            RegisterApplicationClass ( HANDLE );
BOOL            InitInstance             ( HANDLE, int );
long FAR PASCAL SpoolToFileWndProc       ( HWND, UINT, WPARAM, LPARAM );
BOOL FAR PASCAL PCFilenameDialog         ( HWND, UINT, WPARAM, LPARAM );
BOOL FAR PASCAL About                    ( HWND, UINT, WPARAM, LPARAM );

//------------------------------------------------------------------------------
// SPSPOOL.C
//------------------------------------------------------------------------------
void            StartSpoolToFile         ( HWND );
void            FSM_SpoolToFile          ( BYTE, ATOM, HANDLE );

//------------------------------------------------------------------------------
// SPCONFG.C
//------------------------------------------------------------------------------
void            ConfigureSpoolToFile     ( HWND );
BOOL FAR PASCAL SpoolToFileOptionsDialog (HWND, UINT, WPARAM, LPARAM );

//------------------------------------------------------------------------------
// SPSDDE.C
//------------------------------------------------------------------------------
BOOL FAR        InitDDE            ( void );
BOOL FAR        SpDDEInitiate      ( HWND, UINT, WPARAM, LPARAM );
BOOL FAR        SpDDEAck           ( HWND, UINT, WPARAM, LPARAM );
BOOL FAR        SpDDEData          ( HWND, UINT, WPARAM, LPARAM );
BOOL FAR        SpDDERequest       ( HWND, UINT, WPARAM, LPARAM );
BOOL FAR        SpDDETerminate     ( HWND, UINT, WPARAM, LPARAM );
void            PrepGetPartialPs   ( int, int, int );
void            RequestGetPs       ( void );
void            RequestGetPartPs   ( void );
void            ExecuteKeystrokes  ( LPSTR );
void            SetCursorPosition  ( int, int );

//------------------------------------------------------------------------------
// SPPRSUB.C
//------------------------------------------------------------------------------
//BOOL            DisplayAbortDialog    ( HWND );       // Display abort dialog
HWND            DisplayAbortDialog    ( HWND );       // Display abort dialog
BOOL            DestroyAbortDialog    ( HWND, HWND ); // Destroy abort dialog
BOOL FAR PASCAL AbortDialogProc       ( HWND, UINT, WPARAM, LPARAM );
BOOL            AddLineToList         ( HANDLE );     // Add line to list
BOOL            InitSession           ( void );
void            TerminateSession      ( void );
BOOL            FSM_Event             ( BYTE, ATOM, HANDLE );

//------------------------------------------------------------------------------
// SPSUB1.C
//------------------------------------------------------------------------------
BOOL            TerminateConversation ( void );
BOOL            DDEPostMessage        ( HWND, UINT, WPARAM, LPARAM );
void            CenterDialogOnScreen  ( HWND );
int             OffsetInPs            ( int, int );   // return offset in PS
void            GetStartEndCol        ( LPSTR, LPINT, LPINT );
BOOL            IsDbcsHiByte          ( BYTE );
BOOL            IsSoSi                ( BYTE );

// ************* Dialog Identifiers

#define ID_ABOUT     6001
#define ID_HELP      6002
#define ID_SPOOL     6003
#define ID_ZCONFG    6004
#define ID_EDIT1     6005
#define ID_CHECKBOX1 6006
#define ID_RADIO1    6007
#define ID_RADIO2    6008

#define ID_IGNORE  -1

// ************* Resource Identifiers

#define SPMENU     9000
#define SPICON     9001
#define ABOUTBOX   9002
#define ABORTBOX   9003
#define PCFILENAME 9004
#define SPOPTS     9005

//************* Load String Identifiers

#define LS_ERROR1_TEXT          1
#define LS_ERROR2_TEXT          2
#define LS_ERROR3_TEXT          3
#define LS_ERROR4_TEXT          4
#define LS_TITLE_TEXT           5
#define LS_DDE_TOKENS           6
#define LS_16STR_FORMAT         7
#define LS_ABORT_TITLEF         8
#define LS_OPTIONS_TAG          9

//************* MISC

#define uchar           unsigned char

#define DDE_GLOBAL  ( GHND | GMEM_DDESHARE | GMEM_MOVEABLE | GMEM_ZEROINIT )

#define DDE_ACK         0x8000
#define DDE_NACK        0x0000       /* Negative ACK          */
#define DDE_NACK_BUSY   0x4000       /* Negative ACK/BUSY     */

#define WM_USER_END     (WM_USER +  1 )
#define WM_USER_ERROR   (WM_USER +  2 )
#define WM_USER_ABORT   (WM_USER +  3 )
#define WM_USER_CONT    (WM_USER +  4 )
#define WM_USER_BREAK   (WM_USER +  5 )

//******************************************************************************
//
// MISC
//
//******************************************************************************

#define GMEM_GLOBAL     ( GHND | GMEM_DDESHARE | GMEM_MOVEABLE | GMEM_ZEROINIT )

#define SPACE_CHAR      ' '
#define NULL_CHAR       '\0'
#define WS_FIXEDWINDOW  ( WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZE | WS_MINIMIZEBOX )
#define VERY_LIGHT_GRAY ( (DWORD) 0x00C0C0C0 )

#define STATIC_STYLE    ( SS_LEFT | WS_VISIBLE | WS_CHILD )

#define SPOOL_TO_FILE   1

#define EV_DATA         0
#define EV_ACK          1
#define EV_NACK         2
#define EV_END          3
#define EV_ERROR        4
#define EV_ABORT        5
#define EV_CONT         6
#define EV_BRK          7

#define MAX_ROW        24
#define MAX_COL        80
