// winapdoc.cpp : implementation of the CWinapingDoc class
//

#include "stdafx.h"
#include "winaping.h"

#include "winapdoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWinapingDoc

IMPLEMENT_DYNCREATE(CWinapingDoc, CDocument)

BEGIN_MESSAGE_MAP(CWinapingDoc, CDocument)
        //{{AFX_MSG_MAP(CWinapingDoc)
                // NOTE - the ClassWizard will add and remove mapping macros here.
                //    DO NOT EDIT what you see in these blocks of generated code!
        //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinapingDoc construction/destruction

CWinapingDoc::CWinapingDoc() : aping(NULL), alloctime(0), confirmtime(0),
  partner(_T("")), cmcall(_T("")), cmrcmsg(_T("")),
  stoprunning(FALSE), buffer(NULL)
{
}

CWinapingDoc::~CWinapingDoc()
{
}

BOOL CWinapingDoc::OnNewDocument()
{
        if (!CDocument::OnNewDocument())
                return FALSE;

        SetTitle(_T("Personal Communications"));

        // TODO: add reinitialization code here
        // (SDI documents will reuse this document)

        return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CWinapingDoc serialization

void CWinapingDoc::Serialize(CArchive& ar)
{
        if (ar.IsStoring())
        {
                // TODO: add storing code here
        }
        else
        {
                // TODO: add loading code here
        }
}

/////////////////////////////////////////////////////////////////////////////
// CWinapingDoc diagnostics

#ifdef _DEBUG
void CWinapingDoc::AssertValid() const
{
//      CDocument::AssertValid();         // ????? ASERT FAILED HERE ????
}

void CWinapingDoc::Dump(CDumpContext& dc) const
{
        CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWinapingDoc commands
