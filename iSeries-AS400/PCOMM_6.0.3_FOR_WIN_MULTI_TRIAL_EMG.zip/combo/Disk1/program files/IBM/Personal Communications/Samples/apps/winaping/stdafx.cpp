// stdafx.cpp : source file that includes just the standard includes
//	winaping.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

