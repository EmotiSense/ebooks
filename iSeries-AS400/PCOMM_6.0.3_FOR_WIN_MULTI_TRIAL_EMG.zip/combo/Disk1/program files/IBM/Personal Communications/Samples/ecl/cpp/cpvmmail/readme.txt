Emulator Class Library sample - CPVMMAIL
----------------------------------------

Description:
------------

This is a sample ECL application which implements a GUI front in to IBM's
OfficeVision Mail.  It can view, discard, keep, reply, and reply with history.


Building the program:
---------------------


  Microsoft Visual C++ Version 4.2
  --------------------------------

  A Visual Studio project file is provided for building the sample from
  the Visual Studio application.  To load the project file into the
  Visual Studio:

     File -> Open Workspace

  Load the CPVMMAIL.MDB file in this directory.  If the sample is moved
  from the default installation location, the project settings will need
  to be modified to point to the proper PComm directories.  To do this,
  modify the following in the Build -> Settings:

    "Additional include directories" on the C/C++ tab ("Preprocessor")
    "Object/library modules" on the Link tab

  To build the sample, select Build -> Rebuild All.  The resulting
  executable file (CPVMMAIL.EXE) will be placed in the "Debug"
  subdirectory.
