// ReplyDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReplyDlg dialog

class CReplyDlg : public CDialog
{
private:
  ECLSession    *m_pECLSession;
  CCVMMailApp   *m_pMyApp;
  CEdit         *m_pReplyEditBox;

  void PageDown();
  void SendNote();
  void CopyReplyToScreen();

// Construction
public:
	CReplyDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CReplyDlg)
	enum { IDD = IDD_REPLY };
	CString	m_ReplyText;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReplyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CReplyDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
