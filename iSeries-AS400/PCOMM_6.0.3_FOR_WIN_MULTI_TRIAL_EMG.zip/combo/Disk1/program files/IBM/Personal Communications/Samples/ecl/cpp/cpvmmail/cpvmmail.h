// cpvmmail.h : main header file for the CPVMMAIL application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "eclall.hpp"

/////////////////////////////////////////////////////////////////////////////
// CCVMMailApp:
// See cpvmmail.cpp for the implementation of this class
//

#ifndef _CPVMMAIL_H_
#define _CPVMMAIL_H_

class CCVMMailApp : public CWinApp
{
public:
  ECLSession  *m_pECLSession;
  BOOL WaitForScreen(CString Str1, CString Str2, long TimeInterval, int MaxTries);
  void WaitForInput(int SleepInterval, int MaxTries);

public:
	CCVMMailApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCVMMailApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCVMMailApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //_CPVMMAIL_H_

/////////////////////////////////////////////////////////////////////////////
