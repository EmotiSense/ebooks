//******************************************************************************
//
//  File name   : SPDATA.H
//
//  Description : Declares variables for SPL2FILE
//
//  FUNCTIONS:
//
//  COMMENTS:
//
//  Copyright  (C) 1993, 1996 IBM Corporation
//                        All rights reserved.
//
//******************************************************************************

#ifdef MAIN
#define DECLARE
#define INIT_TO(init_value)  = init_value
#else
#define DECLARE extern
#define INIT_TO(init_value)
#endif

DECLARE BOOL           bUserAbort                 INIT_TO((int)NULL); // User Abort flag
DECLARE BOOL           bVisible                   INIT_TO(TRUE);  // Visible Flag
DECLARE BOOL           bRemoveSoSi                INIT_TO(TRUE);  // Remove SO/SI char flag

DECLARE HANDLE         hGlobalInst;                               // Instance handle

DECLARE HWND           hMainWnd                   INIT_TO(NULL);  // Window handle of this Appl
DECLARE HWND           hAbortDialog               INIT_TO(NULL);  // Abort dialog Handle
DECLARE HWND           hDDEClientWnd              INIT_TO(NULL);  // Window handle of PC/5250

DECLARE int            iMenuPicked                INIT_TO((int)NULL);   // Selected Menue Item

DECLARE uchar          *zSpoolToFileClassPrefix   INIT_TO("Spl2File");  // Class Name of SPL2FILE
DECLARE uchar          *zSessionClassPrefix       INIT_TO("PCS5250");   // Class Name of PC/5250
DECLARE uchar          *zIBM5250                  INIT_TO("IBM525032"); // Application name of DDE Server
DECLARE uchar          *zSESSION                  INIT_TO("SESSION");   // Topic name of DDE Server
DECLARE uchar          *zPS                       INIT_TO("PS");        // Item name
DECLARE uchar          *zEPS                      INIT_TO("EPS");       // Item name
DECLARE uchar          *zEPSCOND                  INIT_TO("EPSCOND");   // Item name
DECLARE uchar          *zSETCURSOR                INIT_TO("SETCURSOR"); // Item name
DECLARE uchar          *zTopID                    INIT_TO("DISPLAY SPOOLED FILE");// At Line 1,  Column 31
DECLARE uchar          *zBottomID                 INIT_TO("BOTTOM");    // At line 22, Column 74
DECLARE uchar          *zTopIDJ                   INIT_TO("�X�v�[���E�t�@�C����\x95\x5c��");// At Line 1,  Column 29
DECLARE uchar          *zBottomIDJ                INIT_TO("�I��");      // At line 22, Column 74

DECLARE uchar          zSpoolToFileClassName[33];                 // Buffer for 5250 class name
DECLARE uchar          zSessionClassName[33];                     // Buffer for PC/5250 class name
DECLARE uchar          zMsgBuffer[257];                           // Buffer for message
DECLARE uchar          zFmtBuffer[129];                           // Buffer for wsprintf
DECLARE uchar          zAbortTitle[129];                          // Buffer for Abort Box Title
DECLARE uchar          zSessionID[9];                             // Buffer for Session ID
DECLARE uchar          zOtherSessionIDs[9];                       // Buffer for Session ID
DECLARE uchar          zPCFilename[128];                          // Buffer for PC Filename

DECLARE ATOM           aIBM5250                   INIT_TO((unsigned short)NULL);  // Atom for Application
DECLARE ATOM           aSession                   INIT_TO((unsigned short)NULL);  // Atom for Topic
DECLARE ATOM           aEPSCOND                   INIT_TO((unsigned short)NULL);  // Atom for Item
DECLARE ATOM           aEPS                       INIT_TO((unsigned short)NULL);  // Atom for Item
DECLARE ATOM           aPS                        INIT_TO((unsigned short)NULL);  // Atom for Item
DECLARE ATOM           aSETCURSOR                 INIT_TO((unsigned short)NULL);  // Atom for Item

DECLARE HWND           hSessWnd                   INIT_TO(NULL);  // Window handle of DDE Server
DECLARE WORD           wOperation                 INIT_TO((unsigned short)NULL);  // Current opeation
DECLARE UINT           uLastMessage               INIT_TO((unsigned int)NULL);  // Last sent message

DECLARE BYTE           State                      INIT_TO((unsigned char)NULL);  // Current sate of Finite State Machine
DECLARE HANDLE         hRcvData                   INIT_TO(NULL);  // Memory handle of DDE Data
