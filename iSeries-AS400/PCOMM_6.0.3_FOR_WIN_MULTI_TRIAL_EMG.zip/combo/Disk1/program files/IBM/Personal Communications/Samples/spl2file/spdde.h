//******************************************************************************
//
//  File name   : SPDDE.H
//
//  Description : Defines structures for DDE conversation
//
//  FUNCTIONS:
//
//  COMMENTS:
//
//  Copyright  (C) 1993, 1996 IBM Corporation
//                        All rights reserved.
//
//******************************************************************************

#define   WC_DDE_GLOBAL      (GHND | GMEM_DDESHARE)

