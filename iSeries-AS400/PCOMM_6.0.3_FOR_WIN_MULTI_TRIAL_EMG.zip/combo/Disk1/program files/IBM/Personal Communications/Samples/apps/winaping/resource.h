//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by winaping.rc
//
#define IDR_MAINFRAME                   128
#define IDR_WINAPITYPE                  129
#define IDD_SETUPDLG                    130
#define IDD_GODLG                       131
#define IDC_ALLOCTIME                   1000
#define IDC_CONFIRMTIME                 1001
#define IDC_PARTNER                     1002
#define IDC_CURRITER                    1005
#define IDC_MINTIME                     1006
#define IDC_MAXTIME                     1007
#define IDC_AVGTIME                     1008
#define IDC_TOTTIME                     1009
#define IDC_TOTBYTE                     1010
#define IDC_RATE1                       1011
#define IDC_RATE2                       1012
#define IDC_LISTVIEW                    1013
#define IDRESET                         1017
#define IDC_TPNAME                      1020
#define IDC_PACKETSIZE                  1021
#define IDC_CONSECUTIVE                 1022
#define IDC_ITERATIONS                  1023
#define IDC_VERIFY                      1026
#define IDC_SECURITY                    1027
#define IDC_USERID                      1031
#define IDC_PASSWORD                    1032
#define IDC_ECHO                        1033
#define IDC_DESTINATION                 1034
#define IDC_MODE                        1035
#define IDC_STATIC_USERID               1036
#define IDC_STATIC_PASSWORD             1037
#define IDC_MSGAREA                     1039
#define IDC_USER2                       1041
#define ID_ACTION_SETUP                 32771
#define ID_ACTION_GO                    32772
#define ID_ACTION_STOP                  32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
