// ConnectionsDLG.cpp : implementation file
//

#include "stdafx.h"
#include "cpvmmail.h"
#include "conndlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConnectionsDLG dialog


CConnectionsDLG::CConnectionsDLG(CWnd* pParent /*=NULL*/)
	: CDialog(CConnectionsDLG::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnectionsDLG)
	m_ConnName = _T("");
	//}}AFX_DATA_INIT
}


void CConnectionsDLG::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnectionsDLG)
	DDX_LBString(pDX, IDC_CONNLIST, m_ConnName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnectionsDLG, CDialog)
	//{{AFX_MSG_MAP(CConnectionsDLG)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnectionsDLG message handlers

void CConnectionsDLG::OnCancel() 
{
  // Unregister for connection start events
  //m_ConnMgr.UnregisterStartEvent(m_pMyNotifyClass);
	
	CDialog::OnCancel();
}

void CConnectionsDLG::OnOK() 
{
  // Unregister for connection start events
  //m_ConnMgr.UnregisterStartEvent(m_pMyNotifyClass);

  m_pMyConnListBox->GetText( m_pMyConnListBox->GetCurSel(), m_ConnName );

	CDialog::OnOK();
}

BOOL CConnectionsDLG::OnInitDialog() 
{
	CDialog::OnInitDialog();

  // Get the list box control object
  m_pMyConnListBox = (CListBox *)this->GetDlgItem(IDC_CONNLIST);

  // Populate the list box
  RefreshConnList();

  // Register for connection start events
  //m_pMyNotifyClass = new ConnEvent(m_pMyConnListBox);
  //m_ConnMgr.RegisterStartEvent(m_pMyNotifyClass);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CConnectionsDLG::RefreshConnList() 
{
ULONG           i, Count;
ECLConnection   *CurrentConnection;

  try {
    // Clear the list box
    m_pMyConnListBox->ResetContent();

    // Add the connections to the list
    m_ConnMgr.GetConnList()->Refresh();
    Count = m_ConnMgr.GetConnList()->GetCount();
    if ( Count > 0 ) {
      CurrentConnection = m_ConnMgr.GetConnList()->GetFirstConnection();
      for ( i = 0; i < Count; i++) {
        char ConnString[2];
    
        ConnString[0] = CurrentConnection->GetName();
        ConnString[1] = 0x00;
      
        m_pMyConnListBox->AddString(ConnString);
        CurrentConnection = m_ConnMgr.GetConnList()->GetNextConnection(CurrentConnection);
      }
    }
  }
  catch (ECLErr Err) {
    AfxMessageBox(Err.GetMsgText(), MB_ICONEXCLAMATION);
  }

	return;
}

void CConnectionsDLG::OnRefresh() 
{
	RefreshConnList();
	
}
