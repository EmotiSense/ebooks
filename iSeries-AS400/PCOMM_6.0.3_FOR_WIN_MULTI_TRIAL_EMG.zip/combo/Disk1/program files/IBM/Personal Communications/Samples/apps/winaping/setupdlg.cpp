// CSetupdlg.cpp : implementation file
//

#include "stdafx.h"
#include "winaping.h"
#include "constdef.h"
#include "setupdlg.h"
#include "mainfrm.h"
#include "winapdoc.h"
#include "pinginfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetupdlg dialog

CSetupdlg::CSetupdlg(PingInfo &pi, CWnd* pParent /*=NULL*/)
        : CDialog(CSetupdlg::IDD, pParent), localpi(pi), docpi(pi)
{
        //{{AFX_DATA_INIT(CSetupdlg)
        //}}AFX_DATA_INIT
//      pDoc = (CWinapingDoc*) (((CMainFrame*)pParent)->GetActiveDocument());
}


void CSetupdlg::DoDataExchange(CDataExchange* pDX)
{
        CDialog::DoDataExchange(pDX);
        //{{AFX_DATA_MAP(CSetupdlg)
        //}}AFX_DATA_MAP
        DDX_Text(pDX, IDC_DESTINATION, localpi.destination);
        DDV_MaxChars(pDX, localpi.destination, MAX_DESTINATION);
        DDX_Text(pDX, IDC_MODE, localpi.mode);
        DDV_MaxChars(pDX, localpi.mode, MAX_MODE_NAME);
        DDX_Text(pDX, IDC_TPNAME, localpi.tpName);
        DDV_MaxChars(pDX, localpi.tpName, MAX_TP_NAME);
        DDX_Text(pDX, IDC_PACKETSIZE, localpi.packetSize);
        DDV_MinMaxDWord(pDX, localpi.packetSize, 1, MAX_PACKETSIZE);
        DDX_Text(pDX, IDC_CONSECUTIVE, localpi.consecutivePackets);
        DDV_MinMaxDWord(pDX, localpi.consecutivePackets, 1, MAX_CONSECUTIVE);
        DDX_Text(pDX, IDC_ITERATIONS, localpi.iterations);
        DDV_MinMaxDWord(pDX, localpi.iterations, 0, MAX_ITERATIONS);
        DDX_Check(pDX, IDC_ECHO, localpi.echo);
        DDX_Check(pDX, IDC_VERIFY, localpi.verify);
        DDX_Check(pDX, IDC_SECURITY, localpi.security);
        DDX_Text(pDX, IDC_USERID, localpi.userID);
        DDV_MaxChars(pDX, localpi.userID, MAX_USERID);
        DDX_Text(pDX, IDC_PASSWORD, localpi.password);
        DDV_MaxChars(pDX, localpi.password, MAX_PASSWORD);
}


BEGIN_MESSAGE_MAP(CSetupdlg, CDialog)
        //{{AFX_MSG_MAP(CSetupdlg)
        ON_BN_CLICKED(IDRESET, OnReset)
        ON_BN_CLICKED(IDC_ECHO, OnEcho)
        ON_BN_CLICKED(IDC_SECURITY, OnSecurity)
        //}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CSetupdlg message handlers

void CSetupdlg::OnOK()
{
      if (UpdateData(TRUE)) {       // dlg window to local pi, if OK ....
        docpi = localpi;            // local pi to doc pi

        // --------------------------------
        // Some safty works ...............
        int i = -1;
        do {
          if (i == 0) docpi.destination = (docpi.destination).Mid(1);
          i = (docpi.destination).Find(_T(" "));
          } while (i == 0);                       // exit only when i>0 or i=-1
        if (i > 0) docpi.destination = (docpi.destination).SpanExcluding(_T(" "));

        do {
          if (i == 0) docpi.tpName = (docpi.tpName).Mid(1);
          i = (docpi.tpName).Find(_T(" "));
          } while (i == 0);
        if (i > 0) docpi.tpName = (docpi.tpName).SpanExcluding(_T(" "));

        do {
          if (i == 0) docpi.mode = (docpi.mode).Mid(1);
          i = (docpi.mode).Find(_T(" "));
          } while (i == 0);
        if (i > 0) docpi.mode = (docpi.mode).SpanExcluding(_T(" "));

        if (docpi.security) {
          do {
            if (i == 0) docpi.userID = (docpi.userID).Mid(1);
            i = (docpi.userID).Find(_T(" "));
            } while (i == 0);
          if (i > 0) docpi.userID = (docpi.userID).SpanExcluding(_T(" "));

          do {
            if (i == 0) docpi.password = (docpi.password).Mid(1);
            i = (docpi.password).Find(_T(" "));
            } while (i == 0);
          if (i > 0) docpi.password = (docpi.password).SpanExcluding(_T(" "));
          }

        docpi.verify = localpi.echo && localpi.verify;

        EndDialog(IDOK);
        }
}

void CSetupdlg::OnReset()
{
        localpi = docpi;            // doc pi to local pi
        UpdateData(FALSE);          // local pi to dlg window
}


void CSetupdlg::OnEcho()
{
  BOOL flag;
  if (((CButton*) GetDlgItem(IDC_ECHO))->GetCheck() == 0) flag = FALSE;
  else flag = TRUE;
  GetDlgItem(IDC_VERIFY)->EnableWindow(flag);
}

void CSetupdlg::OnSecurity()
{
  BOOL flag;
  if (((CButton*) GetDlgItem(IDC_SECURITY))->GetCheck() == 0) flag = FALSE;
  else flag = TRUE;
  GetDlgItem(IDC_USERID)->EnableWindow(flag);
  GetDlgItem(IDC_STATIC_USERID)->EnableWindow(flag);
  GetDlgItem(IDC_PASSWORD)->EnableWindow(flag);
  GetDlgItem(IDC_STATIC_PASSWORD)->EnableWindow(flag);
}

BOOL CSetupdlg::OnInitDialog()
{
        localpi = docpi;            // doc pi to local pi
        CDialog::OnInitDialog();
        OnEcho();
        OnSecurity();

        return TRUE;  // return TRUE unless you set the focus to a control
                      // EXCEPTION: OCX Property Pages should return FALSE
}
