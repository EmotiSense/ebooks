// goview.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGoView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CWinapingDoc;

class CGoView : public CFormView
{
protected:
        CGoView();           // protected constructor used by dynamic creation
        DECLARE_DYNCREATE(CGoView)

// Form Data
public:
        //{{AFX_DATA(CGoView)
	enum { IDD = IDD_GODLG };
	CListBox	m_msgArea;
        CString m_partner;
        CString m_rate2;
        CString m_rate1;
        CString m_curriter;
        DWORD   m_alloctime;
        DWORD   m_avgtime;
        DWORD   m_confirmtime;
        DWORD   m_maxtime;
        DWORD   m_mintime;
        CString m_totbyte;
        CString m_tottime;
	//}}AFX_DATA

// Attributes
public:
        void Refresh0();
        void RefreshMsg(CString str);

// Operations
public:

// Overrides
        // ClassWizard generated virtual function overrides
        //{{AFX_VIRTUAL(CGoView)
        public:
        virtual void OnInitialUpdate();
        protected:
        virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
        //}}AFX_VIRTUAL

// Implementation
protected:
        TEXTMETRIC    tm;
        CRect         m_rect;
        BOOL          verify_failed_msg_issued;  // only one msg displayed
        DWORD         total_byte_per_iter; // 64K pketsize/echo/32K consecutive
        double        grand_total_byte;    // DWORD not enough for this
        double        grand_total_time;    // DWORD not enough for this

        virtual      ~CGoView();
#ifdef _DEBUG
        virtual void AssertValid() const;
        virtual void Dump(CDumpContext& dc) const;
#endif

        // Generated message map functions
        //{{AFX_MSG(CGoView)
                // NOTE - the ClassWizard will add and remove member functions here.
        afx_msg LONG OnCpiccallErr(UINT, LONG);           // user msg handler
        afx_msg LONG OnRefresh(UINT, LONG);               // user msg handler
        //}}AFX_MSG
        DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
