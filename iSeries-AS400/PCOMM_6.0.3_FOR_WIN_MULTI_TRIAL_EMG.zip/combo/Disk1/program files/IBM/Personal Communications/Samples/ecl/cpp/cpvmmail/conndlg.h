// ConnectionsDLG.h : header file
//

#include "eclall.hpp"

//class ConnEvent: public ECLStartNotify
//{
  //private:
    //CListBox    *m_pMyConnListBox;
//
  //public:
    //ConnEvent();
//    ConnEvent( CWnd *pListBox ) {
//      m_pMyConnListBox = (CListBox *)pListBox;
//    };
//    ~ConnEvent();
//
//    void NotifyEvent (ECLConnMgr *CMObj, long ConnHandle, BOOL Started) {
//      char ConnString[2];
//      int  ConnIndex;
//
//      ConnString[0] = ConvertHandle2ShortName(ConnHandle);
//      ConnString[1] = 0x00;
//      
//      if ( Started )
//        m_pMyConnListBox->AddString(ConnString);
//      else {
//        ConnIndex = m_pMyConnListBox->FindStringExact(0, ConnString);
//        m_pMyConnListBox->DeleteString(ConnIndex);
//      }
//    };
//
//    void NotifyError (ECLConnMgr *CMObj, long ConnHandle, ECLErr ErrObject) {
//      char  *ErrMsg = new char[strlen(ErrObject.GetMsgText()) + 1];
//
//      strcpy( ErrMsg, ErrObject.GetMsgText() );
//      AfxMessageBox( ErrMsg, MB_ICONEXCLAMATION);
//
//    };
//};

/////////////////////////////////////////////////////////////////////////////
// CConnectionsDLG dialog

class CConnectionsDLG : public CDialog
{
friend class ConnEvent;

private:
  ECLConnMgr  m_ConnMgr;
//  ConnEvent   *m_pMyNotifyClass;
  CListBox    *m_pMyConnListBox;

public:
	CConnectionsDLG(CWnd* pParent = NULL);   // standard constructor
  void RefreshConnList();

// Dialog Data
	//{{AFX_DATA(CConnectionsDLG)
	enum { IDD = IDD_CONNECTIONS };
	CString	m_ConnName;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnectionsDLG)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConnectionsDLG)
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnRefresh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
