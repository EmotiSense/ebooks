/*****************************************************************************/
/*                                                                           */
/*  File name   : PCSMAIN.H                                                  */
/*                                                                           */
/*  Description : Defines constants and function prototypes                  */
/*                                                                           */
/*  Concepts    : [none]                                                     */
/*                                                                           */
/*  API's       : [none]                                                     */
/*                                                                           */
/*  Required                                                                 */
/*    Files     : [none]                                                     */
/*                                                                           */
/*  Copyright  (C)  1994, 1996  IBM  Corporation                             */
/*                                                                           */
/*                    All rights reserved.                                   */
/*                                                                           */
/*****************************************************************************/
/*-----------------------------------------------------------------------------*
|  Menu IDs                                                                    |
*-----------------------------------------------------------------------------*/
#define IDM_FILE                300
#define IDM_FILE_ABOUT          301
#define IDM_FILE_CLEAR          302
#define IDM_FILE_TITLE          303
#define IDM_FILE_EXIT           304
#define IDM_FILE_TOP            305

#define IDM_PCSAPI              310
#define IDM_PCSAPI_START        311
#define IDM_PCSAPI_STOP         312
#define IDM_PCSAPI_STATUS       313
#define IDM_PCSAPI_PROFILE      314
#define IDM_PCSAPI_CONN         315
#define IDM_PCSAPI_DISCONN      316
#define IDM_PCSAPI_TIMEOUT      317

/*-----------------------------------------------------------------------------*
|  Icon IDs                                                                    |
*-----------------------------------------------------------------------------*/
#define ICONPCSMAIN             400

/*-----------------------------------------------------------------------------*
|  Dialog IDs                                                                  |
*-----------------------------------------------------------------------------*/
#define START_DLG               500
#define STOP_DLG                501
#define STATUS_DLG              502
#define PROF_DLG                503
#define CONN_DLG                504
#define DISCONN_DLG             505
#define TIMEOUT_DLG             506
#define ABOUTBOX                507
#define TITLEBOX                508

#define DID_SESID_GP            600
#define DID_SESID               601
#define DID_PRONAME_GP          602
#define DID_PRONAME             603
#define DID_VIS_GP              604
#define DID_RESTORE             605
#define DID_HIDE                606
#define DID_RES                 607
#define DID_SHOW_MAX            608
#define DID_MIN_NOACT           609
#define DID_SHOW_NA             610
#define DID_SHOW_NORM           611
#define DID_MIN                 612
#define DID_SHOW                613
#define DID_SHOW_MIN            614
#define DID_SHOW_NO_ACT         615

#define DID_PRO_SAVE_GP         616
#define DID_SAVE_AS_PROFILE     617
#define DID_SAVE_ON_EXIT        618
#define DID_NOSAVE_ON_EXIT      619

#define DID_STARTED_ST          620
#define DID_STARTED             621
#define DID_ONLINE_ST           622
#define DID_ONLINE              623
#define DID_API_ENABLED_ST      624
#define DID_API_ENABLED         625

#define DID_TIMEOUTVALUE_GP     626
#define DID_TIMEOUTVALUE        627

#define IDD_TITLE               628
#define IDD_LIST                629

#define ID_IGNORE               -1
/*-----------------------------------------------------------------------------*
|  String IDs                                                                  |
*-----------------------------------------------------------------------------*/
#define LS_MENU                 300
#define LS_LIST                 301
#define LS_LISTBOX              302
#define LS_CLASS                303
#define LS_TITLE                304

#define LS_NO_SESSIONID         305
#define LS_NO_PROFILENAME       306
#define LS_SESSION_NOTSTARTED   307
#define LS_INVALID_SESSIONID    308
#define LS_ACTIVE_SESSIONID     309
#define LS_PROFILE_ERROR        310
#define LS_SYSTEM_ERROR         311
#define LS_SAMPLE_PROGRAM       312
#define LS_SESSION_CANNOTSTOP   313
#define LS_NO_TIMEOUTVALUE      314
#define LS_INVALID_TIMEOUTVALUE 315
#define LS_TIMEOUT_ERROR        316
/*-----------------------------------------------------------------------------*
|  Defines for the main window's size                                          |
*-----------------------------------------------------------------------------*/
#define MAIN_WIDTH              300
#define MAIN_HEIGHT             180

/*-----------------------------------------------------------------------------*
|  Miscellaneous defines                                                       |
*-----------------------------------------------------------------------------*/
#define FILENAME_LENGTH         80
#define BUFFER_LENGTH           64
#define STRING_LEN              10
#define TITLE_LEN               64
#define LISTBOX_MAXWIDTH        1000

/*-----------------------------------------------------------------------------*
|  Function prototypes                                                         |
*-----------------------------------------------------------------------------*/
int    PASCAL WinMain(HANDLE, HANDLE, LPSTR, int);
LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ListWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK TitleDlgProc(HWND, UINT, WPARAM, LPARAM);

LRESULT CALLBACK StartDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK StopDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK StatusDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ProfileDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ConnectDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK DisconnectDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SetLinkTimeoutDlgProc(HWND, UINT, WPARAM, LPARAM);

/*-----------------------------------------------------------------------------*
|  Global variables                                                            |
*-----------------------------------------------------------------------------*/
HANDLE   ghInst = NULL;
HWND     ghListBox = NULL;
HWND     ghMainWnd = NULL;
BOOL     fTopmost = FALSE;
CHAR     glpProfile[MAXPATHLEN] = {0x00};
